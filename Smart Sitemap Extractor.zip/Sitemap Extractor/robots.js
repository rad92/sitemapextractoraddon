/* robots.txt rule evaluation.

   A URL sitting in the sitemap while robots.txt blocks it is one of the most
   damaging errors in SEO and one of the least visible: the page looks perfect,
   nothing in its markup is wrong, and Google simply never crawls it. The tool
   already downloads robots.txt to find the sitemap, so the rules come free. */

const ROBOTS_AGENT = "Googlebot";

/* ---------- parsing ---------- */

// Groups are accumulated across consecutive user-agent lines: several agents
// may share one block of rules.
function parseRobots(text) {
  const groups = [];
  const sitemaps = [];
  let current = null;
  let expectingAgents = false;

  for (const rawLine of String(text || "").split(/\r?\n/)) {
    const line = rawLine.replace(/#.*$/, "").trim();
    if (!line) continue;

    const split = line.indexOf(":");
    if (split === -1) continue;

    const field = line.slice(0, split).trim().toLowerCase();
    const value = line.slice(split + 1).trim();

    if (field === "user-agent") {
      if (!expectingAgents || !current) {
        current = { agents: [], rules: [] };
        groups.push(current);
        expectingAgents = true;
      }
      current.agents.push(value.toLowerCase());
      continue;
    }

    if (field === "sitemap") {
      sitemaps.push(value);
      continue;
    }

    if (field === "allow" || field === "disallow") {
      expectingAgents = false;
      if (!current) {
        // Rules before any user-agent line are technically invalid; treat them
        // as belonging to everyone rather than discarding them silently.
        current = { agents: ["*"], rules: [] };
        groups.push(current);
      }
      // "Disallow:" with an empty value means "nothing is disallowed", so it
      // contributes no rule at all.
      if (field === "disallow" && value === "") continue;
      if (value === "") continue;
      current.rules.push({ type: field, pattern: value });
      continue;
    }

    // crawl-delay, host and anything else: not relevant to whether a URL is
    // allowed, and ending the agent block is the only thing that matters.
    expectingAgents = false;
  }

  return { groups, sitemaps };
}

// Google picks exactly one group: the most specific matching user-agent, with
// "*" as the fallback. Matching is case-insensitive and ignores any version
// suffix, so "googlebot/2.1" matches a "googlebot" group.
function rulesForAgent(parsed, agent = ROBOTS_AGENT) {
  const wanted = agent.toLowerCase();
  let best = null;
  let bestLength = -1;
  let wildcard = null;

  for (const group of parsed.groups) {
    for (const candidate of group.agents) {
      if (candidate === "*") {
        wildcard = wildcard || { agents: group.agents, rules: [] };
        wildcard.rules.push(...group.rules);
        continue;
      }
      if (wanted.startsWith(candidate) && candidate.length > bestLength) {
        bestLength = candidate.length;
        best = group;
      }
    }
  }

  if (best) return { rules: best.rules, matchedAgent: best.agents.join(", ") };
  if (wildcard) return { rules: wildcard.rules, matchedAgent: "*" };
  return { rules: [], matchedAgent: null };
}

/* ---------- matching ---------- */

// robots.txt patterns are prefix matches with two special characters: "*" for
// any run of characters and "$" anchoring the end.
function patternToRegex(pattern) {
  let source = "";
  let anchored = false;

  for (let i = 0; i < pattern.length; i++) {
    const ch = pattern[i];
    if (ch === "*") {
      source += ".*";
    } else if (ch === "$" && i === pattern.length - 1) {
      anchored = true;
    } else {
      source += ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }
  }

  return new RegExp("^" + source + (anchored ? "$" : ""));
}

const regexCache = new Map();
function matchRule(path, pattern) {
  let regex = regexCache.get(pattern);
  if (!regex) {
    regex = patternToRegex(pattern);
    regexCache.set(pattern, regex);
  }
  return regex.test(path);
}

// Google's precedence: the longest matching pattern wins, and a tie goes to
// Allow (the least restrictive rule).
function isAllowed(url, rules) {
  let path;
  try {
    const parsed = new URL(url);
    path = parsed.pathname + parsed.search;
  } catch {
    return { allowed: true, rule: null };
  }

  let winner = null;
  for (const rule of rules) {
    if (!matchRule(path, rule.pattern)) continue;
    if (
      !winner ||
      rule.pattern.length > winner.pattern.length ||
      (rule.pattern.length === winner.pattern.length && rule.type === "allow")
    ) {
      winner = rule;
    }
  }

  return {
    allowed: !winner || winner.type === "allow",
    rule: winner,
  };
}

/* ---------- applying to a sitemap ---------- */

function checkRobots(rows, robotsText, agent = ROBOTS_AGENT) {
  if (robotsText == null) {
    for (const row of rows) row.robotsBlocked = false;
    return { available: false, blocked: 0, rules: 0, matchedAgent: null };
  }

  const parsed = parseRobots(robotsText);
  const { rules, matchedAgent } = rulesForAgent(parsed, agent);

  let blocked = 0;
  const byRule = new Map();

  for (const row of rows) {
    const verdict = isAllowed(row.loc, rules);
    row.robotsBlocked = !verdict.allowed;
    row.robotsRule = verdict.rule ? `${verdict.rule.type}: ${verdict.rule.pattern}` : "";

    if (row.robotsBlocked) {
      blocked++;
      const key = verdict.rule.pattern;
      if (!byRule.has(key)) byRule.set(key, []);
      byRule.get(key).push(row);
    }
  }

  // A blocked URL that still gets impressions is the sharpest version of this
  // finding — Google is showing a page it was told not to crawl.
  const blockedWithTraffic = rows.filter((r) => r.robotsBlocked && (r.gsc?.impressions || 0) > 0).length;

  return {
    available: true,
    matchedAgent,
    agent,
    rules: rules.length,
    blocked,
    blockedWithTraffic,
    byRule: [...byRule.entries()]
      .map(([pattern, list]) => ({ pattern, count: list.length, examples: list.slice(0, 5).map((r) => r.loc) }))
      .sort((a, b) => b.count - a.count),
    declaredSitemaps: parsed.sitemaps.length,
  };
}
