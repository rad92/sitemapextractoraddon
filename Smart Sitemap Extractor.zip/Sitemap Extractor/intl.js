/* Text handling for sites that aren't in English or UTF-8. */

/* ---------- character encoding ---------- */

// Chrome's TextDecoder speaks the legacy encodings the rest of the world still
// ships: Shift_JIS, GB18030, Big5, EUC-KR, windows-125x, ISO-8859-x.
function decodeBody(buffer, contentTypeHeader) {
  const bytes = new Uint8Array(buffer);

  // 1. A byte-order mark wins outright — it is unambiguous.
  if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
    return { text: decodeWith(bytes, "utf-8"), charset: "utf-8", from: "BOM" };
  }
  if (bytes[0] === 0xff && bytes[1] === 0xfe) {
    return { text: decodeWith(bytes, "utf-16le"), charset: "utf-16le", from: "BOM" };
  }
  if (bytes[0] === 0xfe && bytes[1] === 0xff) {
    return { text: decodeWith(bytes, "utf-16be"), charset: "utf-16be", from: "BOM" };
  }

  // 2. The HTTP header, when the server bothers to send one.
  const headerCharset = /charset\s*=\s*["']?([\w-]+)/i.exec(contentTypeHeader || "")?.[1];
  if (headerCharset && isKnownCharset(headerCharset)) {
    return { text: decodeWith(bytes, headerCharset), charset: headerCharset.toLowerCase(), from: "header" };
  }

  // 3. The <meta> declaration. This is the common case internationally: plenty of
  //    Japanese and Russian sites send a bare "text/html" header and declare the
  //    real encoding in the markup. Sniff it from an ASCII-safe read of the head,
  //    then decode the whole body properly.
  const probe = decodeWith(bytes.subarray(0, 4096), "windows-1252");
  const metaCharset =
    /<meta[^>]+charset\s*=\s*["']?\s*([\w-]+)/i.exec(probe)?.[1] ||
    /<meta[^>]+content\s*=\s*["'][^"']*charset\s*=\s*([\w-]+)/i.exec(probe)?.[1];

  if (metaCharset && isKnownCharset(metaCharset)) {
    return { text: decodeWith(bytes, metaCharset), charset: metaCharset.toLowerCase(), from: "meta" };
  }

  return { text: decodeWith(bytes, "utf-8"), charset: "utf-8", from: "default" };
}

function isKnownCharset(label) {
  try {
    new TextDecoder(label);
    return true;
  } catch {
    return false;
  }
}

function decodeWith(bytes, label) {
  try {
    return new TextDecoder(label, { fatal: false }).decode(bytes);
  } catch {
    return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  }
}

/* ---------- internationalized domain names ---------- */

// RFC 3492. The URL API normalizes hostnames to punycode, so münchen.de becomes
// xn--mnchen-3ya.de. Showing that back to someone auditing a German or Russian
// site is unreadable, so decode it for display.
function punyAdapt(delta, numPoints, firstTime) {
  delta = firstTime ? Math.floor(delta / 700) : delta >> 1;
  delta += Math.floor(delta / numPoints);
  let k = 0;
  while (delta > 455) {
    delta = Math.floor(delta / 35);
    k += 36;
  }
  return k + Math.floor((36 * delta) / (delta + 38));
}

function punyDecode(input) {
  const output = [];
  let i = 0;
  let n = 128;
  let bias = 72;

  const delimiter = input.lastIndexOf("-");
  if (delimiter > 0) {
    for (const ch of input.slice(0, delimiter)) output.push(ch.codePointAt(0));
  }

  let index = delimiter > 0 ? delimiter + 1 : 0;
  while (index < input.length) {
    const oldi = i;
    let w = 1;
    for (let k = 36; ; k += 36) {
      if (index >= input.length) return null;
      const code = input.charCodeAt(index++);
      let digit;
      if (code >= 0x30 && code <= 0x39) digit = code - 0x30 + 26;
      else if (code >= 0x61 && code <= 0x7a) digit = code - 0x61;
      else if (code >= 0x41 && code <= 0x5a) digit = code - 0x41;
      else return null;
      i += digit * w;
      const t = k <= bias ? 1 : k >= bias + 26 ? 26 : k - bias;
      if (digit < t) break;
      w *= 36 - t;
    }
    const outLen = output.length + 1;
    bias = punyAdapt(i - oldi, outLen, oldi === 0);
    n += Math.floor(i / outLen);
    i %= outLen;
    if (n < 128) return null;
    output.splice(i, 0, n);
    i++;
  }

  try {
    return String.fromCodePoint(...output);
  } catch {
    return null;
  }
}

function unicodeHost(hostname) {
  if (!hostname.includes("xn--")) return hostname;
  return hostname
    .split(".")
    .map((label) => {
      if (!label.toLowerCase().startsWith("xn--")) return label;
      return punyDecode(label.slice(4)) ?? label;
    })
    .join(".");
}

/* ---------- URL comparison ---------- */

// One definition of "the same URL", used by both the canonical check and the
// hreflang graph so they can never disagree. Ignores trailing slash, host case
// and the default port; keeps the query, which can genuinely change a page.
function normUrl(href, base) {
  try {
    const u = base ? new URL(href, base) : new URL(href);
    const path = u.pathname.replace(/\/+$/, "");
    // u.host, not u.hostname: hostname drops the port, which silently rewrites
    // http://staging.example.com:8080/x to port 80. The URL API already strips
    // default ports, so this stays stable for ordinary sites.
    return `${u.protocol}//${u.host.toLowerCase()}${path}${u.search}`;
  } catch {
    return null;
  }
}

function displayUrl(href) {
  try {
    const u = new URL(href);
    const host = unicodeHost(u.hostname);
    // decodeURI turns percent-encoded Cyrillic, Greek, CJK paths back into text.
    let path = u.pathname + u.search;
    try {
      path = decodeURI(path);
    } catch {
      /* malformed escapes: leave as-is */
    }
    return host + path;
  } catch {
    return href;
  }
}

/* ---------- display width ---------- */

// Google truncates titles by pixel width, not character count, and CJK glyphs are
// roughly double-width. Counting characters tells a Japanese site its 35-character
// title is fine when it is actually being cut off. Width in half-width units is a
// far better proxy, and it matches ASCII counts exactly for Latin scripts.
const WIDE_CHARS =
  /[\u1100-\u115F\u2E80-\u303E\u3041-\u33FF\u3400-\u4DBF\u4E00-\u9FFF\uA000-\uA4CF\uAC00-\uD7A3\uF900-\uFAFF\uFE30-\uFE6F\uFF00-\uFF60\uFFE0-\uFFE6]/;

function displayWidth(text) {
  let width = 0;
  for (const ch of text || "") width += WIDE_CHARS.test(ch) ? 2 : 1;
  return width;
}

// Script hint, used to explain why a width target is what it is.
function scriptOf(text) {
  if (!text) return "";
  if (/[\u3040-\u30FF]/.test(text)) return "Japanese";
  if (/[\uAC00-\uD7A3]/.test(text)) return "Korean";
  if (/[\u4E00-\u9FFF]/.test(text)) return "Chinese";
  if (/[\u0400-\u04FF]/.test(text)) return "Cyrillic";
  if (/[\u0600-\u06FF]/.test(text)) return "Arabic";
  if (/[\u0590-\u05FF]/.test(text)) return "Hebrew";
  if (/[\u0E00-\u0E7F]/.test(text)) return "Thai";
  if (/[\u0370-\u03FF]/.test(text)) return "Greek";
  if (/[\u0900-\u097F]/.test(text)) return "Devanagari";
  return "";
}

const RTL_CHARS = /[\u0590-\u05FF\u0600-\u06FF\u0700-\u074F\u0780-\u07BF\uFB1D-\uFDFF\uFE70-\uFEFF]/;
function isRtl(text) {
  return RTL_CHARS.test(text || "");
}

/* ---------- SERP truncation ---------- */
