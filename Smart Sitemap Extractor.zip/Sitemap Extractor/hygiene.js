/* Sitemap hygiene.

   Checks the sitemap as a document in its own right, rather than as a list of
   pages. Everything here comes from data already collected during the crawl. */

// Google's published limits for a single sitemap file.
const SITEMAP_MAX_URLS = 50000;
const SITEMAP_MAX_BYTES = 50 * 1024 * 1024;

const TRACKING_PARAMS = [
  "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "utm_id",
  "gclid", "fbclid", "msclkid", "mc_cid", "mc_eid", "igshid", "ref", "_ga",
];

// W3C datetime, which is what the sitemap spec requires for lastmod.
const W3C_DATE = /^\d{4}(-\d{2}(-\d{2}([T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?)?)?$/;

function sitemapHygiene(rows, sitemaps, duplicates, origin) {
  const issues = [];
  const add = (code, severity, detail, examples = []) =>
    issues.push({ code, severity, detail, examples: examples.slice(0, 5) });

  let siteOrigin = null;
  try {
    siteOrigin = new URL(origin);
  } catch {
    /* fall through: cross-host checks are skipped */
  }

  /* ---- per-file limits ---- */

  for (const file of sitemaps || []) {
    if (file.kind === "failed") continue;
    if (file.count > SITEMAP_MAX_URLS) {
      add("oversized", "error",
        `${displayUrl(file.url)} lists ${file.count.toLocaleString()} URLs — over Google's ${SITEMAP_MAX_URLS.toLocaleString()} limit for one file. Split it and use a sitemap index.`);
    }
    if (file.bytes > SITEMAP_MAX_BYTES) {
      add("oversized-bytes", "error",
        `${displayUrl(file.url)} is ${Math.round(file.bytes / 1024 / 1024)} MB uncompressed — over Google's 50 MB limit.`);
    }
    if (file.kind === "urls" && file.count === 0) {
      add("empty-sitemap", "warn", `${displayUrl(file.url)} contains no URLs.`);
    }
  }

  /* ---- sitemap-level lastmod ---- */

  const staleIndex = [];
  const indexNoLastmod = [];

  for (const file of sitemaps || []) {
    if (file.kind === "failed") continue;

    // Google uses the lastmod an index declares for a child to decide whether
    // re-fetching that child is worthwhile. If the claim is older than the
    // content, the child can simply stop being re-read.
    if (file.declaredLastmod && file.newestUrl) {
      if (isoDate(file.declaredLastmod) < isoDate(file.newestUrl)) {
        staleIndex.push(
          `${displayUrl(file.url)} — index says ${isoDate(file.declaredLastmod)}, contains URLs from ${isoDate(file.newestUrl)}`
        );
      }
    }
    if (file.kind === "index" && file.count && !file.childrenWithLastmod) {
      indexNoLastmod.push(displayUrl(file.url));
    }
    if (file.declaredLastmod && !W3C_DATE.test(String(file.declaredLastmod).trim())) {
      add("bad-sitemap-lastmod", "error",
        `${displayUrl(file.url)} is declared in its index with an unparseable lastmod ("${file.declaredLastmod}").`);
    }
  }

  if (staleIndex.length) {
    add("stale-index-lastmod", "error",
      `${staleIndex.length} sitemap file${staleIndex.length === 1 ? " is" : "s are"} declared in the index with a lastmod older than the newest URL inside. Google uses that date to decide whether to re-fetch the file, so newer URLs can go unread.`,
      staleIndex);
  }
  if (indexNoLastmod.length) {
    add("index-no-lastmod", "warn",
      `${indexNoLastmod.length} sitemap index${indexNoLastmod.length === 1 ? "" : "es"} declare no lastmod for their child sitemaps, so Google has no way to tell which files changed and must re-fetch all of them.`,
      indexNoLastmod);
  }

  /* ---- duplicates across files ---- */

  if (duplicates && duplicates.size) {
    const examples = [...duplicates.entries()].slice(0, 5).map(([url, sources]) =>
      `${displayUrl(url)} — in ${sources.length} files`);
    add("duplicate-urls", "warn",
      `${duplicates.size.toLocaleString()} URL${duplicates.size === 1 ? " appears" : "s appear"} in more than one sitemap file.`,
      examples);
  }

  /* ---- per-URL checks ---- */

  const badLastmod = [];
  const futureLastmod = [];
  const missingLastmod = [];
  const insecure = [];
  const crossHost = [];
  const fragments = [];
  const tracking = [];
  const uppercase = [];

  const today = new Date();
  today.setDate(today.getDate() + 1); // a day's tolerance for timezone skew

  for (const row of rows) {
    if (row.lastmod) {
      if (!W3C_DATE.test(row.lastmod.trim())) {
        badLastmod.push(`${displayUrl(row.loc)} — "${row.lastmod}"`);
      } else {
        const when = new Date(row.lastmod);
        if (!isNaN(when.getTime()) && when > today) {
          futureLastmod.push(`${displayUrl(row.loc)} — ${isoDate(row.lastmod)}`);
        }
      }
    } else {
      missingLastmod.push(row.loc);
    }

    let parsed;
    try {
      parsed = new URL(row.loc);
    } catch {
      continue;
    }

    if (parsed.protocol === "http:" && siteOrigin?.protocol === "https:") {
      insecure.push(displayUrl(row.loc));
    }
    if (siteOrigin && parsed.hostname.replace(/^www\./, "") !== siteOrigin.hostname.replace(/^www\./, "")) {
      crossHost.push(displayUrl(row.loc));
    }
    if (parsed.hash) fragments.push(displayUrl(row.loc));

    const params = [...parsed.searchParams.keys()].filter((k) => TRACKING_PARAMS.includes(k.toLowerCase()));
    if (params.length) tracking.push(`${displayUrl(row.loc)} — ${params.join(", ")}`);

    if (/[A-Z]/.test(parsed.pathname)) uppercase.push(displayUrl(row.loc));
  }

  if (badLastmod.length) {
    add("bad-lastmod", "error",
      `${badLastmod.length.toLocaleString()} URL${badLastmod.length === 1 ? " has" : "s have"} a lastmod that isn't a valid W3C date. Google ignores the value entirely when it can't parse it.`,
      badLastmod);
  }
  if (futureLastmod.length) {
    add("future-lastmod", "warn",
      `${futureLastmod.length.toLocaleString()} URL${futureLastmod.length === 1 ? " has" : "s have"} a lastmod in the future, which makes the whole file's dates less trustworthy.`,
      futureLastmod);
  }
  if (missingLastmod.length === rows.length && rows.length) {
    add("no-lastmod", "warn",
      "No URL has a lastmod. It's optional, but without it Google has no signal about what changed and recrawls on its own schedule.");
  }
  if (insecure.length) {
    add("http-urls", "error",
      `${insecure.length.toLocaleString()} URL${insecure.length === 1 ? " uses" : "s use"} http:// while the site is https://.`,
      insecure);
  }
  if (crossHost.length) {
    add("cross-host", "warn",
      `${crossHost.length.toLocaleString()} URL${crossHost.length === 1 ? " points" : "s point"} at a different host than the sitemap.`,
      crossHost);
  }
  if (fragments.length) {
    add("fragments", "error",
      `${fragments.length.toLocaleString()} URL${fragments.length === 1 ? " contains" : "s contain"} a # fragment. Google drops fragments, so these collapse onto the same page.`,
      fragments);
  }
  if (tracking.length) {
    add("tracking-params", "warn",
      `${tracking.length.toLocaleString()} URL${tracking.length === 1 ? " carries" : "s carry"} tracking parameters, which usually creates duplicates of the clean URL.`,
      tracking);
  }
  if (uppercase.length) {
    add("mixed-case", "warn",
      `${uppercase.length.toLocaleString()} URL${uppercase.length === 1 ? " has" : "s have"} uppercase characters in the path. Valid, but a frequent source of duplicate URLs when the server accepts both forms.`,
      uppercase);
  }

  return {
    issues,
    errors: issues.filter((i) => i.severity === "error").length,
    warnings: issues.filter((i) => i.severity === "warn").length,
  };
}
