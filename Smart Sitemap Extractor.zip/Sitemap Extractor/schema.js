/* Structured data validation.

   The meta pass already parses every JSON-LD block to read dates, so validating
   it costs nothing extra. Rules follow Google's rich-result requirements rather
   than the whole of schema.org: a property schema.org merely allows is not worth
   flagging, while one Google requires for eligibility is. */

// required: omitting it makes the page ineligible for the rich result.
// recommended: Google asks for it and the result is weaker without it.
const SCHEMA_RULES = {
  Article: { required: ["headline"], recommended: ["image", "datePublished", "dateModified", "author"] },
  NewsArticle: { required: ["headline"], recommended: ["image", "datePublished", "dateModified", "author"] },
  BlogPosting: { required: ["headline"], recommended: ["image", "datePublished", "dateModified", "author"] },
  Product: { required: ["name"], recommended: ["image", "description", "offers", "aggregateRating", "review", "brand"] },
  Offer: { required: ["price", "priceCurrency"], recommended: ["availability"] },
  LocalBusiness: { required: ["name", "address"], recommended: ["telephone", "openingHours", "image", "priceRange"] },
  Organization: { required: ["name"], recommended: ["url", "logo"] },
  WebSite: { required: ["name", "url"], recommended: [] },
  BreadcrumbList: { required: ["itemListElement"], recommended: [] },
  FAQPage: { required: ["mainEntity"], recommended: [] },
  Question: { required: ["name", "acceptedAnswer"], recommended: [] },
  Event: { required: ["name", "startDate", "location"], recommended: ["endDate", "image", "description", "offers"] },
  Recipe: { required: ["name", "image", "recipeIngredient", "recipeInstructions"], recommended: ["author", "datePublished", "description", "prepTime", "cookTime"] },
  VideoObject: { required: ["name", "description", "thumbnailUrl", "uploadDate"], recommended: ["duration", "contentUrl"] },
  Review: { required: ["itemReviewed", "reviewRating"], recommended: ["author", "datePublished"] },
  AggregateRating: { required: ["ratingValue"], recommended: ["reviewCount", "ratingCount"] },
  Person: { required: ["name"], recommended: [] },
  JobPosting: { required: ["title", "description", "datePosted", "hiringOrganization"], recommended: ["jobLocation", "baseSalary", "validThrough"] },
  SoftwareApplication: { required: ["name"], recommended: ["applicationCategory", "offers", "aggregateRating"] },
  Course: { required: ["name", "description"], recommended: ["provider"] },
  Service: { required: ["name"], recommended: ["provider", "areaServed"] },
};

// Types that inherit LocalBusiness's requirements.
const LOCAL_BUSINESS_SUBTYPES = /Restaurant|Store|Dentist|Physician|LegalService|HomeAndConstructionBusiness|ProfessionalService|AutomotiveBusiness|FinancialService|MedicalBusiness|SportsActivityLocation|EntertainmentBusiness|FoodEstablishment|LodgingBusiness|HealthAndBeautyBusiness|ChildCare|EmergencyService|GovernmentOffice|RealEstateAgent|TravelAgency|Plumber|Electrician|RoofingContractor|GeneralContractor/;

function rulesForType(type) {
  if (SCHEMA_RULES[type]) return SCHEMA_RULES[type];
  if (LOCAL_BUSINESS_SUBTYPES.test(type)) return SCHEMA_RULES.LocalBusiness;
  return null;
}

function typeNames(value) {
  const raw = value?.["@type"];
  if (!raw) return [];
  return (Array.isArray(raw) ? raw : [raw]).filter((t) => typeof t === "string");
}

// A property counts as present if it has any real content. Empty strings and
// empty arrays are a common CMS output and are worse than useless: they look
// populated in the source and count for nothing.
function hasValue(node, field) {
  const value = node[field];
  if (value == null) return false;
  if (typeof value === "string") return value.trim() !== "";
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === "object") return Object.keys(value).length > 0;
  return true;
}

function validateSchema(doc) {
  const result = {
    blocks: 0,
    broken: 0,
    types: [],
    issues: [],
    hasMicrodata: false,
    hasRdfa: false,
  };

  // Collected so the SERP preview can show what these annotations would earn:
  // breadcrumbs in place of the URL, a star rating, FAQ rows.
  const rich = { breadcrumbs: [], rating: null, faq: [], image: "", datePublished: "" };
  const seenTypes = new Set();
  const add = (severity, type, message) => result.issues.push({ severity, type, message });

  for (const script of doc.querySelectorAll('script[type="application/ld+json" i]')) {
    result.blocks++;

    let data;
    try {
      data = JSON.parse(script.textContent);
    } catch (err) {
      result.broken++;
      add("error", "", `Invalid JSON-LD: ${String(err.message).slice(0, 90)}`);
      continue;
    }

    const topLevel = Array.isArray(data) ? data : [data];
    for (const entry of topLevel) {
      if (entry && typeof entry === "object" && !entry["@context"] && !entry["@graph"]) {
        add("warn", "", "A JSON-LD block has no @context, so search engines may ignore it.");
      }
    }

    for (const node of ldNodes(data)) {
      const types = typeNames(node);
      if (!types.length) continue;

      for (const type of types) {
        seenTypes.add(type);
        const rules = rulesForType(type);
        if (!rules) continue;

        for (const field of rules.required) {
          if (!hasValue(node, field)) {
            add("error", type, `${type} is missing required property "${field}".`);
          }
        }
        for (const field of rules.recommended) {
          if (!hasValue(node, field)) {
            add("warn", type, `${type} is missing recommended property "${field}".`);
          }
        }

        if (type === "BreadcrumbList" && Array.isArray(node.itemListElement) && !rich.breadcrumbs.length) {
          rich.breadcrumbs = node.itemListElement
            .slice()
            .sort((a, b) => (a?.position || 0) - (b?.position || 0))
            .map((item) => (typeof item?.name === "string" ? item.name : item?.item?.name || ""))
            .filter(Boolean);
        }
        if (type === "AggregateRating" && !rich.rating && node.ratingValue != null) {
          rich.rating = {
            value: Number(node.ratingValue),
            best: Number(node.bestRating ?? 5),
            count: Number(node.reviewCount ?? node.ratingCount ?? 0) || 0,
          };
        }
        if (type === "Question" && hasValue(node, "name") && rich.faq.length < 6) {
          rich.faq.push(String(node.name));
        }
        if (!rich.image && typeof node.image === "string") rich.image = node.image;
        if (!rich.datePublished && typeof node.datePublished === "string") rich.datePublished = node.datePublished;

        // Shape checks that a property-presence test cannot catch.
        if (type === "BreadcrumbList" && Array.isArray(node.itemListElement)) {
          const missingPosition = node.itemListElement.some((item) => item && item.position == null);
          if (missingPosition) add("error", type, "BreadcrumbList items must each have a position.");
        }
        if (type === "FAQPage" && Array.isArray(node.mainEntity)) {
          const bad = node.mainEntity.some(
            (q) => !q || !hasValue(q, "name") || !q.acceptedAnswer || !hasValue(q.acceptedAnswer, "text")
          );
          if (bad) add("error", type, "Every FAQ entry needs a name and an acceptedAnswer with text.");
        }
        if (type === "AggregateRating" && node.ratingValue != null) {
          const value = Number(node.ratingValue);
          const best = Number(node.bestRating ?? 5);
          if (Number.isFinite(value) && Number.isFinite(best) && value > best) {
            add("error", type, `ratingValue ${node.ratingValue} is above bestRating ${best}.`);
          }
        }
      }
    }
  }

  // Other syntaxes are valid but not parsed here, which is worth stating rather
  // than reporting "no structured data" on a page that has plenty.
  result.hasMicrodata = Boolean(doc.querySelector("[itemscope][itemtype]"));
  result.hasRdfa = Boolean(doc.querySelector("[typeof][vocab], [property][typeof]"));

  result.rich = rich;
  result.types = [...seenTypes].sort();
  result.errors = result.issues.filter((i) => i.severity === "error").length;
  result.warnings = result.issues.filter((i) => i.severity === "warn").length;
  return result;
}

/* ---------- site-wide roll-up ---------- */

function schemaReport(rows) {
  const typeCounts = new Map();
  const issueCounts = new Map();
  let pagesWithSchema = 0;
  let pagesWithErrors = 0;
  let pagesWithout = 0;
  let microdataOnly = 0;
  let checked = 0;

  for (const row of rows) {
    if (!row.schema) continue;
    checked++;

    const schema = row.schema;
    if (schema.blocks) pagesWithSchema++;
    else if (schema.hasMicrodata || schema.hasRdfa) microdataOnly++;
    else pagesWithout++;

    if (schema.errors) pagesWithErrors++;

    for (const type of schema.types) typeCounts.set(type, (typeCounts.get(type) || 0) + 1);

    for (const issue of schema.issues) {
      const key = `${issue.severity}|${issue.message}`;
      if (!issueCounts.has(key)) {
        issueCounts.set(key, { severity: issue.severity, message: issue.message, count: 0, examples: [] });
      }
      const entry = issueCounts.get(key);
      entry.count++;
      if (entry.examples.length < 5) entry.examples.push(row.loc);
    }
  }

  return {
    checked,
    pagesWithSchema,
    pagesWithErrors,
    pagesWithout,
    microdataOnly,
    types: [...typeCounts.entries()].map(([type, count]) => ({ type, count })).sort((a, b) => b.count - a.count),
    issues: [...issueCounts.values()].sort(
      (a, b) => (a.severity === b.severity ? b.count - a.count : a.severity === "error" ? -1 : 1)
    ),
  };
}
