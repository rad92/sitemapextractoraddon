/* UI: orchestration, rendering, filtering, export. */

const $ = (s) => document.querySelector(s);

const MAX_RENDERED = 1500; // exports always contain everything

// Width targets in half-width units, which is what Google's pixel truncation
// actually tracks. See intl.js for why this beats a character count.
const TITLE_MIN = 30;
const TITLE_MAX = 60;
const DESC_MIN = 70;
const DESC_MAX = 160;

let rows = [];
let sitemapList = [];
let runAbort = null;
let metaAbort = null;
let statusAbort = null;
let hasMeta = false;
let hasStatus = false;
let hreflangReport = null;

/* ---------- issue model ---------- */

function issuesFor(row) {
  const out = [];

  // Reachability first — it changes what the other findings mean.
  if (row.statusState === "failed") out.push("unreachable");
  else if (row.status >= 500) out.push("server-error");
  else if (row.status >= 400) out.push("not-found");
  else if (row.redirectedTo) out.push("redirect");
  if (row.slow) out.push("slow");

  if (row.hreflangIssues?.some((i) => i.severity === "error")) out.push("hreflang-error");
  else if (row.hreflangIssues?.length) out.push("hreflang-warn");

  if (row.underperforming) out.push("underperforming");
  if (row.inspection && !row.inspection.indexed) out.push("not-indexed");
  if (row.inspection?.canonicalOverridden) out.push("google-canonical");
  if (row.robotsBlocked) out.push("robots-blocked");
  if (row.orphan) out.push("orphan");
  if (row.brokenLinks?.length) out.push("broken-links");
  if (row.cannibalized) out.push("cannibalized");
  if (row.queryMismatch) out.push("query-mismatch");

  if (row.metaState === "failed") out.push("failed");
  if (row.metaState !== "ok") return out;

  if (!row.title) out.push("no-title");
  else if (displayWidth(row.title) > TITLE_MAX) out.push("title-long");
  else if (displayWidth(row.title) < TITLE_MIN) out.push("title-short");

  if (!row.description) out.push("no-description");
  else if (displayWidth(row.description) > DESC_MAX) out.push("desc-long");

  if (row.dupTitle) out.push("dup-title");
  if (row.dupDescription) out.push("dup-description");
  if (/noindex/i.test(row.robots || "")) out.push("noindex");
  if (row.canonicalMismatch) out.push("canonical");
  if (!row.h1) out.push("no-h1");
  else if (row.h1Count > 1) out.push("many-h1");
  if (row.skippedLevels?.length) out.push("heading-skip");
  if (row.emptyHeadings) out.push("empty-heading");
  if (row.schemaBroken) out.push("broken-schema");
  if (row.schema?.errors) out.push("schema-errors");

  return out;
}

const ISSUE_LABELS = {
  unreachable: "unreachable",
  "server-error": "server error",
  "not-found": "404 / gone",
  redirect: "redirects",
  slow: "slow response",
  "hreflang-error": "hreflang error",
  "hreflang-warn": "hreflang warning",
  underperforming: "CTR below site median",
  "not-indexed": "not indexed by Google",
  "google-canonical": "Google chose another canonical",
  "robots-blocked": "blocked by robots.txt",
  orphan: "no internal links",
  "broken-links": "links to broken pages",
  cannibalized: "competing for the same query",
  "query-mismatch": "title misses its top query",
  failed: "page failed to load",
  "no-title": "no title",
  "title-long": "title too long",
  "title-short": "title short",
  "no-description": "no description",
  "desc-long": "description too long",
  "dup-title": "duplicate title",
  "dup-description": "duplicate description",
  noindex: "noindex",
  canonical: "canonical points elsewhere",
  "no-h1": "no H1",
  "many-h1": "multiple H1",
  "heading-skip": "skipped heading level",
  "empty-heading": "empty heading tag",
  "broken-schema": "invalid JSON-LD",
  "schema-errors": "structured data errors",
  "no-schema": "no structured data",
};

// Anything that costs indexing or clicks is severe; the rest is advisory.
const SEVERE = new Set([
  "unreachable", "server-error", "not-found", "hreflang-error", "failed",
  "not-indexed", "google-canonical", "orphan", "broken-links", "robots-blocked", "schema-errors",
  "no-title", "no-description", "noindex", "dup-title", "canonical", "broken-schema",
]);

/* ---------- small helpers ---------- */

function setStatus(text, kind = "idle") {
  const el = $("#status");
  el.textContent = text;
  el.className = `status ${kind}`;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function normalizeOrigin(raw) {
  const value = (raw || "").trim();
  if (!value) return null;
  try {
    return new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`).origin;
  } catch {
    return null;
  }
}

/* ---------- sitemap accordion ---------- */

function renderSitemaps(list) {
  const toggle = $("#mapsToggle");
  const panel = $("#mapsPanel");

  // Worth opening when there is more than one file, or when there are enough
  // URLs for the path-segment breakdown to tell you something.
  const expandable = list.length > 1 || rows.length > 20;

  panel.textContent = "";
  panel.hidden = true;
  toggle.disabled = !expandable;
  toggle.classList.toggle("interactive", expandable);
  toggle.setAttribute("aria-expanded", "false");
  if (!expandable) return;

  drawMapPanel();
}

function drawMapPanel() {
  const panel = $("#mapsPanel");
  panel.textContent = "";

  const tabs = el("div", "map-tabs");
  for (const [key, label] of [["files", "By sitemap file"], ["segments", "By path segment"]]) {
    const tab = document.createElement("button");
    tab.type = "button";
    tab.className = `map-tab${mapView === key ? " active" : ""}`;
    tab.textContent = label;
    tab.addEventListener("click", () => {
      mapView = key;
      mapSort = { key: "count", dir: "desc" };
      drawMapPanel();
    });
    tabs.appendChild(tab);
  }
  panel.appendChild(tabs);

  const data =
    mapView === "files"
      ? sitemapList
          .filter((f) => f.kind !== "failed")
          .map((f) => ({
            name: displayUrl(f.url),
            title: f.url,
            kind: f.kind,
            count: f.count,
            from: isoDate(f.kind === "index" ? f.oldestChild : f.oldestUrl) || "",
            to: isoDate(f.kind === "index" ? f.newestChild : f.newestUrl) || "",
            stale: Boolean(
              f.declaredLastmod && f.newestUrl && isoDate(f.declaredLastmod) < isoDate(f.newestUrl)
            ),
            filter: { type: "sitemap", value: f.url, label: displayUrl(f.url) },
          }))
      : segmentSummary(rows).map((g) => ({
          name: g.name,
          title: `${g.count} URLs contain /${g.name}/`,
          count: g.count,
          from: g.from,
          to: g.to,
          filter: { type: "segment", value: g.name, label: `/${g.name}/` },
        }));

  const dir = mapSort.dir === "asc" ? 1 : -1;
  data.sort((a, b) => {
    if (mapSort.key === "name") return a.name.localeCompare(b.name) * dir;
    if (mapSort.key === "count") return (a.count - b.count) * dir;
    return String(a[mapSort.key] || "").localeCompare(String(b[mapSort.key] || "")) * dir;
  });

  const table = el("table", "map-table");
  const head = document.createElement("thead");
  const headRow = document.createElement("tr");

  const columns = [
    { key: "name", label: mapView === "files" ? "Sitemap file" : "Path segment", align: "left" },
    { key: "count", label: mapView === "files" ? "URLs" : "Total URLs", align: "right" },
    { key: "from", label: "From", align: "right" },
    { key: "to", label: "To", align: "right" },
    { key: null, label: "", align: "right" },
  ];

  for (const column of columns) {
    const th = document.createElement("th");
    th.className = column.align === "right" ? "num" : "";
    if (!column.key) {
      th.textContent = column.label;
    } else {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `sort${mapSort.key === column.key ? " active" : ""}`;
      button.textContent = column.label + (mapSort.key === column.key ? (mapSort.dir === "asc" ? " \u2191" : " \u2193") : "");
      button.addEventListener("click", () => {
        mapSort = mapSort.key === column.key
          ? { key: column.key, dir: mapSort.dir === "asc" ? "desc" : "asc" }
          : { key: column.key, dir: column.key === "name" ? "asc" : "desc" };
        drawMapPanel();
      });
      th.appendChild(button);
    }
    headRow.appendChild(th);
  }
  head.appendChild(headRow);
  table.appendChild(head);

  const body = document.createElement("tbody");
  for (const entry of data.slice(0, 300)) {
    const tr = document.createElement("tr");
    if (listFilter && listFilter.type === entry.filter.type && listFilter.value === entry.filter.value) {
      tr.className = "active";
    }

    const name = document.createElement("td");
    name.className = "map-name";
    name.textContent = entry.name;
    name.title = entry.title || entry.name;
    if (entry.kind === "index") name.appendChild(el("span", "tag index", " index"));
    if (entry.stale) {
      const warn = el("span", "tag failed", " stale lastmod");
      warn.title = "The index declares an older lastmod than the newest URL in this file.";
      name.appendChild(warn);
    }
    tr.appendChild(name);

    const count = document.createElement("td");
    count.className = "num";
    count.textContent = entry.count.toLocaleString();
    tr.appendChild(count);

    for (const field of ["from", "to"]) {
      const cell = document.createElement("td");
      cell.className = "num date";
      cell.textContent = entry[field] || "—";
      tr.appendChild(cell);
    }

    const action = document.createElement("td");
    action.className = "num";
    const show = document.createElement("button");
    show.type = "button";
    show.className = "show-urls";
    const active = listFilter && listFilter.type === entry.filter.type && listFilter.value === entry.filter.value;
    show.textContent = active ? "Clear" : "Show URLs";
    show.addEventListener("click", () => {
      listFilter = active ? null : entry.filter;
      drawMapPanel();
      render();
    });
    action.appendChild(show);
    tr.appendChild(action);

    body.appendChild(tr);
  }
  table.appendChild(body);
  panel.appendChild(table);

  if (data.length > 300) {
    panel.appendChild(el("div", "listnote", `Showing the top 300 of ${data.length.toLocaleString()}.`));
  }
}

// Every distinct path segment, at any depth, with how many URLs contain it and
// the lastmod range of those URLs. On a large site this is usually a more useful
// overview than the sitemap file breakdown: it maps to sections of the site
// rather than to however the CMS happened to split its files.
function segmentSummary(list) {
  const groups = new Map();

  for (const row of list) {
    let path;
    try {
      path = new URL(row.loc).pathname;
    } catch {
      continue;
    }

    const segments = path.split("/").filter(Boolean);
    // The last segment is the page's own slug, so counting it would produce a
    // row per page rather than a section overview. Drop it, keeping the
    // directory segments — except on one-segment URLs, where that segment *is*
    // the section. A URL contributes once per distinct directory, so
    // /brakes/brake-discs/x counts toward both "brakes" and "brake-discs".
    const directories = segments.length > 1 ? segments.slice(0, -1) : segments;
    for (const segment of new Set(directories)) {
      if (!groups.has(segment)) {
        groups.set(segment, { name: segment, count: 0, dates: [] });
      }
      const group = groups.get(segment);
      group.count++;
      if (row.lastmod) group.dates.push(isoDate(row.lastmod));
    }
  }

  return [...groups.values()].map((group) => {
    group.dates.sort();
    return {
      name: group.name,
      count: group.count,
      from: group.dates[0] || "",
      to: group.dates[group.dates.length - 1] || "",
      withDates: group.dates.length,
    };
  });
}

// Three separate notions of "when did this change", which are worth keeping
// apart: what the parent index claims, what the server's header says, and what
// the URLs inside actually report.
function sitemapDates(file) {
  const facts = [];
  if (!file || file.kind === "failed") return facts;

  if (file.declaredLastmod) {
    facts.push({ label: "index says", value: isoDate(file.declaredLastmod) });
  }
  if (file.httpLastModified) {
    facts.push({ label: "server says", value: isoDate(file.httpLastModified) });
  }

  if (file.kind === "urls") {
    if (file.newestUrl) {
      facts.push({
        label: "newest URL",
        value: isoDate(file.newestUrl),
        title: file.oldestUrl ? `URLs range from ${isoDate(file.oldestUrl)} to ${isoDate(file.newestUrl)}` : "",
      });
    }
    if (file.count && !file.urlsWithLastmod) {
      facts.push({ label: "no", value: "lastmod on any URL" });
    } else if (file.urlsWithLastmod && file.urlsWithLastmod < file.count) {
      facts.push({ label: "lastmod on", value: `${file.urlsWithLastmod} of ${file.count}` });
    }
  } else if (file.kind === "index") {
    if (file.newestChild) facts.push({ label: "newest child", value: isoDate(file.newestChild) });
    if (file.count && !file.childrenWithLastmod) {
      facts.push({ label: "no", value: "lastmod on any child sitemap" });
    }
  }

  // The index's claim being older than the file's own contents is the reason a
  // child sitemap stops getting re-fetched.
  if (file.declaredLastmod && file.newestUrl && isoDate(file.declaredLastmod) < isoDate(file.newestUrl)) {
    facts.push({
      label: "stale:",
      value: "index is older than its contents",
      stale: true,
      title: `The index declares ${isoDate(file.declaredLastmod)} but this file contains URLs modified ${isoDate(file.newestUrl)}.`,
    });
  }

  return facts;
}

/* ---------- row rendering ---------- */

function widthTag(text, min, max) {
  const width = displayWidth(text);
  const chars = [...text].length;
  const tag = el("span", `len${width < min || width > max ? " warn" : ""}`, String(width));
  tag.title =
    width === chars
      ? `${width} characters (aim for ${min}–${max})`
      : `${chars} characters, ${width} display units — CJK glyphs are double width (aim for ${min}–${max})`;
  return tag;
}

function field(label, value, { empty = "— missing —", range = null, rtl = false } = {}) {
  const wrap = el("div", "meta-field");
  const tag = el("span", "meta-label", label);
  if (range && value) tag.appendChild(widthTag(value, ...range));

  const val = el("span", `meta-value${value ? "" : " empty"}`, value || empty);
  if (rtl && isRtl(value)) val.dir = "rtl";

  wrap.append(tag, val);
  return wrap;
}

function badge(text, tone = "") {
  return el("span", `badge ${tone}`, text);
}

// Drawn from serpPreviewData so the popup and the printed report can never
// disagree about what a page's result would look like.
function serpPreview(row) {
  const data = serpPreviewData(row);
  const wrap = el("div", "serp");

  wrap.appendChild(el("div", "serp-url", data.crumb));

  const title = el("div", `serp-title${data.titleMissing ? " missing" : ""}`,
    data.titleMissing ? "(no title \u2014 Google will invent one)" : data.title);
  if (isRtl(row.title)) title.dir = "rtl";
  wrap.appendChild(title);

  if (data.rating) {
    const stars = el("div", "serp-rating");
    stars.appendChild(el("span", "serp-stars", data.rating.stars));
    stars.appendChild(el("span", "serp-rating-text", data.rating.text));
    wrap.appendChild(stars);
  }

  const descLine = el("div", "serp-desc");
  if (data.date) descLine.appendChild(el("span", "serp-date", `${data.date} \u2014 `));
  if (data.descriptionMissing) {
    descLine.appendChild(el("span", "missing", "No meta description \u2014 Google will pull text from the page instead."));
  } else {
    const body = el("span", "", data.description);
    if (isRtl(row.description)) body.dir = "rtl";
    descLine.appendChild(body);
  }
  wrap.appendChild(descLine);

  if (data.faq.length) {
    const faq = el("div", "serp-faq");
    for (const question of data.faq) faq.appendChild(el("div", "serp-faq-row", question));
    wrap.appendChild(faq);
  }

  if (data.notes.length) wrap.appendChild(el("div", "serp-note", data.notes.join(" \u00b7 ")));
  return wrap;
}

// A two-column table reads far faster than a run of inline label/value pairs,
// especially once a row carries status, performance, links and metadata at once.
function metaTable(entries) {
  const table = el("table", "meta-table");
  const body = document.createElement("tbody");

  for (const entry of entries) {
    if (!entry) continue;
    const [label, value, opts = {}] = entry;
    if (opts.skipEmpty && !value) continue;

    const tr = document.createElement("tr");
    const th = document.createElement("th");
    th.textContent = label;
    if (opts.width && value) th.appendChild(widthTag(value, ...opts.width));
    tr.appendChild(th);

    const td = document.createElement("td");
    // Duck-typed rather than `instanceof Node`, so the value check doesn't
    // depend on a global that may not exist in every context.
    if (value && typeof value === "object" && value.nodeType) {
      td.appendChild(value);
    } else if (value) {
      td.textContent = value;
      if (opts.rtl && isRtl(value)) td.dir = "rtl";
      if (opts.mono) td.className = "mono";
    } else {
      td.textContent = opts.empty || "—";
      td.classList.add("empty");
    }
    tr.appendChild(td);
    body.appendChild(tr);
  }

  table.appendChild(body);
  return table;
}

// Indented outline, so a broken heading structure is visible as shape.
function headingOutline(row) {
  const wrap = el("div", "headings");

  const counts = el("div", "heading-counts");
  for (const level of [1, 2, 3, 4, 5, 6]) {
    const n = row.headingCounts?.[`h${level}`] || 0;
    const chip = el("span", `heading-chip${n ? "" : " zero"}${level === 1 && n !== 1 ? " warn" : ""}`, `H${level} ${n}`);
    counts.appendChild(chip);
  }
  counts.appendChild(el("span", "heading-total", `${row.headingTotal || 0} total`));
  wrap.appendChild(counts);

  if (row.skippedLevels?.length) {
    wrap.appendChild(
      el("div", "heading-warn", `Skipped levels: ${[...new Set(row.skippedLevels)].join(", ")}`)
    );
  }
  if (row.emptyHeadings) {
    wrap.appendChild(el("div", "heading-warn", `${row.emptyHeadings} empty heading tag${row.emptyHeadings === 1 ? "" : "s"}`));
  }

  if (row.headings?.length) {
    const list = el("div", "heading-list");
    for (const heading of row.headings.slice(0, 60)) {
      const line = el("div", `heading-line level-${heading.level}`);
      line.appendChild(el("span", "heading-tag", `H${heading.level}`));
      const text = el("span", "heading-text", heading.text || "(empty)");
      if (!heading.text) text.classList.add("empty");
      if (isRtl(heading.text)) text.dir = "rtl";
      line.appendChild(text);
      list.appendChild(line);
    }
    wrap.appendChild(list);
    if (row.headings.length > 60) {
      wrap.appendChild(el("div", "note", `Showing 60 of ${row.headings.length}.`));
    }
  }

  return wrap;
}

function metaBody(row) {
  const body = el("div", "meta-body");

  if (row.metaState === "ok") body.appendChild(serpPreview(row));

  const fmt = (n) => (n == null ? "" : n.toLocaleString());

  const statusText =
    row.statusState === "failed"
      ? row.statusError || "unreachable"
      : row.statusState
        ? `${row.status}${row.method === "GET" ? " (HEAD refused)" : ""}`
        : "";

  body.appendChild(
    metaTable([
      [ "Status", statusText, { skipEmpty: true } ],
      [ "Response", row.ms != null ? `${row.ms} ms${row.bytes ? ` · ${Math.round(row.bytes / 1024)} KB` : ""}` : "", { skipEmpty: true } ],
      row.gsc ? [ "Search Console", `${fmt(row.gsc.clicks)} clicks · ${fmt(row.gsc.impressions)} impressions · ${(row.gsc.ctr * 100).toFixed(2)}% CTR · position ${row.gsc.position.toFixed(1)}` ] : null,
      row.underperforming ? [ "CTR gap", `${(row.gsc.ctr * 100).toFixed(2)}% against a site median of ${(row.expectedCtr * 100).toFixed(2)}% for position ${row.ctrBucket} — roughly ${fmt(row.missedClicks)} missed clicks, estimated from your own data` ] : null,
      row.topQuery ? [ "Top query", `${row.topQuery.query} (${fmt(row.topQuery.impressions)} impressions, position ${row.topQuery.position.toFixed(1)})` ] : null,
      row.inspection ? [ "Google index", `${row.inspection.indexed ? "Indexed" : "Not indexed"}${row.inspection.coverage ? ` — ${row.inspection.coverage}` : ""}${row.inspection.lastCrawl ? ` · last crawled ${row.inspection.lastCrawl}` : ""}` ] : null,
      row.inspection?.canonicalOverridden ? [ "Google's canonical", `${displayUrl(row.inspection.googleCanonical)} — overrules the page's own ${displayUrl(row.inspection.userCanonical)}` ] : null,
      row.metaState === "failed" ? [ "Could not read page", row.metaError || "unknown error" ] : null,
      row.metaState === "ok" ? [ "SEO title", row.title, { width: [TITLE_MIN, TITLE_MAX], rtl: true, empty: "— missing —" } ] : null,
      row.metaState === "ok" ? [ "Meta description", row.description, { width: [DESC_MIN, DESC_MAX], rtl: true, empty: "— missing —" } ] : null,
      row.metaState === "ok" ? [ "Published", row.published, { empty: "—" } ] : null,
      row.metaState === "ok" ? [ "Modified", row.modified || isoDate(row.lastmod), { empty: "—" } ] : null,
      row.metaState === "ok" ? [ "Language", row.lang || row.ogLocale || (scriptOf(row.title) ? `${scriptOf(row.title)} (no lang attribute)` : ""), { skipEmpty: true } ] : null,
      row.words != null ? [ "Words", fmt(row.words) ] : null,
      row.canonical ? [ "Canonical", displayUrl(row.canonical), { mono: true } ] : null,
      row.robots ? [ "Robots", row.robots, { mono: true } ] : null,
      row.robotsBlocked ? [ "robots.txt", `Blocked — ${row.robotsRule}` ] : null,
      row.outLinks ? [ "Links", `${fmt(row.inlinkCount ?? 0)} inbound · ${fmt(row.internalLinkCount ?? 0)} outbound internal · ${fmt(row.externalLinkCount ?? 0)} external` ] : null,
      row.topAnchors?.length ? [ "Linked here as", row.topAnchors.map((a) => `${a.text} (${a.count})`).join(" · ") ] : null,
      row.headingTotal != null ? [ "Headings", headingOutline(row) ] : null,
      row.charset && row.charsetFrom === "meta" && row.charset !== "utf-8" ? [ "Charset", `${row.charset} (declared in meta)` ] : null,
      row.source ? [ "From sitemap", displayUrl(row.source), { mono: true } ] : null,
    ])
  );

  if (row.schema) {
    const wrap = el("div", "meta-field");
    wrap.appendChild(
      el("span", "meta-label",
        `Structured data — ${row.schema.types.join(", ") || "none found"}` +
          (row.schema.errors ? ` · ${row.schema.errors} error${row.schema.errors === 1 ? "" : "s"}` : ""))
    );
    if (row.schema.issues?.length) {
      const list = el("ul", "issue-list");
      for (const issue of row.schema.issues.slice(0, 10)) {
        list.appendChild(el("li", issue.severity === "error" ? "bad" : "", issue.message));
      }
      wrap.appendChild(list);
    }
    body.appendChild(wrap);
  }

  if (row.hreflangIssues?.length) {
    const wrap = el("div", "meta-field");
    wrap.appendChild(el("span", "meta-label", `hreflang problems (${row.hreflangIssues.length})`));
    const list = el("ul", "issue-list");
    for (const issue of row.hreflangIssues.slice(0, 12)) {
      list.appendChild(el("li", issue.severity === "error" ? "bad" : "", issue.detail));
    }
    wrap.appendChild(list);
    body.appendChild(wrap);
  }

  if (row.brokenLinks?.length) {
    const wrap = el("div", "meta-field");
    wrap.appendChild(el("span", "meta-label", `Links to broken pages (${row.brokenLinks.length})`));
    const list = el("ul", "issue-list");
    for (const link of row.brokenLinks.slice(0, 8)) {
      list.appendChild(el("li", "bad", `${displayUrl(link.to)} — ${link.status}${link.anchor ? ` (anchor: "${link.anchor}")` : ""}`));
    }
    wrap.appendChild(list);
    body.appendChild(wrap);
  }

  if (row.queries?.length) {
    const wrap = el("div", "meta-field");
    wrap.appendChild(el("span", "meta-label", `Top queries (${row.queries.length})`));
    const list = el("div", "query-list");
    for (const q of row.queries.slice(0, 6)) {
      const line = el("div", "query-row");
      line.append(
        el("span", "query-text", q.query),
        el("span", "query-metric", `${q.impressions.toLocaleString()} impr`),
        el("span", "query-metric", `pos ${q.position.toFixed(1)}`)
      );
      list.appendChild(line);
    }
    wrap.appendChild(list);
    body.appendChild(wrap);
  }

  const notes = el("div", "badges");
  if (row.modified && row.lastmod && row.modified !== isoDate(row.lastmod)) {
    notes.appendChild(badge(`sitemap lastmod says ${isoDate(row.lastmod)}`));
  }
  if (row.canonicalMismatch) notes.appendChild(badge(`canonical → ${displayUrl(row.canonical)}`, "bad"));
  if (row.metaFromRedirect) notes.appendChild(badge("metadata above describes the redirect destination"));
  if (row.orphan) notes.appendChild(badge("nothing on the site links here", "bad"));
  if (row.cannibalized) notes.appendChild(badge("competes with another page for a query"));
  if (row.queryMismatch) notes.appendChild(badge(`top query "${row.topQuery?.query}" is not in the title`));
  if (row.redirectedTo) {
    const kind = row.redirectKind?.length ? ` (${row.redirectKind.join(", ")})` : "";
    notes.appendChild(badge(`redirects → ${displayUrl(row.redirectedTo)}${kind}`));
  }
  if (/noindex/i.test(row.robots || "")) notes.appendChild(badge(`robots: ${row.robots}`, "bad"));
  if (row.dupTitle) notes.appendChild(badge("duplicate title", "bad"));
  if (row.dupDescription) notes.appendChild(badge("duplicate description"));
  if (notes.children.length) body.appendChild(notes);

  return body;
}

/* ---------- filtering ---------- */

function visibleRows() {
  const query = ($("#filterText").value || "").trim().toLowerCase();
  // Falling back to "all" matters: without it, an unset control would silently
  // render an empty list rather than everything.
  const mode = $("#filterMode").value || "all";

  let list = rows;

  // Set by "Show URLs" in the sitemap table.
  if (listFilter) {
    if (listFilter.type === "sitemap") {
      list = list.filter((row) => row.source === listFilter.value);
    } else if (listFilter.type === "branch") {
      list = list.filter((row) => listFilter.value.has(row.loc));
    } else if (listFilter.type === "segment") {
      list = list.filter((row) => {
        try {
          return new URL(row.loc).pathname.split("/").filter(Boolean).includes(listFilter.value);
        } catch {
          return false;
        }
      });
    }
  }

  if (mode !== "all") {
    list = list.filter((row) => {
      const issues = issuesFor(row);
      if (mode === "issues") return issues.some((i) => SEVERE.has(i));
      if (mode === "any-issue") return issues.length > 0;
      if (mode === "has-traffic") return (row.gsc?.impressions || 0) > 0;
      // Not counted as a per-row issue: on most sites it is true of most pages
      // and would swamp the summary and the tree.
      if (mode === "no-schema") return row.schema && !row.schema.blocks && !row.schema.hasMicrodata;
      if (mode === "no-traffic") return gscJoin && !(row.gsc?.impressions > 0);
      // The point of the Search Console join: a real problem on a page that
      // actually gets seen, rather than the same problem on a page nobody visits.
      if (mode === "traffic-issues") {
        return (row.gsc?.impressions || 0) > 0 && issues.some((i) => SEVERE.has(i));
      }
      return issues.includes(mode);
    });
  }

  if (query) {
    list = list.filter(
      (row) =>
        row.loc.toLowerCase().includes(query) ||
        (row.title || "").toLowerCase().includes(query) ||
        (row.description || "").toLowerCase().includes(query)
    );
  }

  const sort = $("#sortMode").value || "sitemap";
  if (sort === "modified") {
    list = [...list].sort((a, b) =>
      String(b.modified || b.lastmod || "").localeCompare(String(a.modified || a.lastmod || ""))
    );
  } else if (sort === "published") {
    list = [...list].sort((a, b) => String(b.published || "").localeCompare(String(a.published || "")));
  } else if (sort === "url") {
    list = [...list].sort((a, b) => a.loc.localeCompare(b.loc));
  } else if (sort === "slowest") {
    list = [...list].sort((a, b) => (b.ms ?? -1) - (a.ms ?? -1));
  } else if (sort === "impressions") {
    list = [...list].sort((a, b) => (b.gsc?.impressions || 0) - (a.gsc?.impressions || 0));
  } else if (sort === "clicks") {
    list = [...list].sort((a, b) => (b.gsc?.clicks || 0) - (a.gsc?.clicks || 0));
  } else if (sort === "opportunity") {
    list = [...list].sort((a, b) => (b.missedClicks || 0) - (a.missedClicks || 0));
  } else if (sort === "inlinks") {
    // Pages we never read have no link data, so they sort last rather than
    // masquerading as zero-inlink orphans.
    const key = (r) => (r.outLinks ? r.inlinkCount : Infinity);
    list = [...list].sort((a, b) => key(a) - key(b));
  }

  return list;
}

function render() {
  const list = $("#list");
  list.textContent = "";

  const shown = visibleRows();
  const frag = document.createDocumentFragment();

  for (const row of shown.slice(0, MAX_RENDERED)) {
    const wrap = el("div", "url-row");
    const head = document.createElement("button");
    head.type = "button";
    head.className = "url-head";

    const issues = issuesFor(row);
    const severe = issues.some((i) => SEVERE.has(i));
    // A row is only uncoloured when nothing has been checked yet; after a status
    // sweep alone it must still show that the URL is unreachable.
    const checked = row.statusState || row.metaState;
    const dotClass = !checked
      ? ""
      : row.statusState === "failed" || row.metaState === "failed"
        ? "failed"
        : severe
          ? "bad"
          : issues.length
            ? "flag"
            : "ok";
    head.appendChild(el("span", `dot ${dotClass}`));

    const text = el("span", "url-text");
    const urlLine = el("span", "url-line", displayUrl(row.loc));
    urlLine.title = row.loc;
    text.appendChild(urlLine);

    if (row.title) {
      const sub = el("span", "url-title", row.title);
      if (isRtl(row.title)) sub.dir = "rtl";
      text.appendChild(sub);
    } else if (row.metaState === "failed") {
      text.appendChild(el("span", "url-title err", row.metaError || "failed"));
    }

    head.appendChild(text);

    if (row.gsc?.impressions) {
      const metric = el("span", "row-metric", row.gsc.impressions.toLocaleString());
      metric.title = `${row.gsc.impressions.toLocaleString()} impressions, ${row.gsc.clicks.toLocaleString()} clicks`;
      head.appendChild(metric);
    }
    if (issues.length) {
      head.appendChild(el("span", "issue-count", String(issues.length)));
    }

    wrap.appendChild(head);

    if (row.metaState || row.statusState || row.hreflangIssues?.length || row.gsc || row.inspection) {
      head.classList.add("interactive");
      head.setAttribute("aria-expanded", "false");
      const body = metaBody(row);
      body.hidden = true;
      wrap.appendChild(body);
      head.addEventListener("click", () => {
        const open = body.hidden;
        body.hidden = !open;
        head.setAttribute("aria-expanded", String(open));
      });
    }

    frag.appendChild(wrap);
  }

  list.appendChild(frag);

  const scope = $("#listScope");
  if (listFilter) {
    scope.hidden = false;
    scope.textContent = "";
    scope.appendChild(el("span", "", `Showing only ${listFilter.label}`));
    const clear = document.createElement("button");
    clear.type = "button";
    clear.className = "scope-clear";
    clear.textContent = "Clear";
    clear.addEventListener("click", () => {
      listFilter = null;
      drawMapPanel();
      render();
    });
    scope.appendChild(clear);
  } else {
    scope.hidden = true;
  }

  const note = $("#listNote");
  if (!shown.length && rows.length) {
    note.hidden = false;
    note.textContent = "Nothing matches this filter.";
  } else if (shown.length > MAX_RENDERED) {
    note.hidden = false;
    note.textContent = `Showing ${MAX_RENDERED} of ${shown.length} matching. Exports include all ${rows.length}.`;
  } else {
    note.hidden = true;
  }

  $("#results").hidden = rows.length === 0;
  $("#filters").hidden = rows.length === 0;
  for (const id of ["#copy", "#csv", "#xlsx", "#json", "#pdf"]) $(id).disabled = rows.length === 0;
}

/* ---------- summary ---------- */

function renderSummary() {
  const box = $("#summary");
  box.textContent = "";

  if (!hasMeta && !hasStatus && !hreflangReport && !gscJoin) {
    box.hidden = true;
    return;
  }

  const counts = new Map();
  for (const row of rows) {
    for (const issue of issuesFor(row)) counts.set(issue, (counts.get(issue) || 0) + 1);
  }

  const checked = rows.filter((r) => r.statusState || r.metaState).length;
  const clean = rows.filter((r) => (r.statusState || r.metaState) && issuesFor(r).length === 0).length;

  const chips = [["clean", `${clean} of ${checked} clean`, "good"]];

  // When performance data is loaded, lead with the findings that cost traffic.
  if (gscJoin) {
    const withTraffic = rows.filter(
      (r) => (r.gsc?.impressions || 0) > 0 && issuesFor(r).some((i) => SEVERE.has(i))
    ).length;
    if (withTraffic) chips.push(["traffic-issues", `${withTraffic} issues on pages with traffic`, "bad"]);
    if (robotsReport?.blockedWithTraffic) {
      chips.push(["robots-blocked", `${robotsReport.blockedWithTraffic} blocked but still ranking`, "bad"]);
    }
    if (linkReport?.orphansWithTraffic) {
      chips.push(["orphan", `${linkReport.orphansWithTraffic} orphans earning impressions`, "bad"]);
    }
  }
  for (const [issue, n] of [...counts.entries()].sort((a, b) => b[1] - a[1])) {
    chips.push([issue, `${n} ${ISSUE_LABELS[issue] || issue}`, SEVERE.has(issue) ? "bad" : ""]);
  }

  for (const [key, label, tone] of chips) {
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = `chip ${tone}`;
    chip.textContent = label;
    chip.addEventListener("click", () => {
      $("#filterMode").value = key === "clean" ? "all" : key;
      render();
    });
    box.appendChild(chip);
  }

  box.hidden = false;
}

/* ---------- extraction run ---------- */

async function run() {
  const origin = normalizeOrigin($("#origin").value);
  if (!origin) return setStatus("Enter a valid domain, like example.com", "error");

  runAbort?.abort();
  runAbort = new AbortController();

  rows = [];
  sitemapList = [];
  hasMeta = false;
  hasStatus = false;
  hreflangReport = null;
  gscJoin = null;
  gscBench = null;
  cannibalReport = null;
  linkReport = null;
  linkTargetStatus = new Map();
  robotsReport = null;
  hygieneReport = null;
  robotsText = null;
  robotsUrl = "";
  listFilter = null;
  mapView = "files";
  schemaReportData = null;

  $("#run").disabled = true;
  $("#counters").hidden = false;
  $("#errorBox").hidden = true;
  $("#metaBar").hidden = true;
  $("#progress").hidden = true;
  $("#summary").hidden = true;
  $("#hreflangBox").hidden = true;
  $("#linksBox").hidden = true;
  $("#treeBox").hidden = true;
  $("#schemaBox").hidden = true;
  $("#robotsBox").hidden = true;
  $("#hygieneBox").hidden = true;
  render();
  renderSitemaps([]);
  setStatus("Looking for a sitemap…", "working");

  try {
    // robotsText comes from discover (which fetches robots.txt to find the
    // sitemap), not from crawl. Dropping it here silently disabled every
    // robots.txt check.
    const { seeds, via, robotsText: discoveredRobots } = await discover(origin, runAbort.signal);
    if (!seeds.length) {
      setStatus("No sitemap found in robots.txt or any of the usual paths.", "error");
      return;
    }

    setStatus(`Found ${seeds.length} sitemap${seeds.length > 1 ? "s" : ""} via ${via}. Reading…`, "working");

    const result = await crawl(seeds, {
      signal: runAbort.signal,
      onProgress: (p) => {
        $("#cUrls").textContent = p.urls.toLocaleString();
        $("#cMaps").textContent = p.sitemaps;
        $("#cQueue").textContent = p.queued;
      },
    });

    rows = [...result.urls].map(([loc, info]) => ({
      loc,
      lastmod: info.lastmod,
      alternates: info.alternates,
      source: info.source,
    }));
    sitemapList = result.sitemaps;

    render();
    renderSitemaps(sitemapList);

    setStatus(
      result.truncated
        ? `Stopped at ${MAX_SITEMAPS} sitemaps — ${rows.length.toLocaleString()} URLs so far.`
        : `${rows.length.toLocaleString()} URLs from ${unicodeHost(new URL(origin).hostname)}.`,
      result.truncated ? "warn" : "done"
    );

    if (result.errors.length) {
      $("#errorBox").hidden = false;
      $("#errCount").textContent = result.errors.length;
      $("#errList").textContent = result.errors.join("\n");
    }

    if (rows.length) {
      showActionBar(rows.length);
      showGscBox();
    }
    refreshHreflang();
    refreshTree();
    renderSchema();

    robotsText = discoveredRobots ?? null;
    try {
      robotsUrl = new URL("/robots.txt", origin).href;
    } catch {
      robotsUrl = "";
    }
    refreshRobots();
    hygieneReport = sitemapHygiene(rows, sitemapList, result.duplicates, origin);
    renderHygiene();
  } catch (err) {
    if (err.name !== "AbortError") setStatus(`Failed: ${err.message}`, "error");
  } finally {
    $("#run").disabled = false;
  }
}

/* ---------- status sweep ---------- */

function showActionBar(count) {
  $("#metaBar").hidden = false;
  $("#checkStatus").disabled = false;
  $("#checkStatus").textContent = `Check status (${count.toLocaleString()})`;
  $("#fetchMeta").disabled = false;
  $("#fetchMeta").textContent = `Fetch page meta (${count.toLocaleString()})`;
  $("#cancelRun").hidden = true;

  // HEAD requests are roughly an order of magnitude cheaper than fetching pages,
  // which is the whole point of offering them separately.
  const headSecs = Math.max(1, Math.ceil((count / STATUS_CONCURRENCY) * 0.25));
  const metaSecs = Math.ceil((count / META_CONCURRENCY) * 0.6);
  const fmt = (s) => (s > 90 ? `~${Math.ceil(s / 60)} min` : `~${s}s`);
  $("#metaNote").textContent = `Status ${fmt(headSecs)} · full meta ${fmt(metaSecs)}. Keep this window open.`;
}

// hreflang data can arrive from the sitemap alone, so this is safe to call at
// any point; each later pass just makes the cross-checks better informed.
function refreshHreflang() {
  const any = rows.some(
    (r) => (r.hreflangs?.length || r.alternates?.length || r.headerAlternates?.length)
  );
  hreflangReport = any ? validateHreflang(rows) : null;
  renderHreflang();
}

async function runStatus() {
  if (!rows.length) return;

  statusAbort = new AbortController();
  $("#checkStatus").disabled = true;
  $("#fetchMeta").disabled = true;
  $("#cancelRun").hidden = false;
  $("#progress").hidden = false;
  $("#progressFill").style.width = "0%";

  let pending = 0;
  const result = await sweepStatus(rows, {
    signal: statusAbort.signal,
    onProgress: ({ done, total, broken, redirects }) => {
      $("#progressFill").style.width = `${(done / total) * 100}%`;
      setStatus(
        `Checking status — ${done.toLocaleString()} of ${total.toLocaleString()}` +
          `${broken ? `, ${broken} broken` : ""}${redirects ? `, ${redirects} redirecting` : ""}.`,
        "working"
      );
      if (++pending >= 25) {
        pending = 0;
        render();
      }
    },
  });

  hasStatus = true;
  refreshHreflang();
  refreshLinks();
  refreshTree();
  render();
  renderSummary();

  $("#progress").hidden = true;
  $("#cancelRun").hidden = true;
  $("#checkStatus").disabled = false;
  $("#checkStatus").textContent = "Check status again";
  $("#fetchMeta").disabled = false;

  const parts = [];
  if (result.broken) parts.push(`${result.broken} broken`);
  if (result.redirects) parts.push(`${result.redirects} redirecting`);
  setStatus(
    result.aborted
      ? `Stopped after ${result.done.toLocaleString()} URLs.`
      : `Checked ${result.done.toLocaleString()} URLs — ${parts.length ? parts.join(", ") : "all returned 200"}.`,
    result.aborted ? "warn" : parts.length ? "warn" : "done"
  );

  statusAbort = null;
}

/* ---------- hreflang report ---------- */

function renderHreflang() {
  const section = $("#hreflangBox");
  const body = $("#hreflangBody");
  body.textContent = "";

  if (!hreflangReport || !hreflangReport.pagesWithHreflang) {
    section.hidden = true;
    return;
  }

  section.hidden = false;
  const { clusters, pagesWithHreflang, pagesWithIssues } = hreflangReport;
  $("#hreflangCount").textContent =
    `${pagesWithHreflang} page${pagesWithHreflang === 1 ? "" : "s"} with hreflang` +
    (pagesWithIssues ? `, ${pagesWithIssues} with problems` : " — no problems found");

  for (const cluster of clusters.slice(0, 40)) {
    const card = el("div", `cluster${cluster.clean ? " clean" : ""}`);

    const head = el("div", "cluster-head");
    head.appendChild(el("span", "cluster-size", `${cluster.size} pages`));
    const langs = el("span", "langs");
    for (const code of cluster.languages.slice(0, 24)) langs.appendChild(el("span", "lang-chip", code));
    head.appendChild(langs);
    card.appendChild(head);

    for (const issue of cluster.issues || []) {
      card.appendChild(el("div", `cluster-issue ${issue.severity === "error" ? "bad" : ""}`, issue.detail));
    }

    const incomplete = (cluster.members || []).filter((m) => m.missing?.length);
    for (const member of incomplete.slice(0, 8)) {
      card.appendChild(
        el("div", "cluster-issue bad", `${displayUrl(member.url)} is missing: ${member.missing.join(", ")}`)
      );
    }
    const outside = (cluster.members || []).filter((m) => m.outside);
    if (outside.length) {
      card.appendChild(
        el("div", "cluster-issue", `${outside.length} alternate${outside.length === 1 ? "" : "s"} outside this sitemap (not checked)`)
      );
    }

    body.appendChild(card);
  }

  if (clusters.length > 40) {
    body.appendChild(el("div", "listnote", `Showing 40 of ${clusters.length} hreflang sets.`));
  }
}

/* ---------- Search Console ---------- */

let gscSites = [];
let gscJoin = null;
let gscBench = null;

function gscSay(text, kind = "") {
  const note = $("#gscNote");
  note.textContent = text;
  note.className = `note ${kind}`;
}

function showGscBox() {
  $("#gscBox").hidden = false;
  if (!gscConfigured()) {
    gscSay("No OAuth client configured yet — see the Search Console section of the README, or paste a token below.");
  }
}

async function gscConnect() {
  $("#gscConnect").disabled = true;
  gscSay("Requesting access…");

  try {
    gscSites = await gscListSites();
    if (!gscSites.length) {
      gscSay("That account has no verified Search Console properties.", "bad");
      return;
    }

    const select = $("#gscSite");
    select.textContent = "";
    for (const site of gscSites) {
      const option = document.createElement("option");
      option.value = site.siteUrl;
      option.textContent = site.siteUrl;
      select.appendChild(option);
    }

    // Pre-select the property matching whatever was just extracted.
    const origin = rows.length ? new URL(rows[0].loc).origin : $("#origin").value;
    const match = matchSiteToOrigin(gscSites, normalizeOrigin(origin) || origin);
    if (match) select.value = match;

    select.hidden = false;
    $("#gscLoad").hidden = false;
    $("#gscQueries").hidden = false;
    $("#gscInspect").hidden = false;
    renderQuota(select.value);
    $("#gscSignOut").hidden = false;
    $("#gscConnect").hidden = true;
    $("#gscState").textContent = "connected";
    gscSay(
      match
        ? `${gscSites.length} propert${gscSites.length === 1 ? "y" : "ies"} available — matched this site automatically.`
        : `${gscSites.length} properties available. No obvious match for this site, so pick one.`
    );
  } catch (err) {
    gscSay(err.message, "bad");
  } finally {
    $("#gscConnect").disabled = false;
  }
}

async function gscLoad() {
  if (!rows.length) {
    gscSay("Extract a sitemap first, so there is something to join the data to.", "bad");
    return;
  }

  const siteUrl = $("#gscSite").value;
  const days = Number($("#gscRange").value) || 28;
  const range = gscDateRange(days);

  $("#gscLoad").disabled = true;
  gscSay(`Loading ${range.startDate} to ${range.endDate}…`);

  try {
    const gscRows = await gscFetchPages(siteUrl, range, {
      onProgress: ({ rows: n }) => gscSay(`Loading… ${n.toLocaleString()} URLs so far.`),
    });

    gscJoin = joinGsc(rows, gscRows);
    gscBench = benchmarkCtr(rows);
    refreshRobots();

    render();
    renderSummary();
    renderGscExtras(range);

    const { matched, unseen, totals } = gscJoin;
    gscSay(
      `${totals.clicks.toLocaleString()} clicks and ${totals.impressions.toLocaleString()} impressions over ${days} days. ` +
        `Matched ${matched.toLocaleString()} sitemap URLs; ${unseen.toLocaleString()} had no impressions.`,
      "good"
    );
    $("#gscState").textContent = `${totals.clicks.toLocaleString()} clicks, ${days}d`;
  } catch (err) {
    gscSay(err.message, "bad");
  } finally {
    $("#gscLoad").disabled = false;
  }
}

function renderGscExtras(range) {
  const bench = $("#gscBench");
  bench.textContent = "";

  if (gscBench?.usable) {
    const parts = gscBench.benchmarks.map((b) => `${b.bucket}: ${(b.ctr * 100).toFixed(1)}%`);
    bench.textContent =
      `This site's median CTR by position — ${parts.join(", ")}. ` +
      (gscBench.flagged
        ? `${gscBench.flagged} page${gscBench.flagged === 1 ? "" : "s"} fall well below their own bracket, worth roughly ${gscBench.missedTotal.toLocaleString()} clicks over ${range.days} days.`
        : "No page falls far below its bracket.");
  } else if (gscJoin) {
    bench.textContent = "Not enough pages with impressions to compare CTR by position.";
  }

  const box = $("#gscOrphans");
  box.textContent = "";
  if (!gscJoin?.orphans.length) return;

  const heading = el("div", "orphan-head",
    `${gscJoin.orphans.length.toLocaleString()} URL${gscJoin.orphans.length === 1 ? "" : "s"} getting impressions but missing from the sitemap`);
  box.appendChild(heading);

  for (const entry of gscJoin.orphans.slice(0, 25)) {
    const row = el("div", "orphan-row");
    const link = el("span", "orphan-url", displayUrl(entry.url));
    link.title = entry.url;
    row.append(link, el("span", "orphan-metric", `${entry.clicks.toLocaleString()} clicks`));
    row.append(el("span", "orphan-metric", `${entry.impressions.toLocaleString()} impr`));
    box.appendChild(row);
  }
  if (gscJoin.orphans.length > 25) {
    box.appendChild(el("div", "note", `Showing the top 25 by clicks.`));
  }
}

/* ---------- queries, indexing, links ---------- */

let cannibalReport = null;
let linkReport = null;
let linkTargetStatus = new Map();
let robotsReport = null;
let hygieneReport = null;
let robotsText = null;
let robotsUrl = "";
let listFilter = null;   // { type: "sitemap" | "segment", value, label }
let mapView = "files";
let treeLabelMode = "compact";
let treeDepth = 0;
let schemaReportData = null;   // "files" | "segments"
let mapSort = { key: "count", dir: "desc" };

async function gscLoadQueries() {
  const siteUrl = $("#gscSite").value;
  const range = gscDateRange(Number($("#gscRange").value) || 28);

  $("#gscQueries").disabled = true;
  gscSay("Loading query data…");

  try {
    const queryRows = await gscFetchQueries(siteUrl, range, {
      onProgress: ({ rows: n }) => gscSay(`Loading queries… ${n.toLocaleString()} rows.`),
    });

    const join = joinQueries(rows, queryRows);
    cannibalReport = findCannibalization(queryRows, rows);
    const align = checkQueryAlignment(rows);

    render();
    renderSummary();
    renderCannibalization();

    gscSay(
      `${queryRows.length.toLocaleString()} page/query pairs across ${join.pagesWithQueries.toLocaleString()} pages. ` +
        `${cannibalReport.conflicts.length} quer${cannibalReport.conflicts.length === 1 ? "y has" : "ies have"} more than one page competing` +
        (align.flagged ? `, ${align.flagged} title${align.flagged === 1 ? "" : "s"} miss their top query.` : "."),
      "good"
    );
  } catch (err) {
    gscSay(err.message, "bad");
  } finally {
    $("#gscQueries").disabled = false;
  }
}

function renderCannibalization() {
  const box = $("#gscCannibal");
  box.textContent = "";
  if (!cannibalReport?.conflicts.length) return;

  box.appendChild(
    el("div", "orphan-head",
      `${cannibalReport.conflicts.length} quer${cannibalReport.conflicts.length === 1 ? "y" : "ies"} with more than one of your pages competing`)
  );

  for (const conflict of cannibalReport.conflicts.slice(0, 15)) {
    const card = el("div", "cannibal");
    const head = el("div", "cannibal-head");
    head.append(
      el("span", "cannibal-query", conflict.query),
      el("span", "orphan-metric", `${conflict.totalImpressions.toLocaleString()} impr`)
    );
    card.appendChild(head);
    for (const page of conflict.pages.slice(0, 5)) {
      const line = el("div", "cannibal-page");
      line.append(
        el("span", "orphan-url", displayUrl(page.url)),
        el("span", "orphan-metric", `pos ${page.position.toFixed(1)}`),
        el("span", "orphan-metric", `${page.impressions.toLocaleString()} impr`)
      );
      card.appendChild(line);
    }
    box.appendChild(card);
  }
  if (cannibalReport.conflicts.length > 15) {
    box.appendChild(el("div", "note", "Showing the 15 with most impressions."));
  }
}

async function runInspection() {
  const siteUrl = $("#gscSite").value;
  if (!siteUrl) return gscSay("Connect and pick a property first.", "bad");

  // Inspect what is on screen, so the filter is the selection mechanism.
  const targets = visibleRows().slice(0, INSPECT_DEFAULT_BATCH);
  if (!targets.length) return gscSay("Nothing in the current view to inspect.", "bad");

  const used = await getInspectUsage(siteUrl);
  const remaining = Math.max(0, INSPECT_DAILY_QUOTA - used);
  if (!remaining) {
    gscSay(`The daily inspection quota (${INSPECT_DAILY_QUOTA}) looks used up for this property. It resets every 24 hours.`, "bad");
    return;
  }

  const batch = targets.slice(0, remaining);
  $("#gscInspect").disabled = true;
  gscSay(`Inspecting ${batch.length} URLs — Google takes a few seconds each.`);

  try {
    const result = await inspectUrls(batch, siteUrl, {
      onProgress: ({ done, total }) => gscSay(`Inspecting ${done} of ${total}…`),
    });

    render();
    renderSummary();
    await renderQuota(siteUrl);

    gscSay(
      result.quotaHit
        ? `Stopped: Google's inspection quota was hit after ${result.done}. Wait a minute for the per-minute cap, or a day for the daily one.`
        : `${result.indexed} indexed, ${result.notIndexed} not indexed${result.failed ? `, ${result.failed} failed` : ""}.`,
      result.quotaHit ? "bad" : "good"
    );
  } catch (err) {
    gscSay(err.message, "bad");
  } finally {
    $("#gscInspect").disabled = false;
  }
}

async function renderQuota(siteUrl) {
  const used = await getInspectUsage(siteUrl);
  $("#gscQuota").textContent = used
    ? `Index checks used today: roughly ${used} of ${INSPECT_DAILY_QUOTA} (a local tally, not Google's own counter).`
    : "";
}

async function runLinkCheck() {
  const { targets, total } = offSitemapTargets(rows);
  if (!targets.length) {
    setStatus("No linked URLs outside the sitemap to check.", "done");
    return;
  }

  statusAbort = new AbortController();
  $("#checkLinks").disabled = true;
  $("#cancelRun").hidden = false;
  $("#progress").hidden = false;
  $("#progressFill").style.width = "0%";

  let done = 0;
  let broken = 0;
  let cursor = 0;

  async function worker() {
    while (cursor < targets.length) {
      if (statusAbort.signal.aborted) return;
      const target = targets[cursor++];
      try {
        const result = await probeStatus(target.url, statusAbort.signal);
        linkTargetStatus.set(target.key, result);
        if (result.statusState === "failed" || result.status >= 400) broken++;
      } catch (err) {
        if (err.name === "AbortError") return;
        linkTargetStatus.set(target.key, { statusState: "failed", statusError: err.message });
        broken++;
      }
      done++;
      $("#progressFill").style.width = `${(done / targets.length) * 100}%`;
      setStatus(`Checking linked URLs — ${done} of ${targets.length}${broken ? `, ${broken} broken` : ""}.`, "working");
    }
  }

  await Promise.all(Array.from({ length: Math.min(STATUS_CONCURRENCY, targets.length) }, worker));

  refreshLinks();
  render();
  renderSummary();

  $("#progress").hidden = true;
  $("#cancelRun").hidden = true;
  $("#checkLinks").disabled = false;
  $("#checkLinks").textContent = "Check linked URLs again";

  // With a single target, name it and its status rather than saying "all fine" —
  // that phrasing hides which URL was tested and what it actually returned.
  if (done === 1) {
    const only = targets[0];
    const probed = linkTargetStatus.get(only.key);
    const state = probed?.statusState === "failed" ? probed.statusError : probed?.status;
    setStatus(`Checked ${displayUrl(only.url)} — returned ${state}.`, broken ? "warn" : "done");
  } else {
    setStatus(
      broken
        ? `${broken} of ${done} linked URLs outside the sitemap are broken. See the internal links panel.`
        : `Checked ${done} linked URLs outside the sitemap — none broken.`,
      broken ? "warn" : "done"
    );
  }

  if (total > targets.length) {
    setStatus(`Checked the ${targets.length} most-linked of ${total} URLs outside the sitemap. ${broken} broken.`, "warn");
  }

  statusAbort = null;
}

function refreshLinks() {
  const anyLinks = rows.some((r) => r.outLinks);
  if (!anyLinks) {
    linkReport = null;
    $("#linksBox").hidden = true;
  $("#treeBox").hidden = true;
  $("#schemaBox").hidden = true;
  $("#robotsBox").hidden = true;
  $("#hygieneBox").hidden = true;
    return;
  }

  linkReport = buildLinkGraph(rows, linkTargetStatus);
  const box = $("#linksBox");
  const body = $("#linksBody");
  body.textContent = "";
  box.hidden = false;

  $("#linksCount").textContent =
    `${linkReport.internalEdges.toLocaleString()} links across ${linkReport.crawled.toLocaleString()} pages` +
    (linkReport.orphansReliable ? `, ${linkReport.orphans} with none pointing in` : "");

  const { total: offSitemapCount } = offSitemapTargets(rows);
  const unchecked = offSitemapCount - linkTargetStatus.size;
  $("#checkLinks").hidden = offSitemapCount === 0;
  if (offSitemapCount && !linkTargetStatus.size) {
    $("#checkLinks").textContent = `Check linked URLs (${offSitemapCount})`;
  }

  const lines = [];
  lines.push(`Median inbound links per page: ${linkReport.medianInlinks}.`);

  if (unchecked > 0) {
    lines.push(
      `${unchecked.toLocaleString()} linked URL${unchecked === 1 ? " is" : "s are"} not in the sitemap and ${unchecked === 1 ? "has" : "have"} not been checked yet. ` +
        `Broken links almost always point at URLs a sitemap doesn't list — deleted pages, typos, stale hrefs — so use "Check linked URLs" to test them.`
    );
  }

  if (!linkReport.orphansReliable) {
    lines.push(
      `Only ${Math.round(linkReport.coverage * 100)}% of URLs were read, so orphan detection is switched off — ` +
        `a page can look unlinked simply because the page linking to it wasn't fetched. Run the full meta pass for this.`
    );
  } else if (linkReport.orphans) {
    lines.push(
      `${linkReport.orphans} page${linkReport.orphans === 1 ? " has" : "s have"} no internal links pointing at ${linkReport.orphans === 1 ? "it" : "them"}` +
        (linkReport.orphansWithTraffic
          ? (linkReport.orphans === 1
              ? ", and it still earns impressions — Google found it despite the site's structure."
              : `, and ${linkReport.orphansWithTraffic} of those still earn impressions — Google found them despite the site's structure.`)
          : ".")
    );
  }

  if (linkReport.brokenEdges) {
    lines.push(`${linkReport.brokenEdges} internal link${linkReport.brokenEdges === 1 ? " points" : "s point"} at broken pages, from ${linkReport.pagesLinkingToBroken} page${linkReport.pagesLinkingToBroken === 1 ? "" : "s"}.`);
  }
  if (linkReport.redirectEdges) {
    lines.push(`${linkReport.redirectEdges} internal link${linkReport.redirectEdges === 1 ? " points" : "s point"} at redirects, which wastes a hop on every crawl.`);
  }


  for (const line of lines) body.appendChild(el("div", "cluster-issue", line));

  renderLinkTargets(body);
  renderBrokenLinks(body);
}

// Every internal link pointing at a URL the sitemap doesn't list, with what it
// returned and which page it sits on. Shown whether or not anything is broken:
// a bare count leaves you with no way to find the link or to check the verdict.
function renderLinkTargets(body) {
  const { targets, total } = offSitemapTargets(rows);
  if (!targets.length) return;

  const section = el("div", "link-section");
  section.appendChild(
    el("div", "orphan-head",
      `${total.toLocaleString()} linked URL${total === 1 ? "" : "s"} not in the sitemap` +
        (linkTargetStatus.size ? "" : " — not checked yet"))
  );

  for (const target of targets.slice(0, 50)) {
    const probed = linkTargetStatus.get(target.key);
    const broken = probed && (probed.statusState === "failed" || probed.status >= 400);

    const row = el("div", `target-row${broken ? " bad" : ""}`);
    const url = el("span", "target-url", displayUrl(target.url));
    url.title = target.url;

    const state = probed
      ? probed.statusState === "failed"
        ? probed.statusError || "failed"
        : String(probed.status) + (probed.redirectedTo ? ` → ${displayUrl(probed.redirectedTo)}` : "")
      : "not checked";

    row.append(url, el("span", `target-status${broken ? " bad" : ""}`, state));
    section.appendChild(row);

    // The anchor text is what makes a link findable in a page editor.
    for (const source of target.sources.slice(0, 5)) {
      const line = el("div", "target-source");
      line.textContent = `linked from ${displayUrl(source.from)}` + (source.anchor ? ` — anchor text: "${source.anchor}"` : "");
      line.title = source.from;
      section.appendChild(line);
    }
  }

  if (total > targets.length) {
    section.appendChild(el("div", "note", `Showing the ${targets.length} most-linked of ${total}.`));
  }
  body.appendChild(section);
}

// Broken links whose target *is* in the sitemap, listed the same way.
function renderBrokenLinks(body) {
  const offenders = rows.filter((r) => r.brokenLinks?.some((b) => !b.offSitemap));
  if (!offenders.length) return;

  const section = el("div", "link-section");
  const count = offenders.reduce((n, r) => n + r.brokenLinks.filter((b) => !b.offSitemap).length, 0);
  section.appendChild(el("div", "orphan-head", `${count} link${count === 1 ? "" : "s"} to broken pages in the sitemap`));

  for (const row of offenders.slice(0, 30)) {
    for (const link of row.brokenLinks.filter((b) => !b.offSitemap).slice(0, 5)) {
      const line = el("div", "target-row bad");
      const url = el("span", "target-url", displayUrl(link.to));
      url.title = link.to;
      line.append(url, el("span", "target-status bad", String(link.status)));
      section.appendChild(line);
      const src = el("div", "target-source");
      src.textContent = `linked from ${displayUrl(row.loc)}` + (link.anchor ? ` — anchor text: "${link.anchor}"` : "");
      section.appendChild(src);
    }
  }
  body.appendChild(section);
}

/* ---------- URL tree ---------- */

function refreshTree() {
  const box = $("#treeBox");
  if (!rows.length) {
    box.hidden = true;
    return;
  }
  box.hidden = false;

  const controls = $("#treeControls");
  controls.textContent = "";

  for (const [mode, label] of [["compact", "Compact"], ["full", "Full path"]]) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = treeLabelMode === mode ? "primary" : "";
    button.textContent = label;
    button.addEventListener("click", () => {
      treeLabelMode = mode;
      refreshTree();
    });
    controls.appendChild(button);
  }

  const depth = document.createElement("select");
  for (const [value, label] of [[0, "All depths"], [2, "2 levels"], [3, "3 levels"], [4, "4 levels"], [5, "5 levels"]]) {
    const option = document.createElement("option");
    option.value = String(value);
    option.textContent = label;
    if (treeDepth === value) option.selected = true;
    depth.appendChild(option);
  }
  depth.addEventListener("change", (e) => {
    treeDepth = Number(e.target.value) || 0;
    refreshTree();
  });
  controls.appendChild(depth);

  const save = document.createElement("button");
  save.type = "button";
  save.textContent = "Download SVG";
  save.addEventListener("click", () => {
    const source = treeSvgString();
    if (source) download(`${siteSlug()}-url-tree-${stamp()}.svg`, source, "image/svg+xml");
  });
  controls.appendChild(save);

  buildTreeInto($("#treeBody"));

  $("#treeCount").textContent = treeSummaryText();
}

// Serialised with its colours inlined, so the same markup works in a downloaded
// file and inside the printable report.
function treeSvgString() {
  const svg = $("#treeBody").querySelector("svg");
  if (!svg) return "";
  {
    const clone = svg.cloneNode(true);
    const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
    style.textContent = `
      .tree-edge { fill: none; stroke: #b9c0cc; stroke-width: 1; }
      .tree-node circle { stroke: #fff; stroke-width: 1.5; }
      .tree-node text { font: 11px system-ui, sans-serif; fill: #14171c; }
      .tree-node.ok circle { fill: #2f7d32; }
      .tree-node.warn circle { fill: #b45309; }
      .tree-node.bad circle { fill: #b42318; }
      .tree-node.more circle { fill: #98a2b3; }
      .tree-node.more text { fill: #697280; font-style: italic; }`;
    clone.insertBefore(style, clone.firstChild);
    clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    return new XMLSerializer().serializeToString(clone);
  }
}

let lastTreeSummary = "";
function treeSummaryText() {
  return lastTreeSummary;
}

function buildTreeInto(body) {
  const root = buildUrlTree(rows, { labelMode: treeLabelMode, maxDepth: treeDepth });
  scoreTree(root, issuesFor, SEVERE);
  const layout = layoutTree(root);

  lastTreeSummary =
    `${layout.nodes.length} nodes` +
    (root.problems ? `, ${root.problems} URL${root.problems === 1 ? "" : "s"} with issues` : ", no issues") +
    (layout.truncated ? " (truncated)" : "");

  body.textContent = "";
  body.appendChild(
    renderTreeSvg(layout, {
      onSelect: (node) => {
        const branch = collectRows(node);
        if (!branch.length) return;
        const set = new Set(branch.map((r) => r.loc));
        // Compare on a stable key, not the display label — the label carries a
        // count appended to it and would never match on the second click.
        const key = `${node.depth}|${node.label}`;
        const same = listFilter?.type === "branch" && listFilter.key === key;
        listFilter = same ? null : { type: "branch", key, value: set, label: `${node.label} (${branch.length})` };
        refreshTree();
        render();
      },
    })
  );
}

/* ---------- structured data ---------- */

function renderSchema() {
  const box = $("#schemaBox");
  const body = $("#schemaBody");
  body.textContent = "";

  schemaReportData = rows.some((r) => r.schema) ? schemaReport(rows) : null;

  if (!schemaReportData) {
    // Visible but empty is better than absent: otherwise the panel just looks
    // missing and there is no hint that a meta pass is what fills it.
    box.hidden = rows.length === 0;
    $("#schemaCount").textContent = "not checked yet";
    body.appendChild(
      el("div", "cluster-issue", 'Run "Fetch page meta" to read and validate the structured data on each page.')
    );
    return;
  }

  box.hidden = false;
  const report = schemaReportData;

  $("#schemaCount").textContent = report.pagesWithErrors
    ? `${report.pagesWithErrors} of ${report.checked} pages have errors`
    : `${report.pagesWithSchema} of ${report.checked} pages have structured data`;

  const summary = [];
  summary.push(`${report.pagesWithSchema.toLocaleString()} page${report.pagesWithSchema === 1 ? "" : "s"} carry JSON-LD.`);
  if (report.pagesWithout) {
    summary.push(`${report.pagesWithout.toLocaleString()} have none at all.`);
  }
  if (report.microdataOnly) {
    summary.push(`${report.microdataOnly.toLocaleString()} use microdata or RDFa instead, which isn't validated here.`);
  }
  body.appendChild(el("div", "cluster-issue", summary.join(" ")));

  if (report.types.length) {
    const chips = el("div", "summary");
    for (const { type, count } of report.types.slice(0, 30)) {
      chips.appendChild(el("span", "chip", `${type} × ${count}`));
    }
    body.appendChild(chips);
  }

  // Errors first: those cost rich-result eligibility outright. Warnings are
  // Google's recommendations, which weaken the result rather than block it.
  for (const issue of report.issues.slice(0, 40)) {
    const line = el("div", `cluster-issue ${issue.severity === "error" ? "bad" : ""}`,
      `${issue.count.toLocaleString()} page${issue.count === 1 ? "" : "s"}: ${issue.message}`);
    body.appendChild(line);
    for (const example of issue.examples.slice(0, 3)) {
      const sample = el("div", "target-source", displayUrl(example));
      sample.title = example;
      body.appendChild(sample);
    }
  }
  if (report.issues.length > 40) {
    body.appendChild(el("div", "note", `Showing 40 of ${report.issues.length} distinct findings.`));
  }
}

/* ---------- robots.txt ---------- */

// The rules the tool applied and the file the site actually serves should never
// be something you have to take on trust, so the raw file is always one click
// away — including when the fetch failed, which is exactly when you need it.
function robotsControls() {
  const bar = el("div", "robots-bar");

  if (robotsText) {
    const view = document.createElement("button");
    view.type = "button";
    view.textContent = $("#robotsRaw") && !$("#robotsRaw").hidden ? "Hide contents" : "View contents";
    view.addEventListener("click", () => {
      const raw = $("#robotsRaw");
      raw.hidden = !raw.hidden;
      view.textContent = raw.hidden ? "View contents" : "Hide contents";
    });
    bar.appendChild(view);

    const copy = document.createElement("button");
    copy.type = "button";
    copy.textContent = "Copy";
    copy.addEventListener("click", async () => {
      await navigator.clipboard.writeText(robotsText);
      copy.textContent = "Copied";
      setTimeout(() => (copy.textContent = "Copy"), 1500);
    });
    bar.appendChild(copy);
  }

  if (robotsUrl) {
    const open = document.createElement("button");
    open.type = "button";
    open.textContent = "Open in tab";
    open.title = robotsUrl;
    open.addEventListener("click", () => {
      if (chrome?.tabs?.create) chrome.tabs.create({ url: robotsUrl });
      else window.open(robotsUrl, "_blank", "noopener");
    });
    bar.appendChild(open);

    bar.appendChild(el("span", "note", displayUrl(robotsUrl)));
  }

  return bar;
}

// Renders the file as served, marking the lines that actually blocked something
// so the rule and its consequence are visible together.
function robotsRaw() {
  const pre = el("pre", "robots-raw");
  pre.id = "robotsRaw";
  pre.hidden = true;

  const blocking = new Map();
  for (const group of robotsReport?.byRule || []) blocking.set(group.pattern, group.count);

  const lines = String(robotsText || "").split(/\r?\n/);
  for (const line of lines.slice(0, 2000)) {
    const row = el("div", "robots-line");
    const rule = /^\s*disallow\s*:\s*(\S+)/i.exec(line);
    const hits = rule ? blocking.get(rule[1]) : null;

    if (/^\s*#/.test(line)) row.classList.add("comment");
    if (hits) {
      row.classList.add("blocking");
      row.appendChild(el("span", "", line));
      row.appendChild(el("span", "robots-hits", `blocks ${hits} sitemap URL${hits === 1 ? "" : "s"}`));
    } else {
      row.textContent = line || "\u00a0";
    }
    pre.appendChild(row);
  }

  if (lines.length > 2000) {
    pre.appendChild(el("div", "robots-line comment", `… ${lines.length - 2000} more lines`));
  }
  return pre;
}

function refreshRobots() {
  robotsReport = checkRobots(rows, robotsText);

  const box = $("#robotsBox");
  const body = $("#robotsBody");
  body.textContent = "";

  if (!robotsReport.available) {
    box.hidden = false;
    $("#robotsCount").textContent = "could not be read";
    body.appendChild(
      el("div", "cluster-issue",
        `Nothing was returned from ${displayUrl(robotsUrl)}, so no rules could be checked. ` +
          "That usually means the file is missing or the request failed — open it below to see for yourself.")
    );
    body.appendChild(robotsControls());
    return;
  }

  box.hidden = false;
  $("#robotsCount").textContent = robotsReport.blocked
    ? `${robotsReport.blocked.toLocaleString()} sitemap URL${robotsReport.blocked === 1 ? "" : "s"} blocked`
    : "nothing in the sitemap is blocked";

  body.appendChild(
    el("div", "cluster-issue",
      `Evaluated as ${robotsReport.agent} against the "${robotsReport.matchedAgent || "none"}" group ` +
        `(${robotsReport.rules} rule${robotsReport.rules === 1 ? "" : "s"}), ` +
        `${robotsReport.declaredSitemaps} sitemap${robotsReport.declaredSitemaps === 1 ? "" : "s"} declared.`)
  );

  body.appendChild(robotsControls());
  body.appendChild(robotsRaw());

  if (!robotsReport.blocked) return;

  // Submitting a URL and blocking it are contradictory instructions, and the
  // page itself gives no hint that anything is wrong.
  body.appendChild(
    el("div", "cluster-issue bad",
      `These URLs are in the sitemap and blocked by robots.txt. Google is being told to index them and not to crawl them at the same time.`)
  );

  if (robotsReport.blockedWithTraffic) {
    body.appendChild(
      el("div", "cluster-issue bad",
        `${robotsReport.blockedWithTraffic} of them ${robotsReport.blockedWithTraffic === 1 ? "still gets" : "still get"} impressions — Google is showing ${robotsReport.blockedWithTraffic === 1 ? "a page" : "pages"} it was told not to crawl, so it cannot read ${robotsReport.blockedWithTraffic === 1 ? "its title or description" : "their titles or descriptions"}.`)
    );
  }

  for (const group of robotsReport.byRule.slice(0, 10)) {
    const card = el("div", "cluster");
    const head = el("div", "cluster-head");
    head.append(
      el("span", "cannibal-query", `Disallow: ${group.pattern}`),
      el("span", "orphan-metric", `${group.count.toLocaleString()} URL${group.count === 1 ? "" : "s"}`)
    );
    card.appendChild(head);
    for (const example of group.examples) {
      const line = el("div", "target-source");
      line.textContent = displayUrl(example);
      line.title = example;
      card.appendChild(line);
    }
    body.appendChild(card);
  }
}

/* ---------- sitemap hygiene ---------- */

function renderHygiene() {
  const box = $("#hygieneBox");
  const body = $("#hygieneBody");
  body.textContent = "";

  if (!hygieneReport?.issues.length) {
    box.hidden = false;
    $("#hygieneCount").textContent = "no problems found";
    body.appendChild(el("div", "cluster-issue", "The sitemap files themselves look well-formed."));
    return;
  }

  box.hidden = false;
  const { errors, warnings } = hygieneReport;
  $("#hygieneCount").textContent =
    [errors ? `${errors} error${errors === 1 ? "" : "s"}` : "", warnings ? `${warnings} warning${warnings === 1 ? "" : "s"}` : ""]
      .filter(Boolean)
      .join(", ");

  for (const issue of hygieneReport.issues) {
    body.appendChild(el("div", `cluster-issue ${issue.severity === "error" ? "bad" : ""}`, issue.detail));
    for (const example of issue.examples) {
      body.appendChild(el("div", "target-source", example));
    }
  }
}

/* ---------- meta run ---------- */

function showMetaBar(count) {
  showActionBar(count);
}

async function runMeta() {
  if (!rows.length) return;

  metaAbort = new AbortController();
  $("#fetchMeta").disabled = true;
  $("#checkStatus").disabled = true;
  $("#cancelRun").hidden = false;
  $("#progress").hidden = false;
  $("#progressFill").style.width = "0%";

  // Repainting per page would thrash a long list, so batch redraws.
  let pending = 0;

  const result = await fetchAllMeta(rows, {
    signal: metaAbort.signal,
    onProgress: ({ done, total, failed }) => {
      $("#progressFill").style.width = `${(done / total) * 100}%`;
      setStatus(`Reading pages — ${done.toLocaleString()} of ${total.toLocaleString()}${failed ? `, ${failed} failed` : ""}.`, "working");
      if (++pending >= 20) {
        pending = 0;
        markDuplicates(rows);
        render();
      }
    },
  });

  hasMeta = true;
  markDuplicates(rows);
  refreshHreflang();
  refreshLinks();
  refreshTree();
  renderSchema();
  render();
  renderSummary();

  $("#progress").hidden = true;
  $("#cancelRun").hidden = true;
  $("#fetchMeta").disabled = false;
  $("#checkStatus").disabled = false;
  $("#fetchMeta").textContent = "Fetch page meta again";

  const severe = rows.filter((r) => issuesFor(r).some((i) => SEVERE.has(i))).length;
  setStatus(
    result.aborted
      ? `Stopped after ${result.done.toLocaleString()} pages.`
      : `Read ${result.done.toLocaleString()} pages — ${severe ? `${severe} need attention` : "no major issues"}.`,
    result.aborted ? "warn" : severe ? "warn" : "done"
  );

  metaAbort = null;
}

/* ---------- export ---------- */

function download(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  if (chrome?.downloads?.download) {
    chrome.downloads.download({ url, filename: name });
  } else {
    const a = Object.assign(document.createElement("a"), { href: url, download: name });
    document.body.appendChild(a);
    a.click();
    a.remove();
  }
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

function csvCell(v) {
  const s = String(v ?? "");
  // Spreadsheets treat a leading =, +, - or @ as a formula; prefix to neutralize.
  const safe = /^[=+\-@]/.test(s) ? `'${s}` : s;
  return `"${safe.replace(/"/g, '""')}"`;
}

function stamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
}

function siteSlug() {
  try {
    return unicodeHost(new URL(rows[0].loc).hostname).replace(/[^\w.-]/g, "-");
  } catch {
    return "site";
  }
}

function buildCsv(list) {
  if (!hasMeta && !hasStatus && !gscJoin) {
    return (
      "\ufeff" +
      ["url,lastmod", ...list.map((r) => [r.loc, r.lastmod].map(csvCell).join(","))].join("\r\n")
    );
  }

  const header = [
    "url", "sitemap_file", "clicks", "impressions", "ctr", "avg_position", "site_median_ctr", "est_missed_clicks",
    "top_query", "top_query_impressions", "indexed", "coverage_state", "last_crawled",
    "google_canonical", "robots_blocked", "robots_rule",
    "h1_count", "h2_count", "h3_count", "h4_count", "h5_count", "h6_count",
    "headings_total", "skipped_heading_levels", "schema_types", "schema_errors", "schema_warnings",
    "inbound_links", "outbound_internal_links", "broken_links_from_page",
    "status", "response_ms", "redirects_to", "redirect_type", "content_type",
    "seo_title", "title_width", "meta_description", "description_width",
    "date_published", "date_modified", "sitemap_lastmod", "h1", "h1_count",
    "lang", "hreflang_count", "hreflang_problems", "canonical", "canonical_mismatch",
    "robots", "schema_type", "words", "charset", "issues",
  ];

  const body = list.map((r) =>
    [
      r.loc,
      r.source || "",
      r.gsc?.clicks ?? "",
      r.gsc?.impressions ?? "",
      r.gsc ? (r.gsc.ctr * 100).toFixed(2) + "%" : "",
      r.gsc ? r.gsc.position.toFixed(1) : "",
      r.expectedCtr != null ? (r.expectedCtr * 100).toFixed(2) + "%" : "",
      r.missedClicks || "",
      r.topQuery?.query || "",
      r.topQuery?.impressions ?? "",
      r.inspection ? (r.inspection.indexed ? "yes" : "no") : "",
      r.inspection?.coverage || "",
      r.inspection?.lastCrawl || "",
      r.inspection?.canonicalOverridden ? r.inspection.googleCanonical : "",
      r.robotsBlocked ? "yes" : "",
      r.robotsRule || "",
      r.headingCounts?.h1 ?? "",
      r.headingCounts?.h2 ?? "",
      r.headingCounts?.h3 ?? "",
      r.headingCounts?.h4 ?? "",
      r.headingCounts?.h5 ?? "",
      r.headingCounts?.h6 ?? "",
      r.headingTotal ?? "",
      [...new Set(r.skippedLevels || [])].join("; "),
      (r.schema?.types || []).join("; "),
      r.schema?.errors ?? "",
      r.schema?.warnings ?? "",
      r.outLinks ? r.inlinkCount : "",
      r.internalLinkCount ?? "",
      r.brokenLinks?.length || "",
      r.statusState === "failed" ? `error: ${r.statusError}` : r.status ?? "",
      r.ms ?? "",
      r.redirectedTo || "",
      (r.redirectKind || []).join("; "),
      r.contentType || "",
      r.title,
      r.title ? displayWidth(r.title) : "",
      r.description,
      r.description ? displayWidth(r.description) : "",
      r.published,
      r.modified,
      r.lastmod,
      r.h1,
      r.h1Count ?? "",
      r.lang,
      (r.hreflangs || []).length + (r.alternates || []).length,
      (r.hreflangIssues || []).map((i) => i.detail).join("; "),
      r.canonical,
      r.canonicalMismatch ? "yes" : "",
      r.robots,
      r.schemaType,
      r.words ?? "",
      r.charset,
      issuesFor(r).map((i) => ISSUE_LABELS[i] || i).join("; "),
    ].map(csvCell).join(",")
  );

  // BOM so Excel reads UTF-8 titles correctly; CRLF for the same reason.
  return "\ufeff" + [header.join(","), ...body].join("\r\n");
}

/* ---------- workbook export ---------- */

const MAX_SHEET_ROWS = 50000;

function cap(list, limit = MAX_SHEET_ROWS) {
  return list.length > limit ? list.slice(0, limit) : list;
}

// One tab per data set. A CSV can only ever be one flat table, which is why the
// full export is a workbook: the query, heading and link data are one-to-many
// against a URL and cannot share a single sheet without duplicating rows.
function buildWorkbookSheets() {
  const sheets = [];
  const site = (() => {
    try {
      return unicodeHost(new URL(rows[0].loc).hostname);
    } catch {
      return "";
    }
  })();

  /* Summary */
  const issueTally = new Map();
  for (const row of rows) for (const issue of issuesFor(row)) issueTally.set(issue, (issueTally.get(issue) || 0) + 1);

  const summary = [
    ["Sitemap Extractor report"],
    ["Site", site],
    ["Generated", new Date().toISOString()],
    [],
    ["URLs in sitemap", rows.length],
    ["Sitemap files", sitemapList.filter((f) => f.kind !== "failed").length],
    ["Pages read", rows.filter((r) => r.metaState === "ok").length],
    ["URLs status-checked", rows.filter((r) => r.statusState).length],
  ];
  if (gscJoin) {
    summary.push([], ["Search Console clicks", gscJoin.totals.clicks], ["Search Console impressions", gscJoin.totals.impressions],
      ["URLs with no impressions", gscJoin.unseen], ["URLs earning impressions but not in sitemap", gscJoin.orphans.length]);
  }
  if (robotsReport?.available) summary.push([], ["robots.txt rules", robotsReport.rules], ["Sitemap URLs blocked by robots.txt", robotsReport.blocked]);
  if (linkReport) summary.push([], ["Internal links", linkReport.internalEdges], ["Orphan pages", linkReport.orphans], ["Links to broken pages", linkReport.brokenEdges]);
  summary.push([], ["Issue", "Pages affected"]);
  for (const [issue, count] of [...issueTally.entries()].sort((a, b) => b[1] - a[1])) {
    summary.push([ISSUE_LABELS[issue] || issue, count]);
  }
  sheets.push({ name: "Summary", rows: summary });

  /* URLs — the flat table, same columns as the CSV */
  const csv = buildCsv(rows);
  const csvRows = parseCsvRows(csv);
  sheets.push({ name: "URLs", rows: cap(csvRows) });

  /* Sitemap files */
  sheets.push({
    name: "Sitemaps",
    rows: [
      ["sitemap_file", "type", "urls", "index_declared_lastmod", "http_last_modified", "oldest_inside", "newest_inside", "bytes"],
      ...sitemapList.map((f) => [
        f.url, f.kind, f.count ?? "", isoDate(f.declaredLastmod || ""), f.httpLastModified || "",
        isoDate(f.oldestUrl || f.oldestChild || ""), isoDate(f.newestUrl || f.newestChild || ""), f.bytes ?? "",
      ]),
    ],
  });

  /* Sitemap hygiene */
  if (hygieneReport?.issues.length) {
    sheets.push({
      name: "Sitemap hygiene",
      rows: [["severity", "check", "detail", "examples"],
        ...hygieneReport.issues.map((i) => [i.severity, i.code, i.detail, (i.examples || []).join(" | ")])],
    });
  }

  /* robots.txt */
  if (robotsReport?.available) {
    const robotsRows = [["pattern", "urls_blocked", "examples"],
      ...robotsReport.byRule.map((g) => [g.pattern, g.count, g.examples.join(" | ")])];
    robotsRows.push([], ["url", "blocked", "rule"]);
    for (const row of rows) if (row.robotsBlocked) robotsRows.push([row.loc, "yes", row.robotsRule]);
    sheets.push({ name: "robots.txt", rows: cap(robotsRows) });
  }

  /* Structured data */
  if (rows.some((r) => r.schema)) {
    sheets.push({
      name: "Structured data",
      rows: cap([["url", "types", "blocks", "errors", "warnings", "issues"],
        ...rows.filter((r) => r.schema).map((r) => [
          r.loc, (r.schema.types || []).join("; "), r.schema.blocks ?? "", r.schema.errors ?? "", r.schema.warnings ?? "",
          (r.schema.issues || []).map((i) => `[${i.severity}] ${i.message}`).join(" | "),
        ])]),
    });
    if (schemaReportData?.issues.length) {
      sheets.push({
        name: "Schema issues",
        rows: [["severity", "pages", "message", "examples"],
          ...schemaReportData.issues.map((i) => [i.severity, i.count, i.message, i.examples.join(" | ")])],
      });
    }
  }

  /* Headings — one row per heading, which is why it cannot live in the URL sheet */
  const headingRows = [["url", "level", "heading"]];
  for (const row of rows) {
    for (const heading of row.headings || []) headingRows.push([row.loc, `H${heading.level}`, heading.text]);
  }
  if (headingRows.length > 1) sheets.push({ name: "Headings", rows: cap(headingRows) });

  /* Search Console */
  if (gscJoin) {
    sheets.push({
      name: "Search Console",
      rows: cap([["url", "clicks", "impressions", "ctr", "avg_position", "site_median_ctr", "est_missed_clicks"],
        ...rows.filter((r) => r.gsc).map((r) => [
          r.loc, r.gsc.clicks, r.gsc.impressions, Number((r.gsc.ctr * 100).toFixed(2)), Number(r.gsc.position.toFixed(1)),
          r.expectedCtr != null ? Number((r.expectedCtr * 100).toFixed(2)) : "", r.missedClicks || "",
        ])]),
    });
    if (gscJoin.orphans.length) {
      sheets.push({
        name: "Not in sitemap",
        rows: cap([["url", "clicks", "impressions", "ctr", "avg_position"],
          ...gscJoin.orphans.map((o) => [o.url, o.clicks, o.impressions, Number((o.ctr * 100).toFixed(2)), Number(o.position.toFixed(1))])]),
      });
    }
  }

  /* Queries */
  const queryRows = [["url", "query", "clicks", "impressions", "ctr", "position"]];
  for (const row of rows) {
    for (const q of row.queries || []) {
      queryRows.push([row.loc, q.query, q.clicks, q.impressions, Number((q.ctr * 100).toFixed(2)), Number(q.position.toFixed(1))]);
    }
  }
  if (queryRows.length > 1) sheets.push({ name: "Queries", rows: cap(queryRows) });

  if (cannibalReport?.conflicts.length) {
    const rowsOut = [["query", "total_impressions", "competing_url", "impressions", "position"]];
    for (const conflict of cannibalReport.conflicts) {
      for (const page of conflict.pages) {
        rowsOut.push([conflict.query, conflict.totalImpressions, page.url, page.impressions, Number(page.position.toFixed(1))]);
      }
    }
    sheets.push({ name: "Cannibalisation", rows: cap(rowsOut) });
  }

  /* hreflang */
  const hreflangRows = [["url", "severity", "code", "detail"]];
  for (const row of rows) {
    for (const issue of row.hreflangIssues || []) hreflangRows.push([row.loc, issue.severity, issue.code, issue.detail]);
  }
  if (hreflangRows.length > 1) sheets.push({ name: "hreflang", rows: cap(hreflangRows) });

  /* Links */
  if (linkReport) {
    const brokenRows = [["from_url", "to_url", "anchor_text", "status", "in_sitemap"]];
    for (const row of rows) {
      for (const link of row.brokenLinks || []) {
        brokenRows.push([row.loc, link.to, link.anchor || "", String(link.status), link.offSitemap ? "no" : "yes"]);
      }
    }
    if (brokenRows.length > 1) sheets.push({ name: "Broken links", rows: cap(brokenRows) });

    const orphanRows = [["url", "inbound_links", "impressions"]];
    for (const row of rows) if (row.orphan) orphanRows.push([row.loc, row.inlinkCount ?? 0, row.gsc?.impressions ?? ""]);
    if (orphanRows.length > 1) sheets.push({ name: "Orphans", rows: cap(orphanRows) });
  }

  /* Index inspection */
  if (rows.some((r) => r.inspection)) {
    sheets.push({
      name: "Index status",
      rows: cap([["url", "indexed", "coverage", "last_crawled", "google_canonical", "user_canonical", "robots_state"],
        ...rows.filter((r) => r.inspection).map((r) => [
          r.loc, r.inspection.indexed ? "yes" : "no", r.inspection.coverage, r.inspection.lastCrawl,
          r.inspection.googleCanonical, r.inspection.userCanonical, r.inspection.robotsState,
        ])]),
    });
  }

  return sheets;
}

// The CSV is already assembled and correct, so the URL sheet reuses it rather
// than duplicating 50 columns of field mapping.
function parseCsvRows(text) {
  const out = [];
  let row = [];
  let field = "";
  let quoted = false;
  const body = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;

  for (let i = 0; i < body.length; i++) {
    const ch = body[i];
    if (quoted) {
      if (ch === '"') {
        if (body[i + 1] === '"') {
          field += '"';
          i++;
        } else quoted = false;
      } else field += ch;
      continue;
    }
    if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      out.push(row);
      row = [];
      field = "";
    } else if (ch !== "\r") field += ch;
  }
  if (field || row.length) {
    row.push(field);
    out.push(row);
  }

  // Numeric-looking cells become real numbers so the sheet sorts and totals.
  return out.map((r) =>
    r.map((cell) => {
      if (cell === "") return "";
      const n = Number(cell);
      return Number.isFinite(n) && cell.trim() !== "" && !/^0\d/.test(cell) ? n : cell;
    })
  );
}

/* ---------- printable report ---------- */

// No cap: the report is meant to be the complete record, with every URL and
// every affected URL listed under each finding.


const REPORT_MAX_ROWS = 40;          // for the summary tables at the front
const REPORT_HEADINGS_PER_URL = 40;

// Trimmed copy of a row: everything the report renders, without the bulk it does
// not (outbound link lists, inbound sources), which would multiply payload size
// for no benefit.
function reportRow(row) {
  return {
    loc: row.loc, source: row.source, lastmod: row.lastmod,
    title: row.title, description: row.description,
    published: row.published, modified: row.modified,
    lang: row.lang, ogLocale: row.ogLocale, words: row.words,
    canonical: row.canonical, canonicalMismatch: row.canonicalMismatch,
    robots: row.robots, robotsBlocked: row.robotsBlocked, robotsRule: row.robotsRule,
    charset: row.charset, charsetFrom: row.charsetFrom,
    status: row.status, statusState: row.statusState, statusError: row.statusError,
    method: row.method, ms: row.ms, bytes: row.bytes,
    redirectedTo: row.redirectedTo, redirectKind: row.redirectKind,
    metaState: row.metaState, metaError: row.metaError, metaFromRedirect: row.metaFromRedirect,
    h1: row.h1, h1Count: row.h1Count,
    headingCounts: row.headingCounts, headingTotal: row.headingTotal,
    headings: (row.headings || []).slice(0, REPORT_HEADINGS_PER_URL),
    skippedLevels: row.skippedLevels, emptyHeadings: row.emptyHeadings,
    inlinkCount: row.inlinkCount, internalLinkCount: row.internalLinkCount,
    externalLinkCount: row.externalLinkCount, topAnchors: row.topAnchors,
    orphan: row.orphan, brokenLinks: row.brokenLinks,
    dupTitle: row.dupTitle, dupDescription: row.dupDescription,
    hreflangIssues: row.hreflangIssues,
    schema: row.schema
      ? { types: row.schema.types, blocks: row.schema.blocks, errors: row.schema.errors,
          warnings: row.schema.warnings, issues: row.schema.issues, rich: row.schema.rich }
      : null,
    gsc: row.gsc, expectedCtr: row.expectedCtr, ctrBucket: row.ctrBucket,
    missedClicks: row.missedClicks, underperforming: row.underperforming,
    queries: row.queries, topQuery: row.topQuery,
    cannibalized: row.cannibalized, queryMismatch: row.queryMismatch,
    inspection: row.inspection,
    issues: issuesFor(row).map((i) => ({ key: i, label: ISSUE_LABELS[i] || i, severe: SEVERE.has(i) })),
  };
}

// Every URL grouped under the sitemap file it came from.
function buildSitemapGroups() {
  const groups = new Map();
  for (const file of sitemapList) {
    if (file.kind === "index" || file.kind === "failed") continue;
    groups.set(file.url, {
      sitemap: file.url,
      newest: isoDate(file.newestUrl || ""),
      oldest: isoDate(file.oldestUrl || ""),
      urls: [],
    });
  }

  const other = { sitemap: "Not attributed to a sitemap file", newest: "", oldest: "", urls: [] };
  for (const row of rows) {
    const group = groups.get(row.source) || other;
    group.urls.push(reportRow(row));
  }
  if (other.urls.length) groups.set("__other", other);

  return [...groups.values()].filter((g) => g.urls.length);
}

// The Search Console picture in full.
function buildGscDetail() {
  if (!gscJoin) return null;
  return {
    range: Number($("#gscRange")?.value) || 28,
    property: $("#gscSite")?.value || "",
    totals: gscJoin.totals,
    matched: gscJoin.matched,
    unseen: gscJoin.unseen,
    benchmarks: gscBench?.benchmarks || [],
    flagged: gscBench?.flagged || 0,
    missedTotal: gscBench?.missedTotal || 0,
    pages: rows.filter((r) => r.gsc)
      .sort((a, b) => b.gsc.impressions - a.gsc.impressions)
      .map((r) => ({ url: r.loc, clicks: r.gsc.clicks, impressions: r.gsc.impressions,
                     ctr: r.gsc.ctr, position: r.gsc.position, missedClicks: r.missedClicks || 0 })),
    orphans: gscJoin.orphans,
    queries: (() => {
      const all = [];
      for (const row of rows) for (const q of row.queries || []) all.push({ url: row.loc, ...q });
      return all.sort((a, b) => b.impressions - a.impressions);
    })(),
    cannibalisation: cannibalReport?.conflicts || [],
  };
}

function buildReportPayload() {
  const site = (() => {
    try { return unicodeHost(new URL(rows[0].loc).hostname); } catch { return "site"; }
  })();

  const severeRows = rows.filter((r) => issuesFor(r).some((i) => SEVERE.has(i)));

  const tally = new Map();
  for (const row of rows) for (const issue of issuesFor(row)) tally.set(issue, (tally.get(issue) || 0) + 1);

  // The few things worth saying on page one, in the order a client should care.
  const headline = [];
  const brokenCount = rows.filter((r) => r.statusState === "failed" || r.status >= 400).length;
  if (brokenCount) headline.push({ severity: "error",
    title: `${brokenCount} URL${brokenCount === 1 ? " in the sitemap does not resolve" : "s in the sitemap do not resolve"}`,
    detail: "A sitemap full of dead URLs wastes crawl budget and signals low quality." });
  if (robotsReport?.blocked) headline.push({ severity: "error",
    title: `${robotsReport.blocked} sitemap URL${robotsReport.blocked === 1 ? " is" : "s are"} blocked by robots.txt`,
    detail: "The sitemap asks Google to index these pages while robots.txt forbids crawling them." });
  const noindexed = rows.filter((r) => /noindex/i.test(r.robots || "")).length;
  if (noindexed) headline.push({ severity: "error",
    title: `${noindexed} page${noindexed === 1 ? " in the sitemap carries noindex" : "s in the sitemap carry noindex"}`,
    detail: "These cannot appear in search results, so listing them in the sitemap is contradictory." });
  if (linkReport?.orphansWithTraffic) headline.push({ severity: "warn",
    title: `${linkReport.orphansWithTraffic} page${linkReport.orphansWithTraffic === 1 ? " earns" : "s earn"} impressions with no internal links`,
    detail: "Google found them despite the site's own navigation, so internal linking is leaving value on the table." });
  if (gscBench?.flagged) headline.push({ severity: "warn",
    title: `${gscBench.flagged} page${gscBench.flagged === 1 ? " ranks well but is" : "s rank well but are"} rarely clicked`,
    detail: `Click-through sits well below this site's own median for the same positions — roughly ${gscBench.missedTotal.toLocaleString()} clicks.` });
  if (schemaReportData?.pagesWithErrors) headline.push({ severity: "warn",
    title: `${schemaReportData.pagesWithErrors} page${schemaReportData.pagesWithErrors === 1 ? " has" : "s have"} structured data errors`,
    detail: "Invalid markup makes a page ineligible for the corresponding rich result." });

  const priority = severeRows.slice()
    .sort((a, b) => (b.gsc?.impressions || 0) - (a.gsc?.impressions || 0))
    .slice(0, REPORT_MAX_ROWS)
    .map((r) => ({ url: displayUrl(r.loc), impressions: r.gsc?.impressions || 0,
      issues: issuesFor(r).filter((i) => SEVERE.has(i)).map((i) => ISSUE_LABELS[i] || i).join(", ") }));

  const sections = [];

  if (hygieneReport?.issues.length) sections.push({ title: "Sitemap health",
    headers: ["Severity", "Finding"],
    rows: hygieneReport.issues.map((i) => [i.severity === "error" ? "Error" : "Warning", i.detail]) });

  if (robotsReport?.available && robotsReport.byRule.length) sections.push({ title: "Blocked by robots.txt",
    intro: `Evaluated as ${robotsReport.agent} against the "${robotsReport.matchedAgent}" group.`,
    headers: ["Rule", "URLs blocked", "Example"], aligns: ["", "num", "url"],
    rows: robotsReport.byRule.map((g) => [`Disallow: ${g.pattern}`, g.count, displayUrl(g.examples[0] || "")]) });

  const broken = [];
  for (const row of rows) for (const link of row.brokenLinks || []) {
    broken.push([displayUrl(row.loc), displayUrl(link.to), link.anchor || "", String(link.status)]);
  }
  if (broken.length) sections.push({ title: "Broken internal links",
    intro: "Anchor text is included so each link can be found in the page editor.",
    headers: ["On page", "Links to", "Anchor text", "Status"], aligns: ["url", "url", "", "num"], rows: broken });

  if (schemaReportData?.issues.length) sections.push({ title: "Structured data",
    intro: `${schemaReportData.pagesWithSchema} of ${schemaReportData.checked} pages carry JSON-LD. Errors block the rich result; warnings weaken it.`,
    headers: ["Severity", "Pages", "Finding"], aligns: ["", "num", ""],
    rows: schemaReportData.issues.map((i) => [i.severity === "error" ? "Error" : "Warning", i.count, i.message]) });

  const hreflangIssues = [];
  for (const row of rows) for (const issue of row.hreflangIssues || []) {
    hreflangIssues.push([displayUrl(row.loc), issue.severity, issue.detail]);
  }
  if (hreflangIssues.length) sections.push({ title: "hreflang",
    headers: ["URL", "Severity", "Finding"], aligns: ["url", "", ""], rows: hreflangIssues });

  sections.push({ title: "Sitemap files",
    headers: ["File", "Type", "URLs", "Newest content"], aligns: ["url", "", "num", ""],
    rows: sitemapList.map((f) => [displayUrl(f.url), f.kind, f.count ?? "",
      isoDate(f.newestUrl || f.newestChild || "") || "—"]) });

  return {
    site,
    generated: new Date().toISOString(),
    counts: {
      urls: rows.length,
      pagesRead: rows.filter((r) => r.metaState === "ok").length,
      severe: severeRows.length,
    },
    gsc: gscJoin
      ? { clicks: gscJoin.totals.clicks, impressions: gscJoin.totals.impressions,
          days: Number($("#gscRange")?.value) || 28 }
      : null,
    headline,
    // Each issue carries its URLs, so nothing in the report is a number the
    // reader cannot act on.
    issues: [...tally.entries()].sort((a, b) => b[1] - a[1]).map(([issue, count]) => ({
      key: issue, label: ISSUE_LABELS[issue] || issue, count,
      urls: rows.filter((r) => issuesFor(r).includes(issue)).map((r) => r.loc),
    })),
    priority,
    treeSvg: treeSvgString(),
    treeSummary: treeSummaryText(),
    sections,
    sitemapGroups: buildSitemapGroups(),
    gscDetail: buildGscDetail(),
    robotsText: robotsText || "",
    robotsSummary: robotsReport?.available
      ? { agent: robotsReport.agent, group: robotsReport.matchedAgent, rules: robotsReport.rules, blocked: robotsReport.blocked }
      : null,
  };
}


async function openReport() {
  if (!rows.length) return setStatus("Extract a sitemap first.", "error");

  setStatus("Building the full report…", "working");

  try {
    const payload = buildReportPayload();
    const size = JSON.stringify(payload).length;
    await chrome.storage.local.set({ reportPayload: payload });
    chrome.tabs.create({ url: chrome.runtime.getURL("report.html") });
    setStatus(
      `Report opened in a new tab (${rows.length.toLocaleString()} URLs, ${Math.round(size / 1024)} KB) — use Save as PDF there.`,
      "done"
    );
  } catch (err) {
    // The usual cause is the storage quota on a very large site.
    setStatus(`Could not build the report: ${err.message}`, "error");
  }
}

/* ---------- wiring ---------- */

document.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(location.search);
  if (params.get("view") === "tab") document.body.classList.add("in-tab");

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.url?.startsWith("http")) $("#origin").value = new URL(tab.url).origin;
  } catch {
    /* running as a tab with no active http page: leave the field empty */
  }

  const prefill = params.get("origin");
  if (prefill) $("#origin").value = prefill;

  $("#run").addEventListener("click", run);
  $("#origin").addEventListener("keydown", (e) => {
    if (e.key === "Enter") run();
  });

  $("#gscConnect").addEventListener("click", gscConnect);
  $("#gscLoad").addEventListener("click", gscLoad);
  $("#gscQueries").addEventListener("click", gscLoadQueries);
  $("#gscInspect").addEventListener("click", runInspection);
  $("#gscSite").addEventListener("change", (e) => renderQuota(e.target.value));
  $("#gscSignOut").addEventListener("click", async () => {
    await gscSignOut();
    gscSites = [];
    gscJoin = null;
    gscBench = null;
    $("#gscSite").hidden = true;
    $("#gscLoad").hidden = true;
    $("#gscQueries").hidden = true;
    $("#gscInspect").hidden = true;
    $("#gscSignOut").hidden = true;
    $("#gscConnect").hidden = false;
    $("#gscState").textContent = "not connected";
    $("#gscBench").textContent = "";
    $("#gscOrphans").textContent = "";
    gscSay("Signed out.");
    render();
    renderSummary();
  });
  $("#gscUseToken").addEventListener("click", () => {
    const token = $("#gscToken").value.trim();
    if (!token) return gscSay("Paste an access token first.", "bad");
    setManualToken(token);
    $("#gscToken").value = "";
    gscConnect();
  });

  $("#checkStatus").addEventListener("click", runStatus);
  $("#checkLinks").addEventListener("click", runLinkCheck);
  $("#fetchMeta").addEventListener("click", runMeta);
  $("#cancelRun").addEventListener("click", () => {
    statusAbort?.abort();
    metaAbort?.abort();
    $("#cancelRun").hidden = true;
  });

  $("#filterText").addEventListener("input", render);
  $("#filterMode").addEventListener("change", render);
  $("#sortMode").addEventListener("change", render);

  $("#mapsToggle").addEventListener("click", () => {
    const toggle = $("#mapsToggle");
    if (toggle.disabled) return;
    const panel = $("#mapsPanel");
    const open = panel.hidden;
    panel.hidden = !open;
    toggle.setAttribute("aria-expanded", String(open));
  });

  $("#copy").addEventListener("click", async () => {
    const list = visibleRows();
    await navigator.clipboard.writeText(list.map((r) => r.loc).join("\n"));
    setStatus(`Copied ${list.length.toLocaleString()} URLs.`, "done");
  });

  $("#csv").addEventListener("click", () => {
    download(`${siteSlug()}-sitemap-${stamp()}.csv`, buildCsv(rows), "text/csv;charset=utf-8");
  });

  $("#xlsx").addEventListener("click", async () => {
    const button = $("#xlsx");
    button.disabled = true;
    button.textContent = "Building…";
    try {
      const blob = await buildXlsx(buildWorkbookSheets());
      const url = URL.createObjectURL(blob);
      if (chrome?.downloads?.download) chrome.downloads.download({ url, filename: `${siteSlug()}-seo-${stamp()}.xlsx` });
      else {
        const a = Object.assign(document.createElement("a"), { href: url, download: `${siteSlug()}-seo-${stamp()}.xlsx` });
        document.body.appendChild(a);
        a.click();
        a.remove();
      }
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      setStatus("Workbook exported with a tab per data set.", "done");
    } catch (err) {
      setStatus(`Export failed: ${err.message}`, "error");
    } finally {
      button.disabled = false;
      button.textContent = ".xlsx";
    }
  });

  $("#pdf").addEventListener("click", openReport);

  $("#json").addEventListener("click", () => {
    const payload = {
      generated: new Date().toISOString(),
      sitemaps: sitemapList,
      urls: rows,
    };
    download(`${siteSlug()}-sitemap-${stamp()}.json`, JSON.stringify(payload, null, 2), "application/json");
  });

  $("#openTab").addEventListener("click", () => {
    const origin = $("#origin").value.trim();
    chrome.tabs.create({
      url: chrome.runtime.getURL(`popup.html?view=tab${origin ? `&origin=${encodeURIComponent(origin)}` : ""}`),
    });
  });
});
