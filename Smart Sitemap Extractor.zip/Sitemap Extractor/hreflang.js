/* hreflang validation.

   Individual tags are easy to eyeball; the failures that actually cost traffic
   are relational — a page pointing at a translation that doesn't point back, a
   cluster where one member forgot two languages, an alternate aimed at a URL
   that redirects or is noindex. Google silently ignores non-reciprocal
   annotations, so these break without any visible error anywhere.

   Because we hold the whole sitemap plus every page's alternates, the complete
   graph is available here, which is what makes these checks possible. */

const X_DEFAULT = "x-default";

// Intl resolves these through CLDR aliasing even though they are not ISO 3166-1
// country codes, so it cannot be trusted alone. en-UK is the single most common
// hreflang mistake in the wild and Intl reports it as "United Kingdom".
const INVALID_REGIONS = new Map([
  ["UK", "not ISO 3166-1 — the United Kingdom is GB"],
  ["EU", "not a country; target member countries individually or use x-default"],
  ["EZ", "not a country code"],
  ["UN", "not a country code"],
  ["QO", "not a country code"],
  ["ZZ", "placeholder for an unknown region"],
  ["XA", "pseudo-locale, not a real region"],
  ["XB", "pseudo-locale, not a real region"],
  ["AN", "withdrawn in 2010 — use CW, SX or BQ"],
  ["CS", "withdrawn — use RS or ME"],
  ["YU", "withdrawn — use RS or ME"],
  ["SU", "withdrawn — use RU or a successor state"],
  ["TP", "withdrawn — use TL"],
  ["ZR", "withdrawn — use CD"],
  ["BU", "withdrawn — use MM"],
  ["DD", "withdrawn — use DE"],
  ["FX", "withdrawn — use FR"],
  ["SF", "withdrawn — use FI"],
  ["NT", "withdrawn"],
]);

// Country codes typed where a language belongs. None of these are real language
// codes, so they are safe to reject outright.
const LANGUAGE_FIXES = new Map([
  ["cn", "China is a country — Chinese is zh (try zh-CN)"],
  ["jp", "Japan is a country — Japanese is ja (try ja-JP)"],
  ["gb", "GB is a country — English is en (try en-GB)"],
  ["dk", "Denmark is a country — Danish is da (try da-DK)"],
  ["gr", "Greece is a country — Greek is el (try el-GR)"],
  ["cz", "Czechia is a country — Czech is cs (try cs-CZ)"],
  ["at", "Austria is a country — German is de (try de-AT)"],
  ["ae", "the UAE is a country — Arabic is ar (try ar-AE)"],
  ["us", "the US is a country — English is en (try en-US)"],
]);

// These *are* valid languages but are very often typed when a country was meant,
// so they get an advisory note rather than an error.
const AMBIGUOUS_LANGUAGES = new Map([
  ["uk", "uk is Ukrainian — for the United Kingdom use en-GB"],
  ["se", "se is Northern Sami — for Sweden use sv-SE"],
  ["br", "br is Breton — for Brazil use pt-BR"],
  ["in", "in is Indonesian (deprecated form of id) — for India use en-IN or hi-IN"],
  ["ie", "ie is Interlingue — for Ireland use en-IE"],
  ["ch", "ch is Chamorro — for Switzerland use de-CH, fr-CH or it-CH"],
  ["be", "be is Belarusian — for Belgium use nl-BE or fr-BE"],
]);

let languageNames = null;
let regionNames = null;

function displayNames() {
  if (!languageNames) {
    try {
      languageNames = new Intl.DisplayNames(["en"], { type: "language", fallback: "code" });
      regionNames = new Intl.DisplayNames(["en"], { type: "region", fallback: "code" });
    } catch {
      languageNames = regionNames = { of: (c) => c };
    }
  }
  return { languageNames, regionNames };
}

/* ---------- single tag ---------- */

function parseHreflang(raw) {
  const tag = String(raw || "").trim();
  const result = { tag, valid: true, isXDefault: false, problems: [], notes: [] };

  if (!tag) {
    result.valid = false;
    result.problems.push("empty hreflang value");
    return result;
  }

  if (tag.toLowerCase() === X_DEFAULT) {
    result.isXDefault = true;
    return result;
  }

  if (tag.includes("_")) {
    result.valid = false;
    result.problems.push(`underscores are not allowed — write ${tag.replace(/_/g, "-")}`);
    return result;
  }

  const m = /^([A-Za-z]{2,3})(?:-([A-Za-z]{4}))?(?:-([A-Za-z]{2}|\d{3}))?$/.exec(tag);
  if (!m) {
    result.valid = false;
    result.problems.push("not a valid language[-script][-region] tag");
    return result;
  }

  const [, langRaw, scriptRaw, regionRaw] = m;
  const lang = langRaw.toLowerCase();
  const region = regionRaw ? regionRaw.toUpperCase() : "";
  const { languageNames, regionNames } = displayNames();

  result.language = lang;
  result.script = scriptRaw || "";
  result.region = region;

  if (LANGUAGE_FIXES.has(lang)) {
    result.valid = false;
    result.problems.push(LANGUAGE_FIXES.get(lang));
  } else if (languageNames.of(lang) === lang) {
    result.valid = false;
    result.problems.push(`"${lang}" is not a known language code`);
  } else if (AMBIGUOUS_LANGUAGES.has(lang) && !region) {
    result.notes.push(AMBIGUOUS_LANGUAGES.get(lang));
  }

  if (lang.length === 3 && result.valid) {
    result.notes.push(`prefer the two-letter ISO 639-1 form where one exists`);
  }

  if (region) {
    if (/^\d{3}$/.test(region)) {
      result.valid = false;
      result.problems.push("numeric UN M49 regions are not supported — use a two-letter country code");
    } else if (INVALID_REGIONS.has(region)) {
      result.valid = false;
      result.problems.push(`region "${region}" is ${INVALID_REGIONS.get(region)}`);
    } else if (regionNames.of(region) === region) {
      result.valid = false;
      result.problems.push(`"${region}" is not a known country code`);
    }
  }

  return result;
}

/* ---------- graph ---------- */

// Union-find, so pages linked by any chain of alternates end up in one cluster
// even when no single page declares the whole set.
function makeUnionFind() {
  const parent = new Map();
  const find = (x) => {
    if (!parent.has(x)) parent.set(x, x);
    let root = x;
    while (parent.get(root) !== root) root = parent.get(root);
    while (parent.get(x) !== root) {
      const next = parent.get(x);
      parent.set(x, root);
      x = next;
    }
    return root;
  };
  return {
    find,
    union(a, b) {
      const ra = find(a);
      const rb = find(b);
      if (ra !== rb) parent.set(ra, rb);
    },
    roots: () => new Set([...parent.keys()].map(find)),
    keys: () => [...parent.keys()],
  };
}

// Alternates can arrive from three places: the page's <link> tags, the
// sitemap's xhtml:link entries, and a Link: HTTP header.
function alternatesOf(row) {
  // A URL that redirects has no annotations of its own — anything we read came
  // from the destination's HTML. Treating those as this URL's declarations
  // invents reciprocity failures for every tag on the destination page.
  if (row.redirectedTo || row.metaFromRedirect) return [];

  const all = [
    ...(row.hreflangs || []),
    ...(row.alternates || []),
    ...(row.headerAlternates || []),
  ];
  const seen = new Set();
  const out = [];
  for (const entry of all) {
    const key = `${String(entry.hreflang).toLowerCase()}|${entry.href}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(entry);
  }
  return out;
}

function validateHreflang(rows) {
  const byUrl = new Map();
  for (const row of rows) {
    const key = normUrl(row.loc);
    if (key) byUrl.set(key, row);
  }

  const uf = makeUnionFind();
  const declared = new Map(); // page key -> [{ tag, parsed, targetKey, targetHref }]

  for (const row of rows) {
    const pageKey = normUrl(row.loc);
    if (!pageKey) continue;

    row.hreflangIssues = [];
    const entries = alternatesOf(row);
    if (!entries.length) continue;

    const parsedEntries = [];
    const byTag = new Map();

    for (const entry of entries) {
      const parsed = parseHreflang(entry.hreflang);
      const absolute = /^https?:\/\//i.test(entry.href.trim());
      const targetKey = normUrl(entry.href, row.loc);

      if (!absolute) {
        row.hreflangIssues.push({
          code: "relative-href",
          severity: "error",
          detail: `${entry.hreflang}: href must be an absolute URL`,
        });
      }
      for (const problem of parsed.problems) {
        row.hreflangIssues.push({ code: "invalid-code", severity: "error", detail: `${entry.hreflang}: ${problem}` });
      }
      for (const note of parsed.notes) {
        row.hreflangIssues.push({ code: "ambiguous-code", severity: "warn", detail: `${entry.hreflang}: ${note}` });
      }

      const tagKey = parsed.isXDefault ? X_DEFAULT : String(entry.hreflang).toLowerCase();
      if (byTag.has(tagKey) && byTag.get(tagKey) !== targetKey) {
        row.hreflangIssues.push({
          code: "duplicate-code",
          severity: "error",
          detail: `${entry.hreflang} is declared twice pointing at different URLs`,
        });
      }
      byTag.set(tagKey, targetKey);

      parsedEntries.push({ tag: tagKey, parsed, targetKey, targetHref: entry.href });
      if (targetKey) uf.union(pageKey, targetKey);
    }

    declared.set(pageKey, parsedEntries);

    // Every page in a set must include a self-referential tag. Missing it is
    // one of the few hreflang errors Google documents as invalidating the set.
    const selfReferenced = parsedEntries.some((e) => e.targetKey === pageKey);
    if (!selfReferenced) {
      row.hreflangIssues.push({
        code: "no-self-reference",
        severity: "error",
        detail: "no hreflang tag points back at this page",
      });
    }
  }

  /* ---------- cluster-level checks ---------- */

  const clusters = new Map();
  for (const key of uf.keys()) {
    const root = uf.find(key);
    if (!clusters.has(root)) clusters.set(root, []);
    clusters.get(root).push(key);
  }

  const report = [];

  for (const [root, members] of clusters) {
    if (members.length < 2) continue;

    // The union of every tag declared anywhere in the cluster.
    const expected = new Map();
    for (const member of members) {
      for (const entry of declared.get(member) || []) {
        if (!entry.parsed.valid && !entry.parsed.isXDefault) continue;
        if (!expected.has(entry.tag)) expected.set(entry.tag, new Set());
        if (entry.targetKey) expected.get(entry.tag).add(entry.targetKey);
      }
    }

    const cluster = {
      id: root,
      size: members.length,
      languages: [...expected.keys()].sort(),
      issues: [],
      members: [],
    };

    // The same tag resolving to different URLs across the cluster means the
    // members disagree about which page is which language.
    for (const [tag, targets] of expected) {
      if (targets.size > 1) {
        cluster.issues.push({
          code: "conflicting-target",
          severity: "error",
          detail: `${tag} points at ${targets.size} different URLs across this set`,
        });
        for (const member of members) {
          byUrl.get(member)?.hreflangIssues?.push({
            code: "conflicting-target",
            severity: "error",
            detail: `${tag} resolves to different URLs across this hreflang set`,
          });
        }
      }
    }

    if (expected.size >= 2 && !expected.has(X_DEFAULT)) {
      cluster.issues.push({
        code: "no-x-default",
        severity: "warn",
        detail: "no x-default — visitors outside the listed locales get no explicit fallback",
      });
    }

    for (const member of members) {
      const row = byUrl.get(member);
      const entries = declared.get(member);
      const memberInfo = { url: member, known: Boolean(row), declares: entries ? entries.length : 0 };

      // A URL that only appears as someone else's target.
      if (!row) {
        memberInfo.outside = true;
        cluster.members.push(memberInfo);
        for (const other of members) {
          const source = byUrl.get(other);
          if (!source) continue;
          if ((declared.get(other) || []).some((e) => e.targetKey === member)) {
            source.hreflangIssues.push({
              code: "target-not-in-sitemap",
              severity: "warn",
              detail: `alternate ${displayUrl(member)} is not in this sitemap, so it could not be checked`,
            });
          }
        }
        continue;
      }

      if (!entries || !entries.length) {
        // Named as an alternate by others but declaring nothing itself.
        row.hreflangIssues.push({
          code: "not-reciprocal",
          severity: "error",
          detail: "other pages list this as an alternate, but it declares no hreflang tags",
        });
        memberInfo.missing = cluster.languages;
        cluster.members.push(memberInfo);
        continue;
      }

      const declaredTags = new Set(entries.map((e) => e.tag));
      // x-default's absence is a cluster-level warning already; counting it here
      // too would report the same thing twice at a higher severity.
      const missing = [...expected.keys()].filter((tag) => tag !== X_DEFAULT && !declaredTags.has(tag));
      if (missing.length) {
        memberInfo.missing = missing;
        row.hreflangIssues.push({
          code: "incomplete-set",
          severity: "error",
          detail: `missing ${missing.length} of the set's tags: ${missing.slice(0, 6).join(", ")}${missing.length > 6 ? "…" : ""}`,
        });
      }

      // Reciprocity: everything this page points at must point back.
      for (const entry of entries) {
        if (!entry.targetKey || entry.targetKey === member) continue;
        const target = byUrl.get(entry.targetKey);
        if (!target) continue;

        const back = (declared.get(entry.targetKey) || []).some((e) => e.targetKey === member);
        if (!back) {
          row.hreflangIssues.push({
            code: "not-reciprocal",
            severity: "error",
            detail: `${entry.tag} → ${displayUrl(entry.targetHref)} does not link back`,
          });
        }

        // Cross-checks against whatever the status and meta passes found.
        if (target.statusState === "failed" || (target.status && target.status >= 400)) {
          row.hreflangIssues.push({
            code: "broken-target",
            severity: "error",
            detail: `${entry.tag} → ${displayUrl(entry.targetHref)} returns ${target.status || target.statusError}`,
          });
        } else if (target.redirectedTo) {
          row.hreflangIssues.push({
            code: "redirecting-target",
            severity: "warn",
            detail: `${entry.tag} → ${displayUrl(entry.targetHref)} redirects`,
          });
        }
        if (/noindex/i.test(target.robots || "")) {
          row.hreflangIssues.push({
            code: "noindex-target",
            severity: "error",
            detail: `${entry.tag} → ${displayUrl(entry.targetHref)} is noindex`,
          });
        }
        if (target.canonicalMismatch) {
          row.hreflangIssues.push({
            code: "canonical-conflict",
            severity: "error",
            detail: `${entry.tag} → ${displayUrl(entry.targetHref)} canonicalises to a different URL`,
          });
        }
      }

      memberInfo.issues = row.hreflangIssues.length;
      cluster.members.push(memberInfo);
    }

    const memberIssues = cluster.members.reduce((n, m) => n + (m.issues || 0), 0);
    if (cluster.issues.length || memberIssues) report.push(cluster);
    else report.push({ ...cluster, clean: true });
  }

  // De-duplicate: cluster passes can add the same finding to a row twice.
  for (const row of rows) {
    if (!row.hreflangIssues?.length) continue;
    const seen = new Set();
    row.hreflangIssues = row.hreflangIssues.filter((issue) => {
      const key = `${issue.code}|${issue.detail}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  const pagesWithHreflang = rows.filter((r) => alternatesOf(r).length).length;
  const pagesWithIssues = rows.filter((r) => r.hreflangIssues?.length).length;

  return {
    clusters: report.sort((a, b) => b.size - a.size),
    pagesWithHreflang,
    pagesWithIssues,
    clean: report.filter((c) => c.clean).length,
  };
}
