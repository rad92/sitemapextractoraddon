/* Page-level metadata. One request per URL, so this is always an opt-in pass. */

const META_CONCURRENCY = 5;
const MAX_HTML_BYTES = 700_000;
const REQUEST_TIMEOUT_MS = 20_000;
const MAX_RETRIES = 2;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ---------- fetch ---------- */

// Streams and stops early: the metadata we want sits near the top, and article
// pages can be many megabytes.
async function readCapped(res) {
  if (!res.body) return { buffer: await res.arrayBuffer(), truncated: false };

  const reader = res.body.getReader();
  const chunks = [];
  let total = 0;
  let truncated = false;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    total += value.length;
    if (total >= MAX_HTML_BYTES) {
      truncated = true;
      break;
    }
  }
  reader.cancel().catch(() => {});

  const buffer = new Uint8Array(total);
  let offset = 0;
  for (const c of chunks) {
    buffer.set(c, offset);
    offset += c.length;
  }
  return { buffer: buffer.buffer, truncated };
}

async function loadHtml(url, signal) {
  let lastError;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    if (signal?.aborted) throw new DOMException("aborted", "AbortError");

    // Per-request timeout, folded together with the run-wide cancel signal so a
    // single hung server can't stall the whole job.
    const timer = new AbortController();
    const timeout = setTimeout(() => timer.abort(), REQUEST_TIMEOUT_MS);
    const onAbort = () => timer.abort();
    signal?.addEventListener("abort", onAbort, { once: true });

    try {
      const res = await fetch(url, {
        redirect: "follow",
        credentials: "omit",
        signal: timer.signal,
        headers: { Accept: "text/html,application/xhtml+xml" },
      });

      // Rate limiting and transient outages are worth waiting out; other errors
      // are not going to change on a retry.
      if (res.status === 429 || res.status === 503) {
        const retryAfter = parseInt(res.headers.get("retry-after") || "", 10);
        if (attempt < MAX_RETRIES) {
          await sleep(Number.isFinite(retryAfter) ? Math.min(retryAfter * 1000, 15000) : 1000 * 2 ** attempt);
          lastError = new Error(`HTTP ${res.status}`);
          continue;
        }
      }

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const contentType = res.headers.get("content-type") || "";
      if (contentType && !/text\/html|application\/xhtml|text\/plain/i.test(contentType)) {
        throw new Error(`not HTML (${contentType.split(";")[0].trim()})`);
      }

      const { buffer, truncated } = await readCapped(res);
      const { text, charset, from } = decodeBody(buffer, contentType);

      return {
        html: text,
        charset,
        charsetFrom: from,
        truncated,
        status: res.status,
        finalUrl: res.url || url,
        // An X-Robots-Tag header is invisible in the markup but just as binding.
        xRobots: res.headers.get("x-robots-tag") || "",
      };
    } catch (err) {
      if (signal?.aborted) throw new DOMException("aborted", "AbortError");
      if (err.name === "AbortError") {
        lastError = new Error("timed out");
      } else {
        lastError = err;
        if (!/HTTP (429|503|5\d\d)/.test(err.message)) throw err;
      }
      if (attempt < MAX_RETRIES) await sleep(1000 * 2 ** attempt);
    } finally {
      clearTimeout(timeout);
      signal?.removeEventListener("abort", onAbort);
    }
  }

  throw lastError || new Error("failed");
}

/* ---------- structured data ---------- */

// Walks arrays, @graph and nested objects, so a date is found whether it sits at
// the top level or inside a WebPage/Article node several levels down.
function* ldNodes(value, depth = 0) {
  if (depth > 6 || !value) return;
  if (Array.isArray(value)) {
    for (const item of value) yield* ldNodes(item, depth + 1);
    return;
  }
  if (typeof value !== "object") return;
  yield value;
  for (const key of Object.keys(value)) {
    const child = value[key];
    if (child && typeof child === "object") yield* ldNodes(child, depth + 1);
  }
}

function fromJsonLd(doc) {
  const out = { published: "", modified: "", type: "", blocks: 0, broken: 0 };

  for (const script of doc.querySelectorAll('script[type="application/ld+json" i]')) {
    out.blocks++;
    let data;
    try {
      data = JSON.parse(script.textContent);
    } catch {
      out.broken++; // one malformed block shouldn't lose the others
      continue;
    }
    for (const node of ldNodes(data)) {
      if (!out.published && typeof node.datePublished === "string") out.published = node.datePublished.trim();
      if (!out.modified && typeof node.dateModified === "string") out.modified = node.dateModified.trim();
      if (!out.type && typeof node["@type"] === "string") out.type = node["@type"];
    }
  }
  return out;
}

/* ---------- dates ---------- */

// Normalizes to YYYY-MM-DD.
//
// Deliberately reads the literal date off ISO-8601 strings rather than going
// through Date. "2025-11-03T08:30:00+13:00" is 2025-11-02 in UTC, so a
// toISOString() round-trip reports every post from any timezone ahead of UTC
// (all of Asia, Australia, NZ, and much of Europe in summer) a day early.
function isoDate(raw) {
  if (!raw) return "";
  const value = String(raw).trim();

  const iso = /^\d{4}-\d{2}-\d{2}/.exec(value);
  if (iso) return iso[0];

  // Human formats carry no offset to preserve, so read them in local time to
  // avoid introducing the same off-by-one from the other direction.
  const d = new Date(value);
  if (!isNaN(d.getTime())) {
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  return value; // unparseable: show it rather than silently dropping it
}

/* ---------- extraction ---------- */

function readMeta(html, pageUrl) {
  // DOMParser builds an inert document: no scripts run, no subresources load.
  const doc = new DOMParser().parseFromString(html, "text/html");

  const attr = (selector, name = "content") => {
    const el = doc.querySelector(selector);
    const value = el?.getAttribute(name);
    return value ? value.replace(/\s+/g, " ").trim() : "";
  };

  const title =
    (doc.querySelector("title")?.textContent || "").replace(/\s+/g, " ").trim() ||
    attr('meta[property="og:title" i]') ||
    attr('meta[name="twitter:title" i]');

  const description =
    attr('meta[name="description" i]') ||
    attr('meta[property="og:description" i]') ||
    attr('meta[name="twitter:description" i]');

  const ld = fromJsonLd(doc);
  // Guarded like the link extraction: a missing script should degrade to "no
  // structured data report", not throw away every other field on the page.
  const schema = typeof validateSchema === "function" ? validateSchema(doc) : null;

  const published =
    ld.published ||
    attr('meta[property="article:published_time" i]') ||
    attr('meta[name="article:published_time" i]') ||
    attr('meta[itemprop="datePublished" i]') ||
    attr('meta[name="date" i]') ||
    attr('meta[name="publish_date" i]') ||
    attr('meta[name="DC.date.issued" i]') ||
    attr("time[itemprop='datePublished' i]", "datetime") ||
    attr("time[pubdate]", "datetime");

  const modified =
    ld.modified ||
    attr('meta[property="article:modified_time" i]') ||
    attr('meta[name="article:modified_time" i]') ||
    attr('meta[property="og:updated_time" i]') ||
    attr('meta[itemprop="dateModified" i]') ||
    attr('meta[name="last-modified" i]') ||
    attr("time[itemprop='dateModified' i]", "datetime");

  // Language and alternates — the core of any international audit.
  const hreflangs = [];
  for (const link of doc.querySelectorAll("link[rel='alternate' i][hreflang]")) {
    const lang = link.getAttribute("hreflang");
    const href = link.getAttribute("href");
    if (lang && href) hreflangs.push({ hreflang: lang.trim(), href: href.trim() });
  }

  // Extracted before script/style stripping below; costs no extra request since
  // this document is already parsed.
  // Guarded: if links.js ever fails to load, metadata extraction should degrade
  // to "no link graph" rather than throwing and losing every field on the page.
  const links =
    typeof extractLinks === "function"
      ? extractLinks(doc, pageUrl)
      : { internal: [], external: 0, nofollow: 0, truncated: false };

  // Every heading in document order, not just H1. The outline is what tells you
  // whether a page is structured or just visually styled.
  const allHeadings = [];
  const headingCounts = { h1: 0, h2: 0, h3: 0, h4: 0, h5: 0, h6: 0 };
  let emptyHeadings = 0;
  let previousLevel = 0;
  const skippedLevels = [];

  for (const node of doc.querySelectorAll("h1, h2, h3, h4, h5, h6")) {
    const level = Number(node.tagName[1]);
    const text = (node.textContent || "").replace(/\s+/g, " ").trim();
    headingCounts[`h${level}`]++;
    if (!text) emptyHeadings++;

    // A jump from h2 straight to h4 breaks the document outline for anything
    // reading structure rather than styling.
    if (previousLevel && level > previousLevel + 1) {
      skippedLevels.push(`h${previousLevel} → h${level}`);
    }
    previousLevel = level;

    if (allHeadings.length < 150) allHeadings.push({ level, text });
  }

  const headings = doc.querySelectorAll("h1");

  // Word counting is only meaningful on a complete document.
  let words = 0;
  const body = doc.body;
  if (body) {
    for (const el of body.querySelectorAll("script, style, noscript, template")) el.remove();
    const text = (body.textContent || "").trim();
    words = text ? text.split(/\s+/).length : 0;
  }

  return {
    title,
    description,
    published: isoDate(published),
    modified: isoDate(modified),
    canonical: attr('link[rel="canonical" i]', "href"),
    robots: attr('meta[name="robots" i]') || attr('meta[name="googlebot" i]'),
    h1: (headings[0]?.textContent || "").replace(/\s+/g, " ").trim(),
    h1Count: headings.length,
    headings: allHeadings,
    headingCounts,
    headingTotal: Object.values(headingCounts).reduce((a, b) => a + b, 0),
    emptyHeadings,
    skippedLevels,
    lang: (doc.documentElement?.getAttribute("lang") || "").trim(),
    ogLocale: attr('meta[property="og:locale" i]'),
    hreflangs,
    ogTitle: attr('meta[property="og:title" i]'),
    ogImage: attr('meta[property="og:image" i]'),
    viewport: attr('meta[name="viewport" i]'),
    schemaType: ld.type,
    schemaBlocks: ld.blocks,
    schemaBroken: ld.broken,
    schema,
    words,
    outLinks: links.internal,
    internalLinkCount: links.internal.length,
    externalLinkCount: links.external,
    nofollowCount: links.nofollow,
    linksTruncated: links.truncated,
  };
}

/* ---------- driver ---------- */

// A fixed worker pool over the URL list, mutating rows in place so the UI can
// repaint progressively rather than waiting for the whole batch.
async function fetchAllMeta(rows, { signal, onProgress }) {
  let cursor = 0;
  let done = 0;
  let failed = 0;

  async function worker() {
    while (cursor < rows.length) {
      if (signal.aborted) return;
      const row = rows[cursor++];

      try {
        const page = await loadHtml(row.loc, signal);
        const meta = readMeta(page.html, row.loc);

        Object.assign(row, meta, {
          status: page.status,
          charset: page.charset,
          charsetFrom: page.charsetFrom,
          metaState: "ok",
          words: page.truncated ? null : meta.words, // null = "not counted"
        });

        if (page.xRobots) {
          row.robots = [row.robots, `header: ${page.xRobots}`].filter(Boolean).join(" | ");
        }
        if (page.finalUrl && page.finalUrl !== row.loc) {
          row.redirectedTo = page.finalUrl;
          // Everything just parsed describes the destination, not this URL.
          // Attributing it here would, for example, credit this URL with the
          // destination's hreflang tags and then report them all as broken.
          row.metaFromRedirect = true;
        }

        // Flag only real mismatches: ignore trailing-slash and case-of-host noise.
        if (meta.canonical) {
          try {
            const a = new URL(meta.canonical, row.loc);
            const b = new URL(row.loc);
            const norm = (u) => (u.origin + u.pathname).replace(/\/$/, "").toLowerCase() + u.search;
            row.canonicalMismatch = norm(a) !== norm(b);
          } catch {
            row.canonicalMismatch = false;
          }
        }
      } catch (err) {
        if (err.name === "AbortError") return;
        row.metaState = "failed";
        row.metaError = err.message;
        failed++;
      }

      done++;
      onProgress?.({ done, total: rows.length, failed });
    }
  }

  await Promise.all(Array.from({ length: Math.min(META_CONCURRENCY, rows.length) }, worker));
  return { done, failed, aborted: signal.aborted };
}

/* ---------- cross-page analysis ---------- */

// Duplicate titles and descriptions only become visible once the whole set is in
// hand, so this runs after the fetch pass rather than per row.
function markDuplicates(rows) {
  const titles = new Map();
  const descriptions = new Map();

  for (const row of rows) {
    if (row.metaState !== "ok") continue;
    if (row.title) {
      const key = row.title.trim().toLowerCase();
      titles.set(key, (titles.get(key) || 0) + 1);
    }
    if (row.description) {
      const key = row.description.trim().toLowerCase();
      descriptions.set(key, (descriptions.get(key) || 0) + 1);
    }
  }

  for (const row of rows) {
    row.dupTitle = row.title ? titles.get(row.title.trim().toLowerCase()) > 1 : false;
    row.dupDescription = row.description
      ? descriptions.get(row.description.trim().toLowerCase()) > 1
      : false;
  }
}
