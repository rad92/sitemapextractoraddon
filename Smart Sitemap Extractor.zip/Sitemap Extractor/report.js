/* Renders the printable report from the payload the popup stored.

   Chrome extensions cannot write a PDF directly, and bundling a PDF library
   would mean rebuilding layout, pagination and fonts from scratch. Printing a
   properly styled page is both simpler and better: Chrome's own renderer
   handles pagination, text stays selectable, and the output is vector. */

const STORAGE_KEY = "reportPayload";

const $ = (s) => document.querySelector(s);

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function num(value) {
  return typeof value === "number" ? value.toLocaleString() : value || "—";
}

function table(headers, rows, aligns = []) {
  const wrap = document.createElement("table");
  const head = document.createElement("thead");
  const headRow = document.createElement("tr");
  headers.forEach((h, i) => {
    const th = el("th", aligns[i] === "num" ? "num" : "", h);
    headRow.appendChild(th);
  });
  head.appendChild(headRow);
  wrap.appendChild(head);

  const body = document.createElement("tbody");
  for (const row of rows) {
    const tr = document.createElement("tr");
    row.forEach((cell, i) => {
      const td = el("td", aligns[i] || "", cell == null ? "" : String(cell));
      tr.appendChild(td);
    });
    body.appendChild(tr);
  }
  wrap.appendChild(body);
  return wrap;
}

function section(root, title) {
  root.appendChild(el("h2", "", title));
}

function render(payload) {
  const root = $("#report");
  root.textContent = "";

  /* Cover */
  const cover = el("div", "cover");
  cover.appendChild(el("h1", "", "SEO audit"));
  cover.appendChild(el("div", "site", payload.site));
  const meta = el("div", "meta");
  meta.id = "coverMeta";
  meta.textContent = `Generated ${new Date(payload.generated).toLocaleDateString()}`;
  cover.appendChild(meta);
  root.appendChild(cover);

  /* Headline numbers */
  section(root, "At a glance");
  const cards = el("div", "cards");
  const card = (value, label, tone = "") => {
    const c = el("div", `card ${tone}`);
    c.appendChild(el("div", "value", num(value)));
    c.appendChild(el("div", "label", label));
    return c;
  };
  cards.appendChild(card(payload.counts.urls, "URLs in sitemap"));
  cards.appendChild(card(payload.counts.pagesRead, "pages read"));
  if (payload.counts.severe) cards.appendChild(card(payload.counts.severe, "need attention", "bad"));
  else cards.appendChild(card(0, "need attention", "good"));
  if (payload.gsc) {
    cards.appendChild(card(payload.gsc.clicks, `clicks (${payload.gsc.days}d)`));
    cards.appendChild(card(payload.gsc.impressions, "impressions"));
  }
  root.appendChild(cards);

  if (payload.headline.length) {
    for (const finding of payload.headline) {
      const box = el("div", `finding ${finding.severity === "error" ? "bad" : ""}`);
      box.appendChild(el("div", "title", finding.title));
      if (finding.detail) box.appendChild(el("div", "detail", finding.detail));
      root.appendChild(box);
    }
  } else {
    root.appendChild(el("p", "note", "No significant problems were found in the checks that were run."));
  }

  /* Issue breakdown, each with the URLs it applies to */
  if (payload.issues.length) {
    section(root, "Issues by type");
    root.appendChild(
      el("p", "note", "Every finding lists the URLs it applies to, so nothing here is a number you cannot act on.")
    );
    for (const issue of payload.issues) {
      const block = el("div", "issue-block");
      block.appendChild(el("div", "issue-head", `${issue.label} \u2014 ${num(issue.count)} page${issue.count === 1 ? "" : "s"}`));
      const list = el("ul", "url-list");
      for (const url of issue.urls || []) list.appendChild(el("li", "", url));
      block.appendChild(list);
      root.appendChild(block);
    }
  }

  /* Tree */
  if (payload.treeSvg) {
    section(root, "Site structure");
    root.appendChild(el("p", "note", payload.treeSummary || ""));
    const wrap = el("div", "tree-wrap");
    // Parsed rather than assigned through innerHTML: the SVG is machine-built
    // from URLs, and parsing it as a document keeps the markup inert.
    const parsed = new DOMParser().parseFromString(payload.treeSvg, "image/svg+xml");
    const svg = parsed.documentElement;
    if (svg && svg.nodeName.toLowerCase() === "svg") {
      wrap.appendChild(document.importNode(svg, true));
      root.appendChild(wrap);
    }
  }

  /* Priority pages */
  if (payload.priority?.length) {
    section(root, "Pages to fix first");
    root.appendChild(
      el("p", "note",
        payload.gsc
          ? "Ordered by impressions, so the work is ranked by what it costs rather than by page order."
          : "Pages carrying the most severe findings.")
    );
    root.appendChild(
      table(
        payload.gsc ? ["URL", "Impressions", "Problems"] : ["URL", "Problems"],
        payload.priority.map((p) => (payload.gsc ? [p.url, num(p.impressions), p.issues] : [p.url, p.issues])),
        payload.gsc ? ["url", "num", ""] : ["url", ""]
      )
    );
  }

  /* Sections */
  for (const block of payload.sections) {
    if (!block.rows?.length && !block.notes?.length) continue;
    section(root, block.title);
    if (block.intro) root.appendChild(el("p", "note", block.intro));
    for (const note of block.notes || []) root.appendChild(el("p", "", note));
    if (block.rows?.length) {
      root.appendChild(table(block.headers, block.rows, block.aligns || []));
      if (block.truncated) root.appendChild(el("p", "note", block.truncated));
    }
  }

  if (payload.gscDetail) renderGsc(root, payload.gscDetail);

  if (payload.robotsText) {
    section(root, "robots.txt");
    if (payload.robotsSummary) {
      root.appendChild(
        el("p", "note",
          `Evaluated as ${payload.robotsSummary.agent} against the "${payload.robotsSummary.group}" group \u2014 ` +
            `${payload.robotsSummary.rules} rules, ${payload.robotsSummary.blocked} sitemap URLs blocked.`)
      );
    }
    root.appendChild(el("pre", "robots-file", payload.robotsText));
  }

  if (payload.sitemapGroups?.length) {
    const urls = el("div", "urls-section");
    urls.appendChild(el("div", "page-break"));
    urls.appendChild(el("h2", "", "All URLs"));
    urls.appendChild(
      el("p", "note", "Grouped by the sitemap file each URL came from, with its search preview and metadata.")
    );
    for (const group of payload.sitemapGroups) renderGroup(urls, group);
    root.appendChild(urls);
  }

  const footer = el("footer", "report-footer");
  footer.id = "reportFooter";
  footer.textContent = `${payload.site} · generated ${new Date(payload.generated).toLocaleString()}`;
  root.appendChild(footer);
}

function applyBranding() {
  const client = $("#client").value.trim();
  const author = $("#author").value.trim();
  const meta = $("#coverMeta");
  if (!meta) return;

  const parts = [];
  if (client) parts.push(`Prepared for ${client}`);
  if (author) parts.push(`by ${author}`);
  parts.push(`Generated ${new Date().toLocaleDateString()}`);
  meta.textContent = parts.join(" · ");
}

document.addEventListener("DOMContentLoaded", async () => {
  $("#print").addEventListener("click", () => {
    applyBranding();
    window.print();
  });
  for (const id of ["#client", "#author"]) $(id).addEventListener("input", applyBranding);

  $("#detail").addEventListener("change", (e) => {
    const section = document.querySelector(".urls-section");
    if (section) section.hidden = e.target.value === "summary";
  });

  try {
    const stored = await chrome.storage.local.get(STORAGE_KEY);
    const payload = stored?.[STORAGE_KEY];
    if (!payload) {
      $("#report").textContent = "";
      $("#report").appendChild(
        el("p", "note", "No report data found. Generate the report again from the extension popup.")
      );
      return;
    }
    render(payload);
  } catch (err) {
    $("#report").textContent = `Could not load the report: ${err.message}`;
  }
});

/* ---------- Search Console, in full ---------- */

function renderGsc(root, gsc) {
  root.appendChild(el("div", "page-break"));
  section(root, "Search Console");
  root.appendChild(
    el("p", "note",
      `${gsc.property || "Property"} · last ${gsc.range} days · ${num(gsc.totals.clicks)} clicks and ` +
        `${num(gsc.totals.impressions)} impressions across ${num(gsc.matched)} matched URLs ` +
        `(${num(gsc.unseen)} with no impressions).`)
  );

  if (gsc.benchmarks.length) {
    root.appendChild(el("h3", "", "Click-through rate by position"));
    root.appendChild(
      el("p", "note",
        "Measured against this site's own median rather than a generic industry curve, so the comparison reflects this audience.")
    );
    root.appendChild(
      table(["Position", "Median CTR"], gsc.benchmarks.map((b) => [b.bucket, `${(b.ctr * 100).toFixed(2)}%`]), ["", "num"])
    );
    if (gsc.flagged) {
      root.appendChild(
        el("p", "",
          `${gsc.flagged} page${gsc.flagged === 1 ? " falls" : "s fall"} well below the median for their position — ` +
            `roughly ${num(gsc.missedTotal)} clicks over this period, estimated from the site's own data.`)
      );
    }
  }

  if (gsc.pages.length) {
    root.appendChild(el("h3", "", `Pages (${num(gsc.pages.length)})`));
    root.appendChild(
      table(
        ["URL", "Clicks", "Impressions", "CTR", "Position", "Est. missed"],
        gsc.pages.map((p) => [
          p.url, num(p.clicks), num(p.impressions), `${(p.ctr * 100).toFixed(2)}%`,
          p.position.toFixed(1), p.missedClicks ? num(p.missedClicks) : "",
        ]),
        ["url", "num", "num", "num", "num", "num"]
      )
    );
  }

  if (gsc.orphans.length) {
    root.appendChild(el("h3", "", `Earning impressions but missing from the sitemap (${num(gsc.orphans.length)})`));
    root.appendChild(
      table(["URL", "Clicks", "Impressions", "Position"],
        gsc.orphans.map((o) => [o.url, num(o.clicks), num(o.impressions), o.position.toFixed(1)]),
        ["url", "num", "num", "num"])
    );
  }

  if (gsc.cannibalisation.length) {
    root.appendChild(el("h3", "", "Pages competing for the same query"));
    for (const conflict of gsc.cannibalisation) {
      const block = el("div", "issue-block");
      block.appendChild(el("div", "issue-head", `"${conflict.query}" — ${num(conflict.totalImpressions)} impressions`));
      block.appendChild(
        table(["URL", "Impressions", "Position"],
          conflict.pages.map((p) => [p.url, num(p.impressions), p.position.toFixed(1)]),
          ["url", "num", "num"])
      );
      root.appendChild(block);
    }
  }

  if (gsc.queries.length) {
    root.appendChild(el("h3", "", `Queries (${num(gsc.queries.length)})`));
    root.appendChild(
      table(["Query", "URL", "Clicks", "Impressions", "Position"],
        gsc.queries.map((q) => [q.query, q.url, num(q.clicks), num(q.impressions), q.position.toFixed(1)]),
        ["", "url", "num", "num", "num"])
    );
  }
}

/* ---------- per-URL detail ---------- */

function renderGroup(root, group) {
  const head = el("div", "group-head");
  head.appendChild(el("div", "group-title", group.sitemap));
  const facts = [`${num(group.urls.length)} URLs`];
  if (group.oldest || group.newest) facts.push(`lastmod ${group.oldest || "—"} to ${group.newest || "—"}`);
  head.appendChild(el("div", "group-meta", facts.join(" · ")));
  root.appendChild(head);

  for (const row of group.urls) root.appendChild(renderUrlCard(row));
}

function renderUrlCard(row) {
  const card = el("article", "url-card");

  const header = el("div", "url-card-head");
  const severe = (row.issues || []).some((i) => i.severe);
  header.appendChild(el("span", `dot ${severe ? "bad" : row.issues?.length ? "warn" : "ok"}`));
  header.appendChild(el("span", "url-card-url", row.loc));
  card.appendChild(header);

  const data = serpPreviewData(row);
  const serp = el("div", "serp");
  serp.appendChild(el("div", "serp-url", data.crumb));
  serp.appendChild(
    el("div", `serp-title${data.titleMissing ? " missing" : ""}`,
      data.titleMissing ? "(no title — Google will invent one)" : data.title)
  );
  if (data.rating) {
    const rating = el("div", "serp-rating");
    rating.appendChild(el("span", "serp-stars", data.rating.stars));
    rating.appendChild(el("span", "serp-rating-text", data.rating.text));
    serp.appendChild(rating);
  }
  const desc = el("div", "serp-desc");
  if (data.date) desc.appendChild(el("span", "serp-date", `${data.date} — `));
  desc.appendChild(
    data.descriptionMissing
      ? el("span", "missing", "No meta description — Google will pull text from the page instead.")
      : el("span", "", data.description)
  );
  serp.appendChild(desc);
  for (const question of data.faq) serp.appendChild(el("div", "serp-faq-row", question));
  if (data.notes.length) serp.appendChild(el("div", "serp-note", data.notes.join(" · ")));
  card.appendChild(serp);

  if (row.issues?.length) {
    const issues = el("div", "card-issues");
    for (const issue of row.issues) issues.appendChild(el("span", `pill ${issue.severe ? "bad" : ""}`, issue.label));
    card.appendChild(issues);
  }

  const fields = metaFields(row);
  if (fields.length) {
    const grid = el("dl", "field-grid");
    for (const [label, value] of fields) {
      grid.appendChild(el("dt", "", label));
      grid.appendChild(el("dd", "", value));
    }
    card.appendChild(grid);
  }

  if (row.headingTotal) {
    const wrap = el("div", "card-sub");
    const counts = [1, 2, 3, 4, 5, 6].map((n) => `H${n} ${row.headingCounts?.[`h${n}`] || 0}`).join(" · ");
    wrap.appendChild(el("div", "card-sub-head", `Headings — ${counts} · ${row.headingTotal} total`));
    if (row.skippedLevels?.length) {
      wrap.appendChild(el("div", "sev-warn", `Skipped levels: ${[...new Set(row.skippedLevels)].join(", ")}`));
    }
    if (row.emptyHeadings) wrap.appendChild(el("div", "sev-warn", `${row.emptyHeadings} empty heading tag(s)`));
    const list = el("div", "heading-list");
    for (const heading of row.headings || []) {
      const line = el("div", `heading-line level-${heading.level}`);
      line.appendChild(el("span", "heading-tag", `H${heading.level}`));
      line.appendChild(el("span", "", heading.text || "(empty)"));
      list.appendChild(line);
    }
    wrap.appendChild(list);
    card.appendChild(wrap);
  }

  if (row.schema) {
    const wrap = el("div", "card-sub");
    wrap.appendChild(
      el("div", "card-sub-head",
        `Structured data — ${row.schema.types?.join(", ") || "none found"}` +
          (row.schema.errors ? ` · ${row.schema.errors} error(s)` : ""))
    );
    for (const issue of row.schema.issues || []) {
      wrap.appendChild(el("div", issue.severity === "error" ? "sev-error" : "sev-warn", issue.message));
    }
    card.appendChild(wrap);
  }

  if (row.queries?.length) {
    const wrap = el("div", "card-sub");
    wrap.appendChild(el("div", "card-sub-head", "Top queries"));
    wrap.appendChild(
      table(["Query", "Clicks", "Impressions", "Position"],
        row.queries.map((q) => [q.query, num(q.clicks), num(q.impressions), q.position.toFixed(1)]),
        ["", "num", "num", "num"])
    );
    card.appendChild(wrap);
  }

  for (const [title, items] of [
    ["hreflang problems", (row.hreflangIssues || []).map((i) => [i.severity, i.detail])],
    ["Links to broken pages", (row.brokenLinks || []).map((l) => ["error", `${l.to} — ${l.status}${l.anchor ? ` (anchor: "${l.anchor}")` : ""}`])],
  ]) {
    if (!items.length) continue;
    const wrap = el("div", "card-sub");
    wrap.appendChild(el("div", "card-sub-head", title));
    for (const [severity, detail] of items) {
      wrap.appendChild(el("div", severity === "error" ? "sev-error" : "sev-warn", detail));
    }
    card.appendChild(wrap);
  }

  return card;
}
