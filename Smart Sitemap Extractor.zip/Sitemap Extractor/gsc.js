/* Google Search Console.

   Everything before this file tells you what is wrong. This one tells you what
   is worth fixing: a missing meta description on a page with 40,000 impressions
   and one on a page nobody has ever seen are the same finding and completely
   different jobs. */

const GSC_BASE = "https://searchconsole.googleapis.com/webmasters/v3";
const GSC_SCOPE = "https://www.googleapis.com/auth/webmasters.readonly";
const GSC_PAGE_SIZE = 25000; // API maximum per request
const GSC_MAX_PAGES = 20; // 500k rows is far past anything a sitemap tool needs

// Search Console data lags by two to three days. Asking for today returns an
// empty tail that looks like a traffic collapse.
const GSC_LAG_DAYS = 3;

/* ---------- auth ---------- */

let manualToken = "";

function setManualToken(token) {
  manualToken = (token || "").trim();
}

function gscConfigured() {
  return Boolean(chrome?.runtime?.getManifest?.()?.oauth2?.client_id?.includes("apps.googleusercontent.com"));
}

// chrome.identity handles the consent screen and token caching. The manual token
// path exists so the tool can be used without creating a Cloud project, which is
// a lot of setup for someone who just wants to look at one site.
function getToken({ interactive = true } = {}) {
  if (manualToken) return Promise.resolve(manualToken);

  return new Promise((resolve, reject) => {
    if (!chrome?.identity?.getAuthToken) {
      reject(new Error("chrome.identity is unavailable — paste an access token instead"));
      return;
    }
    if (!gscConfigured()) {
      reject(new Error("no OAuth client configured — see the Search Console setup in the README"));
      return;
    }
    chrome.identity.getAuthToken({ interactive }, (token) => {
      const err = chrome.runtime.lastError;
      if (err || !token) reject(new Error(err?.message || "authorization was cancelled"));
      else resolve(token);
    });
  });
}

function dropToken(token) {
  return new Promise((resolve) => {
    if (manualToken || !chrome?.identity?.removeCachedAuthToken) return resolve();
    chrome.identity.removeCachedAuthToken({ token }, resolve);
  });
}

function gscSignOut() {
  manualToken = "";
  return new Promise((resolve) => {
    if (!chrome?.identity?.getAuthToken) return resolve();
    chrome.identity.getAuthToken({ interactive: false }, (token) => {
      chrome.runtime.lastError; // reading it suppresses the unchecked-error warning
      if (!token) return resolve();
      chrome.identity.removeCachedAuthToken({ token }, resolve);
    });
  });
}

/* ---------- requests ---------- */

async function gscFetch(path, opts = {}) {
  return gscRequest(`${GSC_BASE}${path}`, opts);
}

async function gscRequest(url, { method = "GET", body = null, signal } = {}) {
  let token = await getToken();

  const send = () =>
    fetch(url, {
      method,
      signal,
      headers: {
        Authorization: `Bearer ${token}`,
        ...(body ? { "Content-Type": "application/json" } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });

  let res = await send();

  // A cached token that has expired is the single most common failure here, and
  // it is silently fixable: drop it and let Chrome mint a fresh one.
  if (res.status === 401) {
    await dropToken(token);
    token = await getToken({ interactive: true });
    res = await send();
  }

  if (!res.ok) {
    let detail = "";
    try {
      detail = (await res.json())?.error?.message || "";
    } catch {
      /* non-JSON error body */
    }
    if (res.status === 403) {
      throw new Error(
        detail.includes("has not been used") || detail.includes("disabled")
          ? "the Search Console API is not enabled on your Google Cloud project"
          : detail || "access denied — is this account verified for the property?"
      );
    }
    throw new Error(detail || `HTTP ${res.status}`);
  }

  return res.json();
}

/* ---------- properties ---------- */

async function gscListSites(signal) {
  const data = await gscFetch("/sites", { signal });
  return (data.siteEntry || [])
    .filter((s) => s.permissionLevel && s.permissionLevel !== "siteUnverifiedUser")
    .map((s) => ({ siteUrl: s.siteUrl, permission: s.permissionLevel }))
    .sort((a, b) => a.siteUrl.localeCompare(b.siteUrl));
}

// Properties come in two shapes: a URL prefix ("https://example.com/") and a
// domain property ("sc-domain:example.com") covering every subdomain and scheme.
function matchSiteToOrigin(sites, origin) {
  let host = "";
  try {
    host = new URL(origin).hostname.toLowerCase();
  } catch {
    return null;
  }
  const bare = host.replace(/^www\./, "");

  const exact = sites.find((s) => normUrl(s.siteUrl) === normUrl(origin));
  if (exact) return exact.siteUrl;

  const domainProp = sites.find(
    (s) => s.siteUrl.startsWith("sc-domain:") && s.siteUrl.slice(10).toLowerCase() === bare
  );
  if (domainProp) return domainProp.siteUrl;

  const sameHost = sites.find((s) => {
    try {
      return new URL(s.siteUrl).hostname.toLowerCase().replace(/^www\./, "") === bare;
    } catch {
      return false;
    }
  });
  return sameHost?.siteUrl || null;
}

/* ---------- dates ---------- */

function isoDay(date) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function gscDateRange(days) {
  const end = new Date();
  end.setDate(end.getDate() - GSC_LAG_DAYS);
  const start = new Date(end);
  start.setDate(start.getDate() - (days - 1));
  return { startDate: isoDay(start), endDate: isoDay(end), days };
}

/* ---------- search analytics ---------- */

async function gscFetchPages(siteUrl, range, { signal, onProgress } = {}) {
  const rows = [];

  for (let page = 0; page < GSC_MAX_PAGES; page++) {
    if (signal?.aborted) break;

    const data = await gscFetch(`/sites/${encodeURIComponent(siteUrl)}/searchAnalytics/query`, {
      method: "POST",
      signal,
      body: {
        startDate: range.startDate,
        endDate: range.endDate,
        dimensions: ["page"],
        rowLimit: GSC_PAGE_SIZE,
        startRow: page * GSC_PAGE_SIZE,
        type: "web",
      },
    });

    const batch = data.rows || [];
    for (const r of batch) {
      rows.push({
        url: r.keys[0],
        clicks: r.clicks || 0,
        impressions: r.impressions || 0,
        ctr: r.ctr || 0,
        position: r.position || 0,
      });
    }

    onProgress?.({ rows: rows.length });
    if (batch.length < GSC_PAGE_SIZE) break; // last page
  }

  return rows;
}

/* ---------- joining ---------- */

// Search Console reports the URL it considers canonical, which is not always the
// URL in the sitemap. Matching on the normalized form absorbs the usual
// trailing-slash and host-case differences.
function joinGsc(rows, gscRows) {
  const index = new Map();
  for (const row of rows) {
    const key = normUrl(row.loc);
    if (key) index.set(key, row);
    // Clear any previous run's figures so a shorter range can't leave stale ones.
    row.gsc = null;
  }

  const orphans = [];
  let matched = 0;
  const totals = { clicks: 0, impressions: 0 };

  for (const entry of gscRows) {
    totals.clicks += entry.clicks;
    totals.impressions += entry.impressions;

    const key = normUrl(entry.url);
    const row = key ? index.get(key) : null;

    if (row) {
      row.gsc = entry;
      matched++;
    } else if (entry.impressions > 0) {
      orphans.push(entry);
    }
  }

  orphans.sort((a, b) => b.clicks - a.clicks || b.impressions - a.impressions);

  return {
    matched,
    orphans,
    totals,
    // Search Console usually omits zero-impression pages entirely, but can also
    // return them with zeros. Both mean the same thing: nobody saw this page.
    unseen: rows.filter((r) => !(r.gsc?.impressions > 0)).length,
  };
}

/* ---------- CTR benchmarking ---------- */

// Rather than compare against a generic industry CTR curve, compare each page
// against this site's own median CTR at the same position. A curve invented
// elsewhere says nothing about a niche B2B site; the site's own data does.
const POSITION_BUCKETS = [
  { name: "1–3", min: 0, max: 3.5 },
  { name: "4–6", min: 3.5, max: 6.5 },
  { name: "7–10", min: 6.5, max: 10.5 },
  { name: "11–20", min: 10.5, max: 20.5 },
  { name: "21+", min: 20.5, max: Infinity },
];

const MIN_IMPRESSIONS_FOR_BENCHMARK = 10;
const MIN_SAMPLE_PER_BUCKET = 5;
const MIN_IMPRESSIONS_TO_FLAG = 50;
const UNDERPERFORM_RATIO = 0.6;

function median(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function bucketFor(position) {
  return POSITION_BUCKETS.find((b) => position > b.min && position <= b.max) || POSITION_BUCKETS[0];
}

function benchmarkCtr(rows) {
  const samples = new Map();
  for (const bucket of POSITION_BUCKETS) samples.set(bucket.name, []);

  for (const row of rows) {
    const g = row.gsc;
    if (!g || g.impressions < MIN_IMPRESSIONS_FOR_BENCHMARK) continue;
    samples.get(bucketFor(g.position).name).push(g.ctr);
  }

  const benchmarks = new Map();
  for (const [name, values] of samples) {
    if (values.length >= MIN_SAMPLE_PER_BUCKET) benchmarks.set(name, median(values));
  }

  let flagged = 0;
  let missedTotal = 0;

  for (const row of rows) {
    row.ctrBucket = null;
    row.expectedCtr = null;
    row.missedClicks = 0;
    row.underperforming = false;

    const g = row.gsc;
    if (!g || !g.impressions) continue;

    const bucket = bucketFor(g.position);
    const expected = benchmarks.get(bucket.name);
    row.ctrBucket = bucket.name;
    if (expected == null) continue;

    row.expectedCtr = expected;

    if (g.impressions >= MIN_IMPRESSIONS_TO_FLAG && g.ctr < expected * UNDERPERFORM_RATIO) {
      row.underperforming = true;
      // Clicks this page would have earned at the site's own median CTR for its
      // position. An estimate, and labelled as one everywhere it is shown.
      row.missedClicks = Math.round((expected - g.ctr) * g.impressions);
      flagged++;
      missedTotal += row.missedClicks;
    }
  }

  return {
    benchmarks: [...benchmarks].map(([name, ctr]) => ({ bucket: name, ctr })),
    flagged,
    missedTotal,
    usable: benchmarks.size > 0,
  };
}

/* ---------- URL inspection ---------- */

// A different API version from search analytics, so it needs the full URL.
const GSC_INSPECT_ENDPOINT = "https://searchconsole.googleapis.com/v1/urlInspection/index:inspect";

// Google's published limits: 2,000 per day and 600 per minute, per property.
// This is deliberately not a "check every URL" feature — the API was built for
// sampling across templates, not for sweeping a whole sitemap.
const INSPECT_DAILY_QUOTA = 2000;
const INSPECT_CONCURRENCY = 4;
const INSPECT_DEFAULT_BATCH = 100;

function quotaKey(siteUrl) {
  // Google's reset boundary isn't documented precisely, so this is a local
  // estimate to stop you burning the budget by accident, not Google's counter.
  return `inspectQuota:${siteUrl}:${new Date().toISOString().slice(0, 10)}`;
}

async function getInspectUsage(siteUrl) {
  if (!chrome?.storage?.local) return 0;
  try {
    const key = quotaKey(siteUrl);
    const stored = await chrome.storage.local.get(key);
    return stored?.[key] || 0;
  } catch {
    return 0;
  }
}

async function addInspectUsage(siteUrl, count) {
  if (!chrome?.storage?.local) return;
  try {
    const key = quotaKey(siteUrl);
    const used = await getInspectUsage(siteUrl);
    await chrome.storage.local.set({ [key]: used + count });
  } catch {
    /* quota tracking is a convenience, never a blocker */
  }
}

function readInspection(data) {
  const result = data?.inspectionResult || {};
  const index = result.indexStatusResult || {};

  const out = {
    verdict: index.verdict || "",
    coverage: index.coverageState || "",
    robotsState: index.robotsTxtState || "",
    indexingState: index.indexingState || "",
    pageFetch: index.pageFetchState || "",
    lastCrawl: index.lastCrawlTime ? index.lastCrawlTime.slice(0, 10) : "",
    googleCanonical: index.googleCanonical || "",
    userCanonical: index.userCanonical || "",
    inSitemap: Array.isArray(index.sitemap) && index.sitemap.length > 0,
    crawledAs: index.crawledAs || "",
    link: result.inspectionResultLink || "",
  };

  // PASS means indexed. Everything else is read from the human-readable
  // coverage string, which is where "Crawled - currently not indexed" lives.
  out.indexed = out.verdict === "PASS";
  out.crawledNotIndexed = /crawled.*not indexed/i.test(out.coverage);
  out.discoveredNotIndexed = /discovered.*not indexed/i.test(out.coverage);

  // Google overruling the page's own canonical is one of the most valuable
  // single fields the API returns.
  out.canonicalOverridden = Boolean(
    out.googleCanonical &&
      out.userCanonical &&
      normUrl(out.googleCanonical) !== normUrl(out.userCanonical)
  );

  return out;
}

async function inspectUrls(targets, siteUrl, { signal, onProgress } = {}) {
  let cursor = 0;
  let done = 0;
  let failed = 0;
  let quotaHit = false;

  async function worker() {
    while (cursor < targets.length && !quotaHit) {
      if (signal?.aborted) return;
      const row = targets[cursor++];

      try {
        const data = await gscRequest(GSC_INSPECT_ENDPOINT, {
          method: "POST",
          signal,
          body: { inspectionUrl: row.loc, siteUrl, languageCode: "en-US" },
        });
        row.inspection = readInspection(data);
        row.inspectionError = "";
      } catch (err) {
        if (err.name === "AbortError") return;
        // A quota error doesn't say which limit was hit, so stop rather than
        // keep hammering — the per-minute cap needs a pause, the daily one a day.
        if (/quota|rate limit|429/i.test(err.message)) {
          quotaHit = true;
          row.inspectionError = "quota exhausted";
        } else {
          row.inspectionError = err.message;
          failed++;
        }
      }

      done++;
      onProgress?.({ done, total: targets.length, failed });
    }
  }

  await Promise.all(Array.from({ length: Math.min(INSPECT_CONCURRENCY, targets.length) }, worker));
  await addInspectUsage(siteUrl, done);

  const indexed = targets.filter((r) => r.inspection?.indexed).length;
  const notIndexed = targets.filter((r) => r.inspection && !r.inspection.indexed).length;

  return { done, failed, indexed, notIndexed, quotaHit, aborted: Boolean(signal?.aborted) };
}

/* ---------- query-level data ---------- */

const MAX_QUERIES_PER_PAGE = 10;

async function gscFetchQueries(siteUrl, range, { signal, onProgress } = {}) {
  const rows = [];

  for (let page = 0; page < GSC_MAX_PAGES; page++) {
    if (signal?.aborted) break;

    const data = await gscFetch(`/sites/${encodeURIComponent(siteUrl)}/searchAnalytics/query`, {
      method: "POST",
      signal,
      body: {
        startDate: range.startDate,
        endDate: range.endDate,
        dimensions: ["page", "query"],
        rowLimit: GSC_PAGE_SIZE,
        startRow: page * GSC_PAGE_SIZE,
        type: "web",
      },
    });

    const batch = data.rows || [];
    for (const r of batch) {
      rows.push({
        url: r.keys[0],
        query: r.keys[1],
        clicks: r.clicks || 0,
        impressions: r.impressions || 0,
        ctr: r.ctr || 0,
        position: r.position || 0,
      });
    }

    onProgress?.({ rows: rows.length });
    if (batch.length < GSC_PAGE_SIZE) break;
  }

  return rows;
}

function joinQueries(rows, queryRows) {
  const index = new Map();
  for (const row of rows) {
    const key = normUrl(row.loc);
    if (key) index.set(key, row);
    row.queries = [];
  }

  let matched = 0;
  for (const entry of queryRows) {
    const key = normUrl(entry.url);
    const row = key ? index.get(key) : null;
    if (!row) continue;
    row.queries.push(entry);
    matched++;
  }

  for (const row of rows) {
    if (!row.queries.length) continue;
    row.queries.sort((a, b) => b.impressions - a.impressions);
    row.queries = row.queries.slice(0, MAX_QUERIES_PER_PAGE);
    row.topQuery = row.queries[0];
  }

  return { matched, pagesWithQueries: rows.filter((r) => r.queries.length).length };
}

/* ---------- cannibalization ---------- */

const CANNIBAL_MIN_IMPRESSIONS = 30;
const CANNIBAL_MAX_POSITION = 30;

// Two or more of a site's own URLs competing for the same query. Google picks
// one and the others dilute it; splitting the signals usually means neither
// ranks as well as a single consolidated page would.
function findCannibalization(queryRows, rows) {
  const known = new Set();
  for (const row of rows) {
    const key = normUrl(row.loc);
    if (key) known.add(key);
  }

  const byQuery = new Map();
  for (const entry of queryRows) {
    if (entry.impressions < CANNIBAL_MIN_IMPRESSIONS) continue;
    if (entry.position > CANNIBAL_MAX_POSITION) continue;
    const key = normUrl(entry.url);
    if (!key || !known.has(key)) continue;

    if (!byQuery.has(entry.query)) byQuery.set(entry.query, []);
    byQuery.get(entry.query).push({ ...entry, key });
  }

  const conflicts = [];
  for (const [query, pages] of byQuery) {
    if (pages.length < 2) continue;
    pages.sort((a, b) => b.impressions - a.impressions);
    conflicts.push({
      query,
      pages,
      totalImpressions: pages.reduce((n, p) => n + p.impressions, 0),
      totalClicks: pages.reduce((n, p) => n + p.clicks, 0),
      bestPosition: Math.min(...pages.map((p) => p.position)),
    });
  }

  conflicts.sort((a, b) => b.totalImpressions - a.totalImpressions);

  // Mark the rows involved so they can be filtered in the list.
  const involved = new Set();
  for (const conflict of conflicts) for (const page of conflict.pages) involved.add(page.key);
  for (const row of rows) {
    const key = normUrl(row.loc);
    row.cannibalized = key ? involved.has(key) : false;
  }

  return { conflicts, affectedPages: involved.size };
}

/* ---------- title / query alignment ---------- */

// Deliberately conservative: only flagged when *none* of the query's words
// appear in the title. Anything cleverer would need per-language stopword lists
// and would fire constantly on legitimate titles.
function checkQueryAlignment(rows) {
  let flagged = 0;

  for (const row of rows) {
    row.queryMismatch = false;
    const top = row.topQuery;
    if (!top || !row.title || top.impressions < CANNIBAL_MIN_IMPRESSIONS) continue;

    const normalize = (s) =>
      s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

    const title = normalize(row.title);
    const words = normalize(top.query)
      .split(/[\s\-_/,.:;!?"'()]+/)
      .filter((w) => w.length >= 3);

    if (!words.length) continue;
    if (!words.some((w) => title.includes(w))) {
      row.queryMismatch = true;
      flagged++;
    }
  }

  return { flagged };
}
