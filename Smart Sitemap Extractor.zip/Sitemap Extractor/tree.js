/* URL tree visualisation.

   Renders the sitemap as a directory tree, drawn left to right. The value over
   the table view is shape: you can see at a glance whether a site is flat or
   deeply nested, where the bulk of the URLs sit, and which branches contain
   problems — a red node anywhere tells you which section to look at. */

const TREE_ROW = 22;          // vertical space per leaf
const TREE_PAD = 16;
const TREE_MAX_LEAVES = 400;  // beyond this the picture stops being readable
const TREE_MAX_CHILDREN = 25; // per parent, before collapsing into "N more"

/* ---------- build ---------- */

function makeNode(name, depth) {
  return { name, depth, children: new Map(), count: 0, rows: [], collapsed: 0 };
}

// Splits every URL into path segments and merges them into a trie. A URL that
// ends at an existing branch attaches to that node rather than creating a
// duplicate, so /brakes/ and /brakes/discs share one "brakes".
function buildUrlTree(list, { labelMode = "compact", maxDepth = 0 } = {}) {
  let host = "";
  try {
    host = unicodeHost(new URL(list[0].loc).hostname);
  } catch {
    host = "site";
  }

  const root = makeNode(labelMode === "full" ? "/" : host, 0);
  root.isRoot = true;

  for (const row of list) {
    let parsed;
    try {
      parsed = new URL(row.loc);
    } catch {
      continue;
    }

    // The full-path mode mirrors the address bar: protocol, then host, then
    // each directory. Compact mode starts at the host, which is easier to read.
    const parts =
      labelMode === "full"
        ? [`${parsed.protocol.replace(":", "")}/`, `${unicodeHost(parsed.hostname)}/`]
        : [];

    let path = parsed.pathname;
    try {
      path = decodeURI(path);
    } catch {
      /* malformed escapes: use as-is */
    }
    const segments = path.split("/").filter(Boolean);
    for (const segment of segments) {
      parts.push(labelMode === "full" ? `${segment}/` : segment);
    }

    let node = root;
    root.count++;
    if (!segments.length) root.rows.push(row);

    for (let i = 0; i < parts.length; i++) {
      if (maxDepth && node.depth >= maxDepth) {
        node.collapsed++;
        break;
      }
      const key = parts[i];
      if (!node.children.has(key)) node.children.set(key, makeNode(key, node.depth + 1));
      node = node.children.get(key);
      node.count++;
      if (i === parts.length - 1) node.rows.push(row);
    }
  }

  return root;
}

/* ---------- health ---------- */

// A node is as bad as its worst descendant, so a problem deep in a branch is
// visible from the top without expanding anything.
function scoreTree(node, issuesFor, severeSet) {
  let state = "ok";
  let problems = 0;

  for (const row of node.rows) {
    const issues = issuesFor(row);
    if (issues.some((i) => severeSet.has(i))) {
      state = "bad";
      problems++;
    } else if (issues.length) {
      if (state === "ok") state = "warn";
      problems++;
    }
  }

  for (const child of node.children.values()) {
    const childState = scoreTree(child, issuesFor, severeSet);
    problems += child.problems;
    if (childState === "bad") state = "bad";
    else if (childState === "warn" && state === "ok") state = "warn";
  }

  node.state = state;
  node.problems = problems;
  return state;
}

/* ---------- layout ---------- */

// Leaves get sequential rows; a parent sits at the midpoint of its children.
// That is the classic tidy-tree arrangement and is enough for this shape of data.
function layoutTree(root) {
  const nodes = [];
  const edges = [];
  let leafIndex = 0;
  let truncated = false;

  const widestAtDepth = new Map();

  function visit(node, parent) {
    const label = node.name + (node.collapsed ? ` (+${node.collapsed})` : "");
    widestAtDepth.set(node.depth, Math.max(widestAtDepth.get(node.depth) || 0, label.length));

    const children = [...node.children.values()].sort((a, b) => b.count - a.count);
    const shown = children.slice(0, TREE_MAX_CHILDREN);
    const hidden = children.length - shown.length;

    node.label = label;
    nodes.push(node);
    if (parent) edges.push({ from: parent, to: node });

    if (!shown.length || leafIndex >= TREE_MAX_LEAVES) {
      if (leafIndex >= TREE_MAX_LEAVES) truncated = true;
      node.y = leafIndex++ * TREE_ROW;
      return;
    }

    const ys = [];
    for (const child of shown) {
      visit(child, node);
      ys.push(child.y);
    }

    if (hidden) {
      const more = makeNode(`… ${hidden} more`, node.depth + 1);
      more.isMore = true;
      more.state = "ok";
      more.count = children.slice(TREE_MAX_CHILDREN).reduce((n, c) => n + c.count, 0);
      more.label = more.name;
      more.y = leafIndex++ * TREE_ROW;
      nodes.push(more);
      edges.push({ from: node, to: more });
      ys.push(more.y);
    }

    node.y = (Math.min(...ys) + Math.max(...ys)) / 2;
  }

  visit(root, null);

  // Column positions follow the widest label in each column, so text never
  // overlaps the next level.
  const columnX = new Map();
  let x = TREE_PAD;
  const depths = [...widestAtDepth.keys()].sort((a, b) => a - b);
  for (const depth of depths) {
    columnX.set(depth, x);
    x += Math.min(widestAtDepth.get(depth), 28) * 6.6 + 46;
  }
  for (const node of nodes) node.x = columnX.get(node.depth) ?? TREE_PAD;

  return {
    nodes,
    edges,
    width: x + TREE_PAD,
    height: leafIndex * TREE_ROW + TREE_PAD * 2,
    truncated,
  };
}

/* ---------- render ---------- */

function renderTreeSvg(layout, { onSelect } = {}) {
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", `0 0 ${layout.width} ${layout.height}`);
  svg.setAttribute("width", String(layout.width));
  svg.setAttribute("height", String(layout.height));
  svg.classList.add("url-tree");

  const offset = TREE_PAD;

  for (const edge of layout.edges) {
    const path = document.createElementNS(NS, "path");
    const x1 = edge.from.x;
    const y1 = edge.from.y + offset;
    const x2 = edge.to.x;
    const y2 = edge.to.y + offset;
    const mid = (x1 + x2) / 2;
    path.setAttribute("d", `M${x1},${y1} C${mid},${y1} ${mid},${y2} ${x2},${y2}`);
    path.setAttribute("class", "tree-edge");
    svg.appendChild(path);
  }

  for (const node of layout.nodes) {
    const group = document.createElementNS(NS, "g");
    group.setAttribute("class", `tree-node ${node.state || "ok"}${node.isMore ? " more" : ""}`);

    const circle = document.createElementNS(NS, "circle");
    circle.setAttribute("cx", String(node.x));
    circle.setAttribute("cy", String(node.y + offset));
    circle.setAttribute("r", node.isRoot ? "5.5" : "4.5");
    group.appendChild(circle);

    const text = document.createElementNS(NS, "text");
    const leaf = node.children.size === 0;
    // Labels sit outside the tree on both ends so they never cross an edge.
    text.setAttribute("x", String(node.x + (leaf ? 9 : -9)));
    text.setAttribute("y", String(node.y + offset + 3.5));
    text.setAttribute("text-anchor", leaf ? "start" : "end");
    text.textContent = node.label;
    group.appendChild(text);

    const title = document.createElementNS(NS, "title");
    title.textContent = node.isMore
      ? `${node.count} URLs in collapsed branches`
      : `${node.count} URL${node.count === 1 ? "" : "s"}${node.problems ? `, ${node.problems} with issues` : ""}`;
    group.appendChild(title);

    if (!node.isMore && onSelect) {
      group.classList.add("clickable");
      group.addEventListener("click", () => onSelect(node));
    }

    svg.appendChild(group);
  }

  return svg;
}

// Every URL beneath a node, so clicking a branch can filter the list.
function collectRows(node, out = []) {
  for (const row of node.rows) out.push(row);
  for (const child of node.children.values()) collectRows(child, out);
  return out;
}
