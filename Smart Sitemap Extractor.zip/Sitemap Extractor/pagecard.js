/* Shared page-detail logic.

   The popup and the printed report show the same per-URL information but style
   it differently. Keeping the *data* here — what the SERP preview says, which
   metadata fields a row has — means the two can never drift apart, while each
   builds its own DOM. */

// Google truncates by pixel width; these are the usual desktop cut-off points
// expressed in half-width units, which is what displayWidth measures.
const SERP_TITLE_WIDTH = 60;
const SERP_DESC_WIDTH = 158;

function truncateToWidth(text, max) {
  if (!text) return { text: "", truncated: false };
  if (displayWidth(text) <= max) return { text, truncated: false };

  let out = "";
  let width = 0;
  for (const ch of text) {
    const w = displayWidth(ch);
    if (width + w > max - 1) break;
    out += ch;
    width += w;
  }
  return { text: out.trimEnd() + "…", truncated: true };
}

// Everything needed to draw a Google result, derived from what the page
// actually declares. Structured data feeds the extras, which is what makes the
// preview a check on the markup rather than decoration.
function serpPreviewData(row) {
  const rich = row.schema?.rich;
  const data = { crumb: row.loc, notes: [] };

  try {
    const parsed = new URL(row.loc);
    const trail = rich?.breadcrumbs?.length
      ? rich.breadcrumbs
      : decodeURI(parsed.pathname).split("/").filter(Boolean);
    data.crumb = [unicodeHost(parsed.hostname), ...trail].join(" › ");
  } catch {
    /* keep the raw URL */
  }

  const title = truncateToWidth(row.title || "", SERP_TITLE_WIDTH);
  data.title = row.title ? title.text : "";
  data.titleMissing = !row.title;

  const desc = truncateToWidth(row.description || "", SERP_DESC_WIDTH);
  data.description = row.description ? desc.text : "";
  data.descriptionMissing = !row.description;

  data.date = isoDate(row.published || rich?.datePublished || "");

  if (rich?.rating && Number.isFinite(rich.rating.value)) {
    const best = rich.rating.best || 5;
    const value = Math.max(0, Math.min(5, (rich.rating.value / best) * 5));
    const full = Math.floor(value);
    const half = value - full >= 0.25;
    data.rating = {
      stars: "★".repeat(full) + (half ? "◐" : "") + "☆".repeat(Math.max(0, 5 - full - (half ? 1 : 0))),
      text: `${rich.rating.value}/${best}` + (rich.rating.count ? ` · ${rich.rating.count} reviews` : ""),
    };
  }

  data.faq = rich?.faq?.slice(0, 3) || [];

  if (title.truncated) data.notes.push("title is cut off");
  if (desc.truncated) data.notes.push("description is cut off");
  if (rich?.breadcrumbs?.length) data.notes.push("breadcrumbs from BreadcrumbList");
  if (rich?.rating) data.notes.push("stars from AggregateRating");
  if (data.faq.length) data.notes.push(`${data.faq.length} FAQ rows from FAQPage`);

  return data;
}

// Label/value pairs for the metadata table, as plain strings. Anything needing
// custom rendering (the heading outline, width badges) is handled by the caller.
function metaFields(row) {
  const fmt = (n) => (n == null ? "" : Number(n).toLocaleString());
  const fields = [];
  const push = (label, value) => {
    if (value) fields.push([label, value]);
  };

  if (row.statusState) {
    push("Status",
      row.statusState === "failed"
        ? row.statusError || "unreachable"
        : `${row.status}${row.method === "GET" ? " (HEAD refused)" : ""}`);
  }
  if (row.ms != null) push("Response", `${row.ms} ms${row.bytes ? ` · ${Math.round(row.bytes / 1024)} KB` : ""}`);

  if (row.gsc) {
    push("Search Console",
      `${fmt(row.gsc.clicks)} clicks · ${fmt(row.gsc.impressions)} impressions · ${(row.gsc.ctr * 100).toFixed(2)}% CTR · position ${row.gsc.position.toFixed(1)}`);
  }
  if (row.underperforming && row.expectedCtr != null) {
    push("CTR gap",
      `${(row.gsc.ctr * 100).toFixed(2)}% against a site median of ${(row.expectedCtr * 100).toFixed(2)}% for position ${row.ctrBucket} — roughly ${fmt(row.missedClicks)} missed clicks, estimated from this site's own data`);
  }
  if (row.topQuery) {
    push("Top query", `${row.topQuery.query} (${fmt(row.topQuery.impressions)} impressions, position ${row.topQuery.position.toFixed(1)})`);
  }
  if (row.inspection) {
    push("Google index",
      `${row.inspection.indexed ? "Indexed" : "Not indexed"}${row.inspection.coverage ? ` — ${row.inspection.coverage}` : ""}${row.inspection.lastCrawl ? ` · last crawled ${row.inspection.lastCrawl}` : ""}`);
    if (row.inspection.canonicalOverridden) {
      push("Google's canonical", `${displayUrl(row.inspection.googleCanonical)} — overrules the page's own ${displayUrl(row.inspection.userCanonical)}`);
    }
  }
  if (row.metaState === "failed") push("Could not read page", row.metaError || "unknown error");

  push("Published", row.published);
  push("Modified", row.modified || isoDate(row.lastmod));
  push("Language", row.lang || row.ogLocale);
  if (row.words != null) push("Words", fmt(row.words));
  push("Canonical", row.canonical ? displayUrl(row.canonical) : "");
  push("Robots", row.robots);
  if (row.robotsBlocked) push("robots.txt", `Blocked — ${row.robotsRule}`);
  if (row.outLinks || row.inlinkCount != null) {
    push("Links", `${fmt(row.inlinkCount ?? 0)} inbound · ${fmt(row.internalLinkCount ?? 0)} outbound internal · ${fmt(row.externalLinkCount ?? 0)} external`);
  }
  if (row.topAnchors?.length) push("Linked here as", row.topAnchors.map((a) => `${a.text} (${a.count})`).join(" · "));
  if (row.charset && row.charsetFrom === "meta" && row.charset !== "utf-8") push("Charset", `${row.charset} (declared in meta)`);
  push("From sitemap", row.source ? displayUrl(row.source) : "");

  return fields;
}
