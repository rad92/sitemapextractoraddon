/* Minimal .xlsx writer.

   A CSV is one flat table by definition, so "one tab per data set" means a real
   workbook. Rather than bundle a spreadsheet library, this writes the handful of
   XML parts Excel actually requires and packs them into a ZIP. Strings are
   written inline, which skips the shared-strings table entirely at the cost of
   slightly larger files — a fair trade for far less that can go wrong. */

/* ---------- ZIP ---------- */

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

async function deflateRaw(bytes) {
  if (typeof CompressionStream === "undefined") return null;
  try {
    const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  } catch {
    return null; // fall back to storing uncompressed
  }
}

function writeU32(view, offset, value) {
  view.setUint32(offset, value, true);
}
function writeU16(view, offset, value) {
  view.setUint16(offset, value, true);
}

// Builds a ZIP archive from [{ name, bytes }]. Uses deflate when the browser
// offers it and falls back to stored entries, which are equally valid.
async function makeZip(files) {
  const encoder = new TextEncoder();
  const entries = [];

  for (const file of files) {
    const raw = typeof file.data === "string" ? encoder.encode(file.data) : file.data;
    const compressed = await deflateRaw(raw);
    const useDeflate = compressed && compressed.length < raw.length;
    entries.push({
      name: encoder.encode(file.name),
      raw,
      body: useDeflate ? compressed : raw,
      method: useDeflate ? 8 : 0,
      crc: crc32(raw),
    });
  }

  const localParts = [];
  const centralParts = [];
  let offset = 0;

  for (const entry of entries) {
    const header = new Uint8Array(30 + entry.name.length);
    const view = new DataView(header.buffer);
    writeU32(view, 0, 0x04034b50);
    writeU16(view, 4, 20);
    writeU16(view, 6, 0);
    writeU16(view, 8, entry.method);
    writeU16(view, 10, 0); // time
    writeU16(view, 12, 0x21); // date: 1980-01-01, deterministic output
    writeU32(view, 14, entry.crc);
    writeU32(view, 18, entry.body.length);
    writeU32(view, 22, entry.raw.length);
    writeU16(view, 26, entry.name.length);
    writeU16(view, 28, 0);
    header.set(entry.name, 30);

    localParts.push(header, entry.body);

    const central = new Uint8Array(46 + entry.name.length);
    const cview = new DataView(central.buffer);
    writeU32(cview, 0, 0x02014b50);
    writeU16(cview, 4, 20);
    writeU16(cview, 6, 20);
    writeU16(cview, 8, 0);
    writeU16(cview, 10, entry.method);
    writeU16(cview, 12, 0);
    writeU16(cview, 14, 0x21);
    writeU32(cview, 16, entry.crc);
    writeU32(cview, 20, entry.body.length);
    writeU32(cview, 24, entry.raw.length);
    writeU16(cview, 28, entry.name.length);
    writeU16(cview, 30, 0);
    writeU16(cview, 32, 0);
    writeU16(cview, 34, 0);
    writeU16(cview, 36, 0);
    writeU32(cview, 38, 0);
    writeU32(cview, 42, offset);
    central.set(entry.name, 46);
    centralParts.push(central);

    offset += header.length + entry.body.length;
  }

  const centralSize = centralParts.reduce((n, p) => n + p.length, 0);
  const end = new Uint8Array(22);
  const eview = new DataView(end.buffer);
  writeU32(eview, 0, 0x06054b50);
  writeU16(eview, 8, entries.length);
  writeU16(eview, 10, entries.length);
  writeU32(eview, 12, centralSize);
  writeU32(eview, 16, offset);

  return new Blob([...localParts, ...centralParts, end], { type: "application/zip" });
}

/* ---------- sheet XML ---------- */

function xmlEscape(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    // Control characters are illegal in XML 1.0 and Excel refuses the file.
    .replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, "");
}

function columnName(index) {
  let name = "";
  let n = index;
  while (n >= 0) {
    name = String.fromCharCode(65 + (n % 26)) + name;
    n = Math.floor(n / 26) - 1;
  }
  return name;
}

function sheetXml(rows) {
  const out = [
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
    "<sheetData>",
  ];

  rows.forEach((row, r) => {
    out.push(`<row r="${r + 1}">`);
    row.forEach((cell, c) => {
      if (cell == null || cell === "") return;
      const ref = `${columnName(c)}${r + 1}`;
      // Numbers are written as numbers so they sort and total correctly; the
      // header row is always text, and long digit strings (IDs) stay text too.
      if (typeof cell === "number" && Number.isFinite(cell)) {
        out.push(`<c r="${ref}"><v>${cell}</v></c>`);
      } else {
        out.push(`<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(cell)}</t></is></c>`);
      }
    });
    out.push("</row>");
  });

  out.push("</sheetData></worksheet>");
  return out.join("");
}

// Excel rejects these characters in a tab name, and caps the length at 31.
function safeSheetName(name, used) {
  let clean = String(name).replace(/[\\/?*[\]:]/g, " ").trim().slice(0, 31) || "Sheet";
  let candidate = clean;
  let n = 2;
  while (used.has(candidate.toLowerCase())) {
    const suffix = ` ${n++}`;
    candidate = clean.slice(0, 31 - suffix.length) + suffix;
  }
  used.add(candidate.toLowerCase());
  return candidate;
}

/* ---------- workbook ---------- */

// sheets: [{ name, rows: [[cell, ...], ...] }]
async function buildXlsx(sheets) {
  const used = new Set();
  const named = sheets
    .filter((s) => s && s.rows && s.rows.length)
    .map((s) => ({ name: safeSheetName(s.name, used), rows: s.rows }));

  if (!named.length) named.push({ name: safeSheetName("Empty", used), rows: [["No data"]] });

  const files = [
    {
      name: "[Content_Types].xml",
      data:
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
        '<Default Extension="xml" ContentType="application/xml"/>' +
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
        named
          .map((_, i) =>
            `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`)
          .join("") +
        "</Types>",
    },
    {
      name: "_rels/.rels",
      data:
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
        "</Relationships>",
    },
    {
      name: "xl/workbook.xml",
      data:
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ' +
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' +
        named
          .map((s, i) => `<sheet name="${xmlEscape(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`)
          .join("") +
        "</sheets></workbook>",
    },
    {
      name: "xl/_rels/workbook.xml.rels",
      data:
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
        named
          .map((_, i) =>
            `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`)
          .join("") +
        "</Relationships>",
    },
    ...named.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(s.rows) })),
  ];

  return makeZip(files);
}
