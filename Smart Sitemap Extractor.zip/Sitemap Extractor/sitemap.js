/* Sitemap discovery, parsing and crawling. */

const MAX_SITEMAPS = 200;
const SITEMAP_CONCURRENCY = 5;

// Ordered roughly by how often they're right. Covers WordPress, Yoast, RankMath,
// Shopify, Squarespace, Wix, Ghost, Drupal, Magento, Next.js and hand-rolled sites.
const CANDIDATES = [
  "/sitemap.xml",
  "/sitemap_index.xml",
  "/sitemap-index.xml",
  "/sitemapindex.xml",
  "/wp-sitemap.xml",
  "/sitemap.xml.gz",
  "/sitemap_index.xml.gz",
  "/sitemap/sitemap.xml",
  "/sitemap/index.xml",
  "/sitemaps/sitemap.xml",
  "/sitemaps.xml",
  "/sitemap1.xml",
  "/sitemap-1.xml",
  "/page-sitemap.xml",
  "/post-sitemap.xml",
  "/server-sitemap.xml",
  "/pub/media/sitemap.xml",
  "/sitemap.txt",
  "/sitemap.php",
];

/* ---------- fetch ---------- */

// Transparently gunzips. Detects via magic bytes rather than Content-Type, since
// servers routinely mislabel .xml.gz as text/xml or application/octet-stream.
// Returns { text, lastModified }: the server's own Last-Modified header for the
// sitemap file is a second, independent signal about when it was last touched.
async function loadText(url, signal) {
  const res = await fetch(url, { redirect: "follow", credentials: "omit", signal });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  const lastModified = res.headers.get("last-modified") || "";
  const buf = await res.arrayBuffer();
  const head = new Uint8Array(buf.slice(0, 2));

  if (head[0] === 0x1f && head[1] === 0x8b) {
    try {
      const stream = new Blob([buf]).stream().pipeThrough(new DecompressionStream("gzip"));
      return { text: await new Response(stream).text(), lastModified };
    } catch {
      throw new Error("corrupt gzip");
    }
  }

  // XML declares its own encoding; UTF-8 covers essentially every sitemap in the
  // wild, and the XML parser re-reads the declaration anyway.
  return { text: new TextDecoder("utf-8").decode(buf), lastModified };
}

/* ---------- parsing ---------- */

// localName already drops the namespace prefix in Chrome; the split is a
// safeguard for documents that come back with prefixed names like <sm:urlset>.
function tagOf(el) {
  return el.localName.toLowerCase().split(":").pop();
}

function parseSitemap(text) {
  const trimmed = text.trim();

  // Plain-text sitemaps are valid: one URL per line.
  if (!trimmed.startsWith("<")) {
    const entries = trimmed
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => /^https?:\/\//i.test(l))
      .map((loc) => ({ loc, lastmod: "", alternates: [] }));
    if (!entries.length) throw new Error("not a sitemap");
    return { isIndex: false, entries };
  }

  const doc = new DOMParser().parseFromString(trimmed, "text/xml");
  if (doc.getElementsByTagName("parsererror").length) throw new Error("invalid XML");

  const root = doc.documentElement;
  const rootName = tagOf(root);
  if (rootName !== "urlset" && rootName !== "sitemapindex") {
    throw new Error(`unexpected root <${rootName}>`);
  }

  const entries = [];
  for (const block of root.children) {
    const blockName = tagOf(block);
    if (blockName !== "url" && blockName !== "sitemap") continue;

    const entry = { loc: "", lastmod: "", alternates: [] };

    // Reading only direct children is what keeps nested <image:loc> and
    // <video:loc> from being mistaken for the page URL.
    for (const field of block.children) {
      const name = tagOf(field);
      if (name === "loc" && !entry.loc) {
        entry.loc = field.textContent.trim();
      } else if (name === "lastmod" && !entry.lastmod) {
        entry.lastmod = field.textContent.trim();
      } else if (name === "link" && field.getAttribute("rel") === "alternate") {
        // xhtml:link alternates — how multilingual sites declare their language
        // versions at the sitemap level.
        const hreflang = field.getAttribute("hreflang");
        const href = field.getAttribute("href");
        if (hreflang && href) entry.alternates.push({ hreflang, href });
      }
    }

    if (entry.loc) entries.push(entry);
  }

  return { isIndex: rootName === "sitemapindex", entries };
}

/* ---------- discovery ---------- */

async function discover(origin, signal) {
  const declared = [];
  let robotsText = null;

  try {
    const { text: robots } = await loadText(new URL("/robots.txt", origin).href, signal);
    robotsText = robots;
    for (const line of robots.split(/\r?\n/)) {
      const m = /^\s*sitemap\s*:\s*(\S+)/i.exec(line);
      if (!m) continue;
      try {
        // Resolve against the origin so relative declarations work, and keep
        // cross-host sitemaps (CDN-hosted ones are common).
        declared.push(new URL(m[1].trim(), origin).href);
      } catch {
        /* skip unparseable entries */
      }
    }
  } catch {
    /* no robots.txt is fine — fall through to guessing */
  }

  if (declared.length) return { seeds: [...new Set(declared)], via: "robots.txt", robotsText };

  for (const path of CANDIDATES) {
    if (signal?.aborted) break;
    const url = new URL(path, origin).href;
    try {
      const { text } = await loadText(url, signal);
      if (/<(urlset|sitemapindex)/i.test(text) || /^https?:\/\//im.test(text.trim())) {
        return { seeds: [url], via: "common path", robotsText };
      }
    } catch {
      /* try the next candidate */
    }
  }

  return { seeds: [], via: null, robotsText };
}

/* ---------- crawl ---------- */

async function crawl(seeds, { signal, onProgress }) {
  const queue = [...seeds];
  const visited = new Set();
  const detail = new Map();
  const urls = new Map();
  const errors = [];
  // A URL listed in more than one sitemap file is deduplicated for the results,
  // so the duplication has to be recorded here or it becomes invisible.
  const duplicates = new Map();
  // lastmod that a parent index declares for each child sitemap file. Google
  // uses this to decide whether re-fetching the child is worth it, so it is a
  // separate thing from the lastmod of the URLs inside.
  const declaredLastmod = new Map();
  let done = 0;

  while (queue.length && visited.size < MAX_SITEMAPS) {
    if (signal?.aborted) break;

    const batch = [];
    while (batch.length < SITEMAP_CONCURRENCY && queue.length) {
      const next = queue.shift();
      if (!visited.has(next)) {
        visited.add(next);
        batch.push(next);
      }
    }

    await Promise.all(
      batch.map(async (sitemapUrl) => {
        try {
          const { text, lastModified } = await loadText(sitemapUrl, signal);
          const { isIndex, entries } = parseSitemap(text);

          const base = {
            url: sitemapUrl,
            bytes: text.length,
            httpLastModified: lastModified,
            declaredLastmod: declaredLastmod.get(sitemapUrl) || "",
          };

          if (isIndex) {
            for (const e of entries) {
              if (e.lastmod) declaredLastmod.set(e.loc, e.lastmod);
              if (!visited.has(e.loc)) queue.push(e.loc);
            }
            const childDates = entries.map((e) => e.lastmod).filter(Boolean).sort();
            detail.set(sitemapUrl, {
              ...base,
              kind: "index",
              count: entries.length,
              childrenWithLastmod: childDates.length,
              newestChild: childDates[childDates.length - 1] || "",
              oldestChild: childDates[0] || "",
            });
          } else {
            for (const e of entries) {
              if (!urls.has(e.loc)) {
                urls.set(e.loc, { lastmod: e.lastmod, alternates: e.alternates, source: sitemapUrl });
              } else {
                if (!duplicates.has(e.loc)) duplicates.set(e.loc, [urls.get(e.loc).source]);
                duplicates.get(e.loc).push(sitemapUrl);
              }
            }
            // ISO-8601 dates sort correctly as strings, which is why the sitemap
            // spec requires that format.
            const dates = entries.map((e) => e.lastmod).filter(Boolean).sort();
            detail.set(sitemapUrl, {
              ...base,
              kind: "urls",
              count: entries.length,
              urlsWithLastmod: dates.length,
              newestUrl: dates[dates.length - 1] || "",
              oldestUrl: dates[0] || "",
            });
          }
        } catch (err) {
          if (err.name !== "AbortError") errors.push(`${sitemapUrl} — ${err.message}`);
          detail.set(sitemapUrl, { url: sitemapUrl, kind: "failed", count: 0 });
        }
        done++;
        onProgress?.({ sitemaps: done, urls: urls.size, queued: queue.length });
      })
    );
  }

  // visited is a Set, so this preserves dequeue order (parents before children)
  // rather than whichever request happened to finish first.
  const sitemaps = [...visited].map((u) => detail.get(u)).filter(Boolean);

  return { urls, sitemaps, errors, duplicates, truncated: queue.length > 0 };
}
