/* Internal link graph.

   This is the cheapest analysis in the tool: the meta pass already downloads
   every page's HTML, so extracting links costs no extra requests. What it buys
   is the set of questions a per-page audit structurally cannot answer — which
   pages nothing links to, and which internal links point at URLs that are
   broken, redirecting or noindex. */

const MAX_LINKS_PER_PAGE = 500;
const MAX_ANCHORS_KEPT = 5;

// Only meaningful if we actually fetched most of the site. With a handful of
// pages read, "no inbound links" just means "we didn't look at the page that
// links here", which would be a badly misleading finding.
const MIN_COVERAGE_FOR_ORPHANS = 0.5;

// www.example.com/x and example.com/x are the same page for link-graph purposes,
// and real sites mix the two freely in their markup. normUrl deliberately keeps
// the distinction (it matters for canonicals), so the graph strips it here.
function linkKey(href, base) {
  const normalized = base ? normUrl(href, base) : normUrl(href);
  return normalized ? normalized.replace(/^(https?:\/\/)www\./i, "$1") : null;
}

function extractLinks(doc, pageUrl) {
  const result = { internal: [], external: 0, nofollow: 0, truncated: false };

  let base;
  try {
    base = new URL(pageUrl);
  } catch {
    return result;
  }

  const bareHost = base.hostname.toLowerCase().replace(/^www\./, "");
  const selfKey = linkKey(pageUrl);
  const seen = new Set();

  for (const anchor of doc.querySelectorAll("a[href]")) {
    const raw = (anchor.getAttribute("href") || "").trim();
    if (!raw || raw.startsWith("#")) continue;
    if (/^(mailto:|tel:|javascript:|data:|sms:|ftp:)/i.test(raw)) continue;

    let target;
    try {
      target = new URL(raw, pageUrl);
    } catch {
      continue;
    }
    if (target.protocol !== "http:" && target.protocol !== "https:") continue;

    // www.example.com and example.com are the same site for linking purposes.
    if (target.hostname.toLowerCase().replace(/^www\./, "") !== bareHost) {
      result.external++;
      continue;
    }

    const key = linkKey(target.href);
    if (!key || key === selfKey || seen.has(key)) continue;

    if (result.internal.length >= MAX_LINKS_PER_PAGE) {
      result.truncated = true;
      break;
    }

    const rel = (anchor.getAttribute("rel") || "").toLowerCase();
    const nofollow = rel.includes("nofollow");
    if (nofollow) result.nofollow++;

    seen.add(key);
    result.internal.push({
      to: key,
      // The normalized key has the trailing slash stripped and is for matching
      // only. Keep the resolved href so anything that fetches this link
      // requests the URL the page actually points at.
      href: target.href,
      anchor: (anchor.textContent || "").replace(/\s+/g, " ").trim().slice(0, 100),
      nofollow,
    });
  }

  return result;
}

/* ---------- targets outside the sitemap ---------- */

// The URLs most likely to be broken are exactly the ones a sitemap does not
// list: deleted pages, typos, stale hrefs. Checking only sitemap members means
// checking only pages that still exist, which misses almost every real broken
// link. This collects the rest so they can be probed directly.
function offSitemapTargets(rows, limit = 1000) {
  const known = new Set();
  for (const row of rows) {
    const key = linkKey(row.loc);
    if (key) known.add(key);
  }

  const targets = new Map();
  for (const row of rows) {
    if (!row.outLinks) continue;
    for (const link of row.outLinks) {
      const key = linkKey(link.to);
      if (!key || known.has(key) || targets.has(key)) continue;
      targets.set(key, { key, url: link.href || link.to, sources: [] });
    }
  }

  // Record who links to each one, so a broken target can be traced back.
  for (const row of rows) {
    if (!row.outLinks) continue;
    for (const link of row.outLinks) {
      const entry = targets.get(linkKey(link.to));
      if (entry && entry.sources.length < 20) {
        entry.sources.push({ from: row.loc, anchor: link.anchor });
      }
    }
  }

  const all = [...targets.values()];
  // Most-linked first, so a cap keeps the ones that matter most.
  all.sort((a, b) => b.sources.length - a.sources.length);
  return { targets: all.slice(0, limit), total: all.length };
}

/* ---------- graph ---------- */

function buildLinkGraph(rows, targetStatus = new Map()) {
  const byKey = new Map();
  for (const row of rows) {
    const key = linkKey(row.loc);
    if (key) byKey.set(key, row);
  }

  for (const row of rows) {
    row.inlinkCount = 0;
    row.inlinkSources = [];
    row.topAnchors = [];
    row.brokenLinks = [];
    row.redirectLinks = [];
    row.noindexLinks = [];
    row.orphan = false;
  }

  const anchorsByTarget = new Map();
  let crawled = 0;
  let internalEdges = 0;
  let offSiteMapEdges = 0;

  for (const row of rows) {
    if (!row.outLinks) continue;
    crawled++;

    for (const link of row.outLinks) {
      internalEdges++;
      // extractLinks already normalizes these, but normalizing again is cheap
      // and stops a whole class of silent "everything is an orphan" bugs.
      const target = byKey.get(linkKey(link.to));

      // Not in the sitemap. If it has been probed we can still judge it; that
      // is where the genuinely broken links live.
      if (!target) {
        offSiteMapEdges++;
        const probed = targetStatus.get(linkKey(link.to));
        if (probed) {
          if (probed.statusState === "failed" || (probed.status && probed.status >= 400)) {
            row.brokenLinks.push({
              to: link.href || link.to,
              anchor: link.anchor,
              status: probed.status || probed.statusError,
              offSitemap: true,
            });
          } else if (probed.redirectedTo) {
            row.redirectLinks.push({ to: link.href || link.to, anchor: link.anchor, dest: probed.redirectedTo, offSitemap: true });
          }
        }
        continue;
      }

      target.inlinkCount++;
      if (target.inlinkSources.length < 20) {
        target.inlinkSources.push({ from: row.loc, anchor: link.anchor, nofollow: link.nofollow });
      }

      if (link.anchor) {
        if (!anchorsByTarget.has(link.to)) anchorsByTarget.set(link.to, new Map());
        const counts = anchorsByTarget.get(link.to);
        counts.set(link.anchor, (counts.get(link.anchor) || 0) + 1);
      }

      // Link health, from whatever the status and meta passes already found.
      if (target.statusState === "failed" || (target.status && target.status >= 400)) {
        row.brokenLinks.push({ to: target.loc, anchor: link.anchor, status: target.status || target.statusError });
      } else if (target.redirectedTo) {
        row.redirectLinks.push({ to: target.loc, anchor: link.anchor, dest: target.redirectedTo });
      }
      if (/noindex/i.test(target.robots || "")) {
        row.noindexLinks.push({ to: target.loc, anchor: link.anchor });
      }
    }
  }

  for (const [key, counts] of anchorsByTarget) {
    const target = byKey.get(key);
    if (!target) continue;
    target.topAnchors = [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, MAX_ANCHORS_KEPT)
      .map(([text, count]) => ({ text, count }));
  }

  const coverage = rows.length ? crawled / rows.length : 0;
  const orphansReliable = coverage >= MIN_COVERAGE_FOR_ORPHANS;

  if (orphansReliable) {
    for (const row of rows) {
      // Only call a page orphaned if we actually read it; a page we skipped
      // tells us nothing about who links to it.
      if (row.outLinks && row.inlinkCount === 0) row.orphan = true;
    }
  }

  const orphans = rows.filter((r) => r.orphan);
  const withBroken = rows.filter((r) => r.brokenLinks.length);
  const brokenEdges = withBroken.reduce((n, r) => n + r.brokenLinks.length, 0);

  // A page nothing links to that still earns impressions is the strongest
  // version of this finding: Google found it despite the site's own structure.
  const orphansWithTraffic = orphans.filter((r) => (r.gsc?.impressions || 0) > 0).length;

  return {
    crawled,
    coverage,
    orphansReliable,
    internalEdges,
    offSiteMapEdges,
    orphans: orphans.length,
    orphansWithTraffic,
    pagesLinkingToBroken: withBroken.length,
    brokenEdges,
    redirectEdges: rows.reduce((n, r) => n + r.redirectLinks.length, 0),
    medianInlinks: medianOf(rows.filter((r) => r.outLinks).map((r) => r.inlinkCount)),
    targetsProbed: targetStatus.size,
  };
}

function medianOf(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : Math.round((sorted[mid - 1] + sorted[mid]) / 2);
}
