/* Fast status sweep. HEAD requests only, so no page bodies are downloaded and a
   sitemap far too large for the full meta pass can still be checked. */

const STATUS_CONCURRENCY = 8;
const STATUS_TIMEOUT_MS = 15_000;
const SLOW_MS = 2000;

// Servers and CDNs that refuse HEAD tend to answer with one of these.
const HEAD_REJECTED = new Set([400, 403, 405, 406, 409, 411, 501]);

/* ---------- Link header ---------- */

// RFC 8288. Some sites declare canonical and hreflang in an HTTP header instead
// of markup — the only way to do it for PDFs and other non-HTML files.
function parseLinkHeader(value) {
  const links = [];
  if (!value) return links;

  // Split on commas that separate entries, not commas inside quoted parameters.
  for (const part of value.split(/,(?=\s*<)/)) {
    const m = /<([^>]*)>\s*(.*)/.exec(part.trim());
    if (!m) continue;

    const link = { href: m[1].trim(), rel: "", hreflang: "" };
    for (const param of m[2].split(";")) {
      const p = /^\s*([\w*-]+)\s*=\s*"?([^";]*)"?/.exec(param);
      if (!p) continue;
      const key = p[1].toLowerCase();
      if (key === "rel") link.rel = p[2].trim().toLowerCase();
      else if (key === "hreflang") link.hreflang = p[2].trim();
    }
    if (link.rel) links.push(link);
  }
  return links;
}

/* ---------- redirect classification ---------- */

// Extension fetch cannot observe intermediate hops: Chrome returns an
// opaque-filtered response for a manual-redirect request (status 0, no
// Location), so 301-vs-302 is genuinely not available here. Comparing the
// requested URL against where we landed gives the part that usually matters.
function classifyRedirect(fromUrl, toUrl) {
  const tags = [];
  let a, b;
  try {
    a = new URL(fromUrl);
    b = new URL(toUrl);
  } catch {
    return tags;
  }

  if (a.protocol !== b.protocol) {
    tags.push(a.protocol === "http:" && b.protocol === "https:" ? "http→https" : "protocol change");
  }

  const stripWww = (h) => h.replace(/^www\./i, "");
  if (a.hostname !== b.hostname) {
    if (stripWww(a.hostname) === stripWww(b.hostname)) {
      tags.push(b.hostname.toLowerCase().startsWith("www.") ? "www added" : "www removed");
    } else {
      tags.push("different host");
    }
  }

  const stripSlash = (p) => p.replace(/\/+$/, "");
  if (a.pathname !== b.pathname) {
    if (stripSlash(a.pathname) === stripSlash(b.pathname)) {
      tags.push(b.pathname.endsWith("/") ? "slash added" : "slash removed");
    } else if (a.pathname.toLowerCase() === b.pathname.toLowerCase()) {
      tags.push("case change");
    } else {
      tags.push("different path");
    }
  }

  if (a.search !== b.search) tags.push("query changed");

  return tags;
}

/* ---------- probe ---------- */

async function probeStatus(url, signal) {
  const started = performance.now();

  const timer = new AbortController();
  const timeout = setTimeout(() => timer.abort(), STATUS_TIMEOUT_MS);
  const onAbort = () => timer.abort();
  signal?.addEventListener("abort", onAbort, { once: true });

  try {
    let method = "HEAD";
    let res = await fetch(url, {
      method: "HEAD",
      redirect: "follow",
      credentials: "omit",
      signal: timer.signal,
    });

    // Fall back to GET when HEAD is refused, cancelling the body immediately so
    // the page still isn't downloaded. Costs one extra round trip on those hosts.
    if (HEAD_REJECTED.has(res.status)) {
      method = "GET";
      res = await fetch(url, {
        method: "GET",
        redirect: "follow",
        credentials: "omit",
        signal: timer.signal,
      });
      res.body?.cancel().catch(() => {});
    }

    const ms = Math.round(performance.now() - started);
    const links = parseLinkHeader(res.headers.get("link"));

    const result = {
      statusState: "ok",
      status: res.status,
      method,
      ms,
      slow: ms > SLOW_MS,
      contentType: (res.headers.get("content-type") || "").split(";")[0].trim(),
      bytes: parseInt(res.headers.get("content-length") || "", 10) || null,
      headerRobots: res.headers.get("x-robots-tag") || "",
      headerCanonical: links.find((l) => l.rel === "canonical")?.href || "",
      headerAlternates: links
        .filter((l) => l.rel === "alternate" && l.hreflang)
        .map((l) => ({ hreflang: l.hreflang, href: l.href })),
    };

    if (res.redirected && res.url && res.url !== url) {
      result.redirectedTo = res.url;
      result.redirectKind = classifyRedirect(url, res.url);
    }

    return result;
  } catch (err) {
    if (signal?.aborted) throw new DOMException("aborted", "AbortError");
    return {
      statusState: "failed",
      status: null,
      ms: Math.round(performance.now() - started),
      statusError: err.name === "AbortError" ? "timed out" : err.message,
    };
  } finally {
    clearTimeout(timeout);
    signal?.removeEventListener("abort", onAbort);
  }
}

/* ---------- driver ---------- */

async function sweepStatus(rows, { signal, onProgress }) {
  let cursor = 0;
  let done = 0;
  let broken = 0;
  let redirects = 0;

  async function worker() {
    while (cursor < rows.length) {
      if (signal.aborted) return;
      const row = rows[cursor++];

      try {
        const result = await probeStatus(row.loc, signal);
        Object.assign(row, result);

        // An X-Robots-Tag header binds exactly like the meta tag and is
        // invisible unless you read the response headers.
        if (result.headerRobots) {
          const tag = `header: ${result.headerRobots}`;
          row.robots = row.robots && !row.robots.includes(tag) ? `${row.robots} | ${tag}` : tag;
        }
        if (result.redirectedTo) redirects++;
        if (result.statusState === "failed" || result.status >= 400) broken++;
      } catch (err) {
        if (err.name === "AbortError") return;
        row.statusState = "failed";
        row.statusError = err.message;
        broken++;
      }

      done++;
      onProgress?.({ done, total: rows.length, broken, redirects });
    }
  }

  await Promise.all(Array.from({ length: Math.min(STATUS_CONCURRENCY, rows.length) }, worker));
  return { done, broken, redirects, aborted: signal.aborted };
}
